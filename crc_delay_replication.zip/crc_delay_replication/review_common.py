"""
review_common.py — 审稿回应实验的共享工具
=================================================================
- gains_full: 对振子 i 计算完整增益矩阵 G[j][k] = base - E({(j,k)})（字典可选 r / x）
- decide:     两种结构判据（逐邻居 argmax + 均值阈值 / 全局 (j,k) 阈值）
- metrics:    P/R/F1 + 时延命中(|Δτ|≤0.1) + exact-step match(|Δk|=0, ≤1) + 最大间隙判据
- sync_metrics: s_sync(相对误差口径) 与 ρ
所有实验脚本共用, 保证口径一致。
"""
import numpy as np

from granger_structure import fit_out


def err_terms(X, i, terms, reservoirs, Nc, lam, d_obs=3):
    """储备池字典: 输入=[r_i(t); r_j(t-k) 前Nc维], 目标=x_i(t+1) 前 d_obs 分量."""
    T = X.shape[0]
    K_max = max([k for (_, k) in terms] + [0])
    Ts = T - K_max - 1
    parts = [reservoirs[i][K_max + 1:T - 1, :]]
    for (j, k) in terms:
        parts.append(reservoirs[j][K_max + 1 - k:T - 1 - k, :Nc])
    R = np.hstack(parts).T
    U = X[K_max + 2:K_max + 2 + Ts, i, :d_obs].T
    w = fit_out(U, R, lam)
    return float(np.mean((U - w @ R) ** 2))


def err_terms_x(X, i, terms, K_max, lam, d_obs=3):
    """原始信号字典: 输入=[x_i(t); x_j(t-k)], 每项 d_obs 分量."""
    T = X.shape[0]
    Ts = T - K_max - 1
    parts = [X[K_max + 1:T - 1, i, :d_obs]]
    for (j, k) in terms:
        parts.append(X[K_max + 1 - k:T - 1 - k, j, :d_obs])
    R = np.hstack(parts).T
    U = X[K_max + 2:K_max + 2 + Ts, i, :d_obs].T
    w = fit_out(U, R, lam)
    return float(np.mean((U - w @ R) ** 2))


def gains_full(X, i, reservoirs, Nc, K_max, lam, dict_kind="r", d_obs=3):
    """完整增益矩阵 {j: array(K_max+1)}; dict_kind='r' 储备池 / 'x' 原始信号."""
    N = X.shape[1]
    if dict_kind == "r":
        f = lambda terms: err_terms(X, i, terms, reservoirs, Nc, lam, d_obs)
    else:
        f = lambda terms: err_terms_x(X, i, terms, K_max, lam, d_obs)
    base = f([])
    G = {}
    for j in range(N):
        if j == i:
            continue
        G[j] = np.array([base - f([(j, k)]) for k in range(K_max + 1)])
    return G


def decide(Gs, N, rule="argmax_mean"):
    """Gs={i:{j:arr(k)}} → hat 边集, kb={i:{j:k*}}.
    argmax_mean: 每 j 先 argmax_k, 再 gain_max > mean_j(gain_max) 判边（本文方法）
    global_thresh: 对全部 (j,k) 增益取单一均值阈值, 任一 k 过阈即判边"""
    hat = set()
    kb = {}
    for i, G in Gs.items():
        kb[i] = {}
        for j, arr in G.items():
            kb[i][j] = int(np.argmax(arr))
        if rule == "argmax_mean":
            gm = {j: float(arr.max()) for j, arr in G.items()}
            thr = float(np.mean(list(gm.values())))
            for j, v in gm.items():
                if v > thr:
                    hat.add((i, j))
        elif rule == "global_thresh":
            allv = np.concatenate([arr for arr in G.values()])
            thr = float(allv.mean())
            for j, arr in G.items():
                if bool((arr > thr).any()):
                    hat.add((i, j))
    return hat, kb


def _prf(hat, true):
    TP = len(hat & true); FP = len(hat - true); FN = len(true - hat)
    P = TP / (TP + FP) if TP + FP else 0.0
    R = TP / (TP + FN) if TP + FN else 0.0
    F1 = 2 * P * R / (P + R) if P + R else 0.0
    return dict(P=P, R=R, F1=F1, FP=FP, FN=FN)


def metrics(W, tau, Gs, dt_s, hit_tol=0.1):
    """返回 {rule: dict}. 时延指标按 argmax k* 计算（与边判据无关）。"""
    N = W.shape[0]
    true = {(i, j) for i in range(N) for j in range(N) if W[i, j] == 1}
    out = {}
    for rule in ["argmax_mean", "global_thresh"]:
        hat, kb = decide(Gs, N, rule)
        d = _prf(hat, true)
        h10 = h0 = h1 = nt = 0
        errs = []
        dex = []
        for (i, j) in true:
            nt += 1
            k = kb[i][j]
            kt = int(round(tau[i, j] / dt_s))
            e = abs(k * dt_s - tau[i, j])
            errs.append(e)
            dk = abs(k - kt)
            dex.append(dk)
            h10 += int(e <= hit_tol)
            h0 += int(dk == 0)
            h1 += int(dk <= 1)
        d.update(hit10=h10, exact0=h0, exact1=h1, nt=nt,
                 merr=float(np.mean(errs)), mexact=float(np.mean(dex)))
        out[rule] = d
    # 最大间隙判据（作用于 gain_max）
    hat = set()
    for i, G in Gs.items():
        items = sorted(((j, float(arr.max())) for j, arr in G.items()),
                       key=lambda x: -x[1])
        g = np.array([v for _, v in items])
        if len(g) < 2:
            hat.add((i, items[0][0]))
            continue
        ratio = g[:-1] / (g[1:] + 1e-30)
        m = int(np.argmax(ratio))
        for j, _ in items[:m + 1]:
            hat.add((i, j))
    out["gap"] = _prf(hat, true)
    return out


def sync_metrics(X):
    """s_sync = mean pair RMS / spread（→0 同步, ≈1.41 独立）; ρ 平均成对相关."""
    N = X.shape[1]
    xs = X[:, :, 0]
    d = np.array([np.sqrt(np.mean((xs[:, i] - xs[:, j]) ** 2))
                  for i in range(N) for j in range(i + 1, N)])
    spread = np.sqrt(np.mean((xs - xs.mean(axis=1, keepdims=True)) ** 2))
    s = float(np.mean(d) / (spread + 1e-12))
    C = np.corrcoef(xs.T)
    rho = float((C.sum() - N) / (N * (N - 1)))
    return s, rho


def make_tau(W, tau_range, seed):
    N = W.shape[0]
    rng = np.random.default_rng(seed + 1000)
    tau = rng.uniform(*tau_range, (N, N))
    np.fill_diagonal(tau, 0.0)
    return tau * W


def argmax_eval(X, i, reservoirs, Nc, K_max, lam, d_obs=3):
    """sindy_argmax 的 d_obs 参数化版: 返回 (gain_max{j}, k_best{j})."""
    N = X.shape[1]
    base = err_terms(X, i, [], reservoirs, Nc, lam, d_obs)
    gain_max, k_best = {}, {}
    for j in range(N):
        if j == i:
            continue
        bg, bk = -np.inf, 0
        for k in range(0, K_max + 1):
            e = err_terms(X, i, [(j, k)], reservoirs, Nc, lam, d_obs)
            gain = base - e
            if gain > bg:
                bg, bk = gain, k
        gain_max[j] = bg
        k_best[j] = bk
    return gain_max, k_best


def full_pipeline(X, W, tau, dt_s, reservoirs, Nc=30, lam=1e-6, d_obs=3,
                  hit_tol=0.1):
    """储备池已给定 → argmax增益 → mean/gap 判据 + 时延命中 + exact-step."""
    N = W.shape[0]
    K_max = int(np.ceil(tau[W == 1].max() / dt_s)) + 2
    true = {(i, j) for i in range(N) for j in range(N) if W[i, j] == 1}
    gains = {}
    hat = set()
    h10 = h0 = h1 = nt = 0
    errs = []
    for i in range(N):
        gm, kb = argmax_eval(X, i, reservoirs, Nc, K_max, lam, d_obs)
        gains[i] = gm
        thr = float(np.mean(list(gm.values())))
        for j, v in gm.items():
            if v > thr:
                hat.add((i, j))
        for j in range(N):
            if W[i, j] == 1:
                nt += 1
                k = kb[j]
                kt = int(round(tau[i, j] / dt_s))
                e = abs(k * dt_s - tau[i, j])
                errs.append(e)
                h10 += int(e <= hit_tol)
                h0 += int(abs(k - kt) == 0)
                h1 += int(abs(k - kt) <= 1)
    d_mean = _prf(hat, true)
    # gap 判据
    hat_g = set()
    for i, gm in gains.items():
        items = sorted(gm.items(), key=lambda x: -x[1])
        g = np.array([v for _, v in items])
        if len(g) < 2:
            hat_g.add((i, items[0][0]))
            continue
        ratio = g[:-1] / (g[1:] + 1e-30)
        m = int(np.argmax(ratio))
        for j, _ in items[:m + 1]:
            hat_g.add((i, j))
    d_gap = _prf(hat_g, true)
    return dict(mean=d_mean, gap=d_gap, hit10=h10, exact0=h0, exact1=h1,
                nt=nt, merr=float(np.mean(errs)), K_max=K_max, gains=gains)
