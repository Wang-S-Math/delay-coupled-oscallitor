"""
review_c1_rk4.py — 审稿 1.1: Lorenz 主实验的 RK4+Lagrange 交叉验证
=================================================================
数据生成映射原定义为 前向Euler(dt=0.005)+时延取整; 审稿人要求用高精度 DDE
积分(RK4+四点Lagrange延迟插值, 分数时延不取整) 交叉验证 N=7 基准结论。
配置与主实验一致: W7, ε=1.5, Δt=0.05, τ∈[0.3,1.2], T=20000, 种子0-3。
输出: Euler(主表) vs RK4 的 P/R/时延命中(≤0.1s)/exact-step/mean|Δτ|/s_sync。
"""
import os
for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
           "NUMEXPR_NUM_THREADS"):
    os.environ[_v] = "1"
import json
import time
import numpy as np

from pre2025_crc import W7, Reservoir
from sindy_argmax import sindy_argmax
import lorenz_tune
import review_common as RC


def simulate_lorenz_rk4(W, tau, t_end, dt, eps, seed, sample=10):
    """RK4 + 四点 Lagrange 延迟插值 (分数时延, 不取整). 耦合: ẏ_i += εΣ_j w_ij[x_j(t-τ_ij)-x_i]."""
    N = W.shape[0]
    p_idx, q_idx = np.nonzero(W)
    d_e = np.asarray(tau, float)[p_idx, q_idx] / dt
    d_e = np.maximum(d_e, 1e-9)
    M = int(np.ceil(d_e.max())) + 3
    n = int(round(t_end / dt))
    rng = np.random.default_rng(seed)
    X0 = rng.uniform(1.0, 5.0, (N, 3))
    buf = np.tile(X0, (M, 1, 1))
    a, b, c = 10.0, 28.0, 8.0 / 3.0
    Wm = W.astype(float)
    deg = Wm.sum(axis=1)

    def delayed(al):
        idx = M - 1 - d_e + al
        i0 = np.floor(idx).astype(np.int64)
        w = idx - i0
        lm1 = w * (w - 1.0) * (w - 2.0) / (-6.0)
        l0 = (w + 1.0) * (w - 1.0) * (w - 2.0) / 2.0
        l1 = (w + 1.0) * w * (w - 2.0) / (-2.0)
        l2 = (w + 1.0) * w * (w - 1.0) / 6.0
        rows = (ptr + i0[None, :] + np.array([-1, 0, 1, 2])[:, None]) % M
        vals = buf[rows, q_idx[None, :], 0]           # (4,E) x分量
        V = lm1 * vals[0] + l0 * vals[1] + l1 * vals[2] + l2 * vals[3]
        return np.bincount(p_idx, weights=V, minlength=N)

    def rhs(x, xdel):
        dX = np.empty_like(x)
        dX[:, 0] = a * (x[:, 1] - x[:, 0])
        coup = xdel - deg * x[:, 0]
        dX[:, 1] = b * x[:, 0] - x[:, 1] - x[:, 0] * x[:, 2] + eps * coup
        dX[:, 2] = x[:, 0] * x[:, 1] - c * x[:, 2]
        return dX

    X = np.empty((n + 1, N, 3))
    X[0] = X0
    ptr = 0
    for i in range(n):
        x = X[i]
        k1 = rhs(x, delayed(0.0))
        k2 = rhs(x + 0.5 * dt * k1, delayed(0.5))
        k3 = rhs(x + 0.5 * dt * k2, delayed(0.5))
        k4 = rhs(x + dt * k3, delayed(1.0))
        X[i + 1] = x + (dt / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4)
        if not np.all(np.isfinite(X[i + 1])):
            raise RuntimeError("diverged")
        buf[ptr] = X[i + 1]
        ptr = (ptr + 1) % M
    return X[::sample]


def run_one(sim, W, seed, eps=1.5, tau_range=(0.3, 1.2), Ns=300, Nc=30,
            lam=1e-6, sample=10, dt_int=0.005, T_use=20000):
    N = W.shape[0]
    dt_s = sample * dt_int
    tau = RC.make_tau(W, tau_range, seed)
    t_end = T_use * dt_s + 20.0
    X = sim(W, tau, t_end, dt=dt_int, eps=eps, seed=seed, sample=sample)[:T_use]
    s_sync, rho = RC.sync_metrics(X)
    reservoirs = [Reservoir(Ns, 3, 0.1, 0.3, 0.9, seed=i).run(X[:, i, :])
                  for i in range(N)]
    K_max = int(np.ceil(tau[W == 1].max() / dt_s)) + 2
    true = {(i, j) for i in range(N) for j in range(N) if W[i, j] == 1}
    hat = set()
    h10 = h0 = h1 = nt = 0
    errs = []
    for i in range(N):
        gm, kb = sindy_argmax(X, i, reservoirs, Nc, K_max, lam)
        thr = float(np.mean(list(gm.values())))
        for j, v in gm.items():
            if v > thr:
                hat.add((i, j))
        for j in range(N):
            if W[i, j] == 1:
                nt += 1
                k = kb[j]
                kt = int(round(tau[i, j] / dt_s))
                e = abs(k * dt_s - tau[i, j])
                errs.append(e)
                h10 += int(e <= 0.1)
                h0 += int(abs(k - kt) == 0)
                h1 += int(abs(k - kt) <= 1)
    d = RC._prf(hat, true)
    d.update(hit10=h10, exact0=h0, exact1=h1, nt=nt,
             merr=float(np.mean(errs)), s_sync=s_sync, rho=rho)
    return d


def main():
    t0 = time.time()
    try:
        with open("results_c1.json") as fh:
            log = json.load(fh)
    except Exception:
        log = {}
    print("=" * 110, flush=True)
    print("[C1] Lorenz N=7 W7 交叉验证: Euler+取整(主表口径) vs RK4+Lagrange(分数时延)", flush=True)
    print("     ε=1.5, Δt=0.05, τ∈[0.3,1.2], T=20000, 种子0-3; 命中|Δτ|≤0.1s; exact=|Δk| vs round(τ/Δt)", flush=True)
    print("=" * 110, flush=True)
    for tag, sim in [("Euler ", lorenz_tune.simulate), ("RK4   ", simulate_lorenz_rk4)]:
        rows = []
        for s in range(4):
            key = f"{tag.strip()}_s{s}"
            if key in log:
                rows.append(log[key])
                continue
            d = run_one(sim, W7, s)
            rows.append(d)
            log[key] = d
            with open("results_c1.json", "w") as fh:
                json.dump(log, fh, indent=1, default=float)
            print(f"  {tag} seed{s}: P={d['P']:.0%} R={d['R']:.0%} FP={d['FP']} "
                  f"hit={d['hit10']}/{d['nt']} exact0={d['exact0']}/{d['nt']} "
                  f"exact<=1={d['exact1']}/{d['nt']} merr={d['merr']:.4f}s "
                  f"s_sync={d['s_sync']:.2f} rho={d['rho']:+.2f} [{time.time()-t0:.0f}s]", flush=True)
        m = lambda k: np.mean([r[k] for r in rows])
        sd = lambda k: np.std([r[k] for r in rows])
        print(f"  {tag} 汇总: P={m('P'):.0%}+-{sd('P'):.0%} R={m('R'):.0%} "
              f"hit={m('hit10'):.1f}/{rows[0]['nt']} exact0={m('exact0'):.1f} "
              f"exact<=1={m('exact1'):.1f} merr={m('merr'):.4f}+-{sd('merr'):.4f}s "
              f"s_sync={m('s_sync'):.2f}", flush=True)
        print(flush=True)
    print(f"总耗时 {time.time()-t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
