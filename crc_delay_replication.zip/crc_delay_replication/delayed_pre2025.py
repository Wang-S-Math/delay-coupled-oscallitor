"""
delayed_pre2025.py — PRE2025扩展异构时延(用户核心目标)
=================================================================
模型: 耦合Lorenz + 异构时延(每对τ_ij不同):
  ẏ_i = b·x_i - y_i - x_i·z_i + ε·Σ_j w_ij·[x_j(t-τ_ij) - x_i(t)]
复验两个"有效"(无时滞已复现):
  ①C-RC动力学预测(输出层耦合) vs 普通RC → 结构信息仍提升预测?
  ②Granger因果结构辨识 → 时延下仍能重构W?
关键: 储备池r_j(tanh+Wres记忆)含x_j历史→输出层引入r_j节点可捕获x_j(t-τ)
"""
import time
import numpy as np
from pre2025_crc import W7, Reservoir
from granger_structure import fit_out


def simulate_delayed(W, tau, t_end, dt=0.01, eps=0.3, seed=0):
    """耦合Lorenz + 异构时延tau[i,j]. 欧拉法(dt小). 返回采样序列."""
    N = W.shape[0]
    rng = np.random.default_rng(seed)
    X0 = rng.uniform(1.0, 5.0, (N, 3))
    n = int(round(t_end/dt))
    max_lag = int(np.ceil(np.max(tau)/dt)) + 1
    X = np.tile(X0, (n + 1 + max_lag, 1, 1))
    idx = max_lag
    a, b, c = 10.0, 28.0, 8.0/3.0
    for i in range(n):
        dX = np.zeros((N, 3))
        for p in range(N):
            xp, yp, zp = X[idx, p]
            coup = 0.0
            for q in range(N):
                if W[p, q] != 0:
                    lag = max(1, int(round(tau[p, q]/dt)))
                    coup += W[p, q]*(X[idx-lag, q, 0] - xp)
            dX[p, 0] = a*(yp - xp)
            dX[p, 1] = b*xp - yp - xp*zp + eps*coup
            dX[p, 2] = xp*yp - c*zp
        X[idx+1] = X[idx] + dt*dX
        idx += 1
    return X[max_lag+1:max_lag+1+n:5]  # 采样Δt=0.05


def main():
    t0 = time.time()
    print("=" * 62)
    print("PRE2025扩展异构时延 (N=7, 每对τ_ij不同)")
    print("=" * 62)
    # 异构时延矩阵: 每对(τ∈[0.2,0.8]s), 对角0
    rng = np.random.default_rng(42)
    tau = rng.uniform(0.2, 0.8, (7, 7))
    np.fill_diagonal(tau, 0.0)
    print("异构时延矩阵 τ_ij (s):")
    for i in range(7):
        print("  " + " ".join(f"{tau[i,j]:.2f}" if W7[i,j] else "  - " for j in range(7)))
    print(f"  平均耦合时延={tau[W7==1].mean():.3f}s")

    X = simulate_delayed(W7, tau, t_end=1010.0, dt=0.01, eps=0.3, seed=0)
    X = X[:20000]
    print(f"\n数据: {X.shape[0]} 点")

    # ① C-RC vs 普通RC (异构时延)
    from pre2025_crc import crc_errors
    err_c, err_r = crc_errors(X, W7, Ns=300, Nc=30, lam=1e-6, seed=0)
    print(f"\n[1] 动力学预测 (异构时延): C-RC={err_c.mean():.5f}  普通RC={err_r.mean():.5f}  "
          f"降低={100*(err_r.mean()-err_c.mean())/err_r.mean():.1f}%")
    for i in range(7):
        print(f"    振子{i}: C-RC={err_c[i]:.4f}  普通RC={err_r[i]:.4f}  "
              f"降低={100*(err_r[i]-err_c[i])/err_r[i]:.1f}%")

    # ② Granger因果结构辨识 (异构时延)
    from granger_structure import granger_structure
    dE, _ = granger_structure(X, Ns=300, Nc=30, lam=1e-6, seed=0)
    N = 7
    W_hat = np.zeros((N, N), dtype=int)
    for i in range(N):
        thr = np.mean([dE[i, j] for j in range(N) if j != i])
        for j in range(N):
            if j != i and dE[i, j] < thr:
                W_hat[i, j] = 1
    true_edges = set((i, j) for i in range(N) for j in range(N) if W7[i, j] == 1)
    hat_edges = set((i, j) for i in range(N) for j in range(N) if W_hat[i, j] == 1)
    TP = len(hat_edges & true_edges); FP = len(hat_edges - true_edges); FN = len(true_edges - hat_edges)
    P = TP/(TP+FP) if TP+FP else 0; R = TP/(TP+FN) if TP+FN else 0
    print(f"\n[2] Granger因果结构辨识 (异构时延): 真实{len(true_edges)}边 重构{len(hat_edges)}边")
    print(f"    TP={TP} FP={FP} FN={FN}  精确率P={P:.2%}  召回率R={R:.2%}")
    print(f"    (无时滞基线: P=100% R=100%)")
    print(f"\n({time.time()-t0:.1f}s)")


if __name__ == "__main__":
    main()
