"""
pre2025_crc.py — 真正的PRE2025: C-RC预测耦合Lorenz动力学(无时滞基线)
=================================================================
PRE2025 (Zhang&Wang, PRE 112, 054226, 2025):
  模型(式11, 无时滞): ẋ=a(y-x), ẏ=bx-y-xz+εΣ_j w_ij(x_j-x_i), ż=xy-cz
    a=10,b=28,c=8/3, ε=0.3, ER平均度3, N=7 (W=式12)
  C-RC核心: ①每振子独立训练储备池(式7, 只用u_i) ②输出层耦合(式8-9,
    v_i=w_i^out·[r_i;q_i], q_i=邻居储备池Nc节点, 结构w_i决定用哪些邻居)
  预测: 已知W → C-RC(输出层引入邻居) vs 普通RC(只用自己) 对比误差
数据: RK4 dt=0.01, 采样Δt=0.05(每5步取1), 20000步(15000训练+5000预测)
"""
import time
import numpy as np

# W 式12 (N=7)
W7 = np.array([
    [0, 0, 0, 1, 0, 0, 1],
    [0, 0, 0, 0, 0, 1, 0],
    [0, 1, 0, 0, 0, 1, 0],
    [1, 1, 1, 0, 0, 0, 0],
    [1, 0, 0, 1, 0, 0, 0],
    [0, 1, 0, 0, 0, 0, 1],
    [0, 0, 0, 0, 0, 1, 0],
], dtype=float)


def coupled_lorenz(X, W, eps, a=10.0, b=28.0, c=8.0/3.0):
    """式11. X (N,3). 耦合在y方程: eps*Σ_j w_ij(x_j-x_i)."""
    N = W.shape[0]
    dX = np.zeros((N, 3))
    for i in range(N):
        xi, yi, zi = X[i]
        dX[i, 0] = a*(yi - xi)
        coup = 0.0
        for j in range(N):
            if W[i, j] != 0:
                coup += W[i, j]*(X[j, 0] - xi)
        dX[i, 1] = b*xi - yi - xi*zi + eps*coup
        dX[i, 2] = xi*yi - c*zi
    return dX


def simulate(W, t_end, dt=0.01, eps=0.3, X0=None, seed=0):
    N = W.shape[0]
    rng = np.random.default_rng(seed)
    if X0 is None:
        X0 = rng.uniform(1.0, 5.0, (N, 3))
    n = int(round(t_end/dt))
    X = np.zeros((n+1, N, 3)); X[0] = X0
    for i in range(n):
        k1 = coupled_lorenz(X[i], W, eps)
        k2 = coupled_lorenz(X[i] + 0.5*dt*k1, W, eps)
        k3 = coupled_lorenz(X[i] + 0.5*dt*k2, W, eps)
        k4 = coupled_lorenz(X[i] + dt*k3, W, eps)
        X[i+1] = X[i] + (dt/6.0)*(k1 + 2*k2 + 2*k3 + k4)
    return X


class Reservoir:
    """式7: r(t+1)=(1-α)r(t)+α·tanh(Win·u(t)+Wres·r(t)+bk)."""
    def __init__(self, Ns, input_dim, sparsity=0.1, alpha=0.3, rho=0.9, seed=0):
        rng = np.random.default_rng(seed)
        self.Ns = Ns; self.alpha = alpha
        self.Win = rng.uniform(-1.0, 1.0, (Ns, input_dim))
        Wres = rng.uniform(0.0, 1.0, (Ns, Ns))
        keep = rng.random((Ns, Ns)) < sparsity
        Wres = Wres * keep
        rho_actual = np.max(np.abs(np.linalg.eigvals(Wres)))
        if rho_actual > 0:
            Wres = Wres * rho/rho_actual
        self.Wres = Wres
        self.bk = rng.uniform(0.0, 0.5, Ns)

    def run(self, U):
        """U (T, D) → R (T, Ns)."""
        T = U.shape[0]
        R = np.zeros((T, self.Ns)); r = np.zeros(self.Ns)
        for t in range(T):
            r = (1 - self.alpha)*r + self.alpha*np.tanh(self.Win@U[t] + self.Wres@r + self.bk)
            R[t] = r
        return R


def crc_errors(X, W, Ns=200, Nc=20, lam=1e-6,
               sparsity=0.1, alpha=0.3, rho=0.9, seed=0):
    """C-RC(式8-9) vs 普通RC 的预测误差. 目标=预测u_i(t+1). 所有矩阵(T,D)."""
    N = W.shape[0]; T = X.shape[0]
    # 每振子独立储备池(式7, 输入u_i=[x_i,y_i,z_i])
    reservoirs = []
    for i in range(N):
        res = Reservoir(Ns, 3, sparsity, alpha, rho, seed=seed + i)
        reservoirs.append(res.run(X[:, i, :]))  # (T, Ns)
    err_c = np.zeros(N); err_r = np.zeros(N)
    for i in range(N):
        R_i = reservoirs[i]  # (T, Ns)
        nbrs = [j for j in range(N) if W[i, j] != 0]
        # 邻居储备池前Nc节点 (式8: q_i=g(w_i◦[s_1..s_Nm]))
        S = np.hstack([reservoirs[j][:, :Nc] for j in nbrs]) if nbrs else np.zeros((T, 0))
        R_full = np.hstack([R_i, S])  # (T, Ns_total)
        U = X[1:, i, :]              # (T-1, 3) 目标: u_i(t+1)
        Rm = R_full[:-1, :]          # (T-1, Ns_total) 输入: t=0..T-2
        U_mat = U.T                  # (3, T-1) = (D, T)
        R_mat = Rm.T                 # (Ns_total, T-1) = (Ns, T)
        Nst = R_mat.shape[0]
        b_c = U_mat @ R_mat.T        # (3, Ns_total)
        w_c = np.linalg.solve(R_mat@R_mat.T + lam*np.eye(Nst), b_c.T).T  # (3, Ns_total)
        Rm_i = R_i[:-1, :]           # (T-1, Ns)
        Ri_mat = Rm_i.T              # (Ns, T-1)
        b_r = U_mat @ Ri_mat.T       # (3, Ns)
        w_r = np.linalg.solve(Ri_mat@Ri_mat.T + lam*np.eye(Ns), b_r.T).T  # (3, Ns)
        err_c[i] = float(np.mean((U_mat - w_c @ R_mat)**2))
        err_r[i] = float(np.mean((U_mat - w_r @ Ri_mat)**2))
    return err_c, err_r


def main():
    t0 = time.time()
    print("=" * 60)
    print("真正PRE2025复现: C-RC vs 普通RC (耦合Lorenz N=7, 无时滞)")
    print("W=式12, ε=0.3, a=10,b=28,c=8/3")
    print("=" * 60)
    # 生成数据: t_end = 20000步*0.05 = 1000 (采样后20000点)
    X = simulate(W7, t_end=1010.0, dt=0.01, eps=0.3, seed=0)  # (101001, 7, 3)
    Xs = X[::5]  # 采样Δt=0.05 → (20201, 7, 3)
    print(f"数据: {Xs.shape[0]} 采样点 (需≥20000)")
    Xs = Xs[:20000]
    err_c, err_r = crc_errors(Xs, W7, Ns=200, Nc=20, lam=1e-6, seed=0)
    print(f"\n{'振子':>4} {'C-RC误差':>12} {'普通RC误差':>12} {'C-RC降低%':>10}")
    for i in range(7):
        red = (err_r[i] - err_c[i])/err_r[i]*100
        print(f"  {i:>2} {err_c[i]:>14.5f} {err_r[i]:>14.5f} {red:>10.1f}")
    print(f"\n平均: C-RC={err_c.mean():.5f}  普通RC={err_r.mean():.5f}  "
          f"降低={100*(err_r.mean()-err_c.mean())/err_r.mean():.1f}%")
    print(f"\n判据: C-RC误差 < 普通RC = 输出层耦合(结构)提升预测 = 有效")
    print(f"({time.time()-t0:.1f}s)")


if __name__ == "__main__":
    main()
