"""
sindy_argmax.py — 逐邻居argmax: 时滞唯一→每j取gain最大的k_j (用户洞察)
=================================================================
用户洞察: 每个j时滞唯一(只有1个k_j)→对j取argmax_k gain(j,k)=k_j, 不用阈值筛k.
阈值只判断结构(j是否邻居), 不干扰时延估计(argmax).
对比 sindy_forward(贪心阈值): P=62%/R=100%/时延9/13 (阈值一大杀真边).
"""
import time
import numpy as np
from pre2025_crc import W7, Reservoir
from delayed_pre2025 import simulate_delayed
from sindy_delay import err_terms


def sindy_argmax(X, i, reservoirs, Nc, K_max, lam):
    """对每个j独立取argmax_k gain(j,k)=k_j; 返回{gain_max, k_best}."""
    N = X.shape[1]
    base = err_terms(X, i, [], reservoirs, Nc, lam)
    gain_max, k_best = {}, {}
    for j in range(N):
        if j == i:
            continue
        bg, bk = -np.inf, 0
        for k in range(0, K_max + 1):
            e = err_terms(X, i, [(j, k)], reservoirs, Nc, lam)
            gain = base - e
            if gain > bg:
                bg, bk = gain, k
        gain_max[j] = bg
        k_best[j] = bk
    return gain_max, k_best


def main():
    t0 = time.time()
    rng = np.random.default_rng(42)
    tau = rng.uniform(0.2, 0.8, (7, 7)); np.fill_diagonal(tau, 0.0)
    X = simulate_delayed(W7, tau, t_end=1010.0, dt=0.01, eps=0.3, seed=0)[:20000]
    N = 7
    Ns, Nc, lam = 300, 30, 1e-6
    dt_s = 0.05
    K_max = int(round(tau[W7 == 1].max() / dt_s))  # 16
    reservoirs = [Reservoir(Ns, 3, 0.1, 0.3, 0.9, seed=i).run(X[:, i, :]) for i in range(N)]
    print("=" * 68)
    print(f"逐邻居argmax: 时滞唯一→每j取gain最大的k_j (K_max={K_max})")
    print(f"异构时延τ真实范围: [{tau[W7==1].min():.2f},{tau[W7==1].max():.2f}]s")
    print("=" * 68)

    # 每个振子算 gain_max(j) + k_best(j)
    all_gain = {}
    all_kbest = {}
    for i in range(N):
        all_gain[i], all_kbest[i] = sindy_argmax(X, i, reservoirs, Nc, K_max, lam)

    # 结构: gain_max 排序(取相对大的) — 用 gain_max > mean 阈值
    print(f"\n[结构] 各振子的 gain_max 排序 (gain大的=邻居):")
    for i in range(N):
        g = all_gain[i]
        ranked = sorted(g.items(), key=lambda x: -x[1])
        thr = np.mean(list(g.values()))
        nbrs = [j for j, v in ranked if v > thr]
        print(f"  振子{i}: " + "  ".join(f"j={j}(g={v:.1e},k={all_kbest[i][j]})" for j, v in ranked[:4]))

    # 结构P/R: 用 gain_max>mean 判邻居
    true = set((a, b) for a in range(N) for b in range(N) if W7[a, b] == 1)
    hat = set()
    for i in range(N):
        g = all_gain[i]; thr = np.mean(list(g.values()))
        for j, v in g.items():
            if v > thr:
                hat.add((i, j))
    TP = len(hat & true); FP = len(hat - true); FN = len(true - hat)
    P = TP/(TP+FP) if TP+FP else 0; R = TP/(TP+FN) if TP+FN else 0
    print(f"\n[结构P/R] 重构{TP+FP}边 TP={TP} FP={FP} FN={FN}  P={P:.0%} R={R:.0%}")

    # 时延: argmax k_j vs 真实
    hit = 0; n_true = 0
    print(f"\n[时延argmax] 每真边j的k_j*=argmax_k gain vs 真实:")
    for i in range(N):
        for j in range(N):
            if W7[i, j] == 1:
                n_true += 1
                k = all_kbest[i].get(j, -1)
                k_true = int(round(tau[i, j] / dt_s))
                ok = abs(k - k_true) <= 2
                hit += ok
                print(f"  ({i},{j}) {'✓' if ok else ' '}  k_j*={k:2d}({k*dt_s:.2f}s) vs 真实{k_true}({k_true*dt_s:.2f}s)")
    print(f"\n[时延命中] 真边{n_true}条中 {hit}条精确(|Δk|≤2) = {hit/n_true:.0%}")
    print(f"\n(对照: sindy_forward贪心阈值 P=62%/R=100%/时延9/13)")
    print(f"({time.time()-t0:.1f}s)")


if __name__ == "__main__":
    main()
