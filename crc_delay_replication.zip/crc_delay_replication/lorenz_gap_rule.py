"""
lorenz_gap_rule.py — 无参判据: 增益排序的"最大间隙"自动切分
=================================================================
前提: α 扫描已证明全部 10 个拓扑 AUC=1.000 (真/假边增益完全不重叠, 无任何交叉)。
      → 既然存在一个干净的分界, 就不该手调 α, 而应由数据自动找出这个间隙。

判据(最大相对间隙): 对振子 i, 将候选增益降序排 g(1)≥g(2)≥...≥g(n),
      取 m* = argmax_m  g(m)/g(m+1)   (最大的相对跌落处即真/假边分界)
      判 {j: g_j ≥ g(m*)} 为邻居。   完全无参、无需已知度/稀疏度。

对照: (a) α=0 原判据 g>mean   (b) α=0.5 固定  (c) 各拓扑最优α(oracle上界)
全部用 lorenz_alpha_scan.py 缓存的 gain pkl, 零额外算力。
"""
import os
import glob
import pickle
import numpy as np


def eval_hat(hat, true):
    TP = len(hat & true); FP = len(hat - true); FN = len(true - hat)
    P = TP / (TP + FP) if TP + FP else 0.0
    R = TP / (TP + FN) if TP + FN else 0.0
    F1 = 2 * P * R / (P + R) if P + R else 0.0
    return P, R, F1, TP, FP, FN


def gap_rule(gains, N):
    """最大相对间隙切分: 降序排列, 在 g(m)/g(m+1) 最大处切."""
    hat = set()
    for i in range(N):
        items = sorted(gains[i].items(), key=lambda x: -x[1])   # 降序
        g = np.array([v for _, v in items])
        if len(g) < 2:
            hat.add((i, items[0][0])); continue
        ratio = g[:-1] / (g[1:] + 1e-30)          # g(m)/g(m+1)
        m = int(np.argmax(ratio))                 # 切点: 取前 m+1 个
        for j, _ in items[:m + 1]:
            hat.add((i, j))
    return hat


def rule_alpha(gains, N, alpha):
    hat = set()
    for i in range(N):
        v = np.array(list(gains[i].values()))
        thr = v.mean() + alpha * v.std()
        for j, gv in gains[i].items():
            if gv > thr:
                hat.add((i, j))
    return hat


def main():
    print("=" * 100)
    print("无参判据(最大间隙) vs 阈值判据(α)   全部基于缓存 gain, 零额外算力")
    print("=" * 100)
    print(f"{'拓扑':<16}{'N':>3}{'边':>5} │{'α=0(原): P':>11}{'FP':>5}{'F1':>6} │"
          f"{'α=0.5: P':>9}{'FP':>5}{'F1':>6} │{'最大间隙: P':>11}{'R':>6}{'FP':>5}{'F1':>7}")
    print("-" * 100)
    tot = {k: [] for k in ["a0", "a5", "gap"]}
    for f in sorted(glob.glob("gains_*_N*_T*.pkl")):
        with open(f, "rb") as fh:
            D = pickle.load(fh)
        W, gains, N = D["W"], D["gains"], D["N"]
        true = set((i, j) for i in range(N) for j in range(N) if W[i, j] == 1)
        name = os.path.basename(f).replace("gains_", "").replace(".pkl", "")
        P0, R0, F0, _, FP0, _ = eval_hat(rule_alpha(gains, N, 0.0), true)
        P5, R5, F5, _, FP5, _ = eval_hat(rule_alpha(gains, N, 0.5), true)
        Pg, Rg, Fg, TPg, FPg, FNg = eval_hat(gap_rule(gains, N), true)
        tot["a0"] += [F0]; tot["a5"] += [F5]; tot["gap"] += [Fg]
        print(f"{name:<16}{N:>3}{int(W.sum()):>5} │{P0:>11.0%}{FP0:>5}{F0:>6.3f} │"
              f"{P5:>9.0%}{FP5:>5}{F5:>6.3f} │{Pg:>11.0%}{Rg:>6.0%}{FPg:>5}{Fg:>7.3f}")
    print("-" * 100)
    print(f"{'平均 F1':<24} │{np.mean(tot['a0']):>22.3f} │{np.mean(tot['a5']):>20.3f} │"
          f"{np.mean(tot['gap']):>29.3f}")
    print(f"\n→ 最大间隙判据无需任何超参数(不需已知度/稀疏度/α), "
          f"平均 F1={np.mean(tot['gap']):.3f}")


if __name__ == "__main__":
    main()
