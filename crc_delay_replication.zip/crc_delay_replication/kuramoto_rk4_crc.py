"""
kuramoto_rk4_crc.py — 时延耦合 Kuramoto 振子网络 + C-RC 重构（RK4 + 四点拉格朗日 DDE）
========================================================================================
模型（逐辺异构时延，任意有向拓扑）:
    dθ_p/dt = ω_p + Σ_q w_pq κ sin(θ_q(t − τ_pq) − θ_p(t))

观测信号: z_p = (sin θ_p, cos θ_p) → (T, N, 2)，与 SL/Lorenz 管线同形状，
直接复用 sl_l50.gains_argmax / crit_edges 与 pre2025_crc.Reservoir。

积分器与 sl_sim_rk4 同一方案（RK4 + 环形缓冲 + 四点 Lagrange 延迟插值），
状态为标量 θ，耦合为 κ sin(θ_q(t−τ) − θ_p(t))。

同步诊断: 序参量 r = |mean_j e^{iθ_j}| 的时间平均。r→1 完全同步；
r ≲ 0.5 为去同步（可辨识区）。
"""
import os
import pickle

import numpy as np

from pre2025_crc import Reservoir
import sl_l50 as S

LAM_R = 1e-6


def simulate_kuramoto(W, tau, t_end, dt, kappa, omega, seed):
    """RK4 + 四点 Lagrange。返回 TH (T, N) 相位。"""
    N = W.shape[0]
    p_idx, q_idx = np.nonzero(W)
    d_e = np.asarray(tau, float)[p_idx, q_idx] / dt
    d_e = np.maximum(d_e, 1e-9)
    M = int(np.ceil(d_e.max())) + 3

    n = int(round(t_end / dt))
    rng = np.random.default_rng(seed)
    th0 = rng.uniform(-np.pi, np.pi, N)
    buf = np.tile(th0, (M, 1))

    def delayed(a):
        idx = M - 1 - d_e + a
        i0 = np.floor(idx).astype(np.int64)
        w = idx - i0
        lm1 = w * (w - 1.0) * (w - 2.0) / (-6.0)
        l0 = (w + 1.0) * (w - 1.0) * (w - 2.0) / 2.0
        l1 = (w + 1.0) * w * (w - 2.0) / (-2.0)
        l2 = (w + 1.0) * w * (w - 1.0) / 6.0
        rows = (ptr + i0[None, :] + np.array([-1, 0, 1, 2])[:, None]) % M
        vals = buf[rows, q_idx[None, :]]                # (4, E)
        lw = np.stack([lm1, l0, l1, l2])                # (4, E)
        return np.einsum("ae,ae->e", lw, vals)

    def rhs(th, thD):
        return omega + np.bincount(
            p_idx, weights=kappa * np.sin(thD - th[p_idx]), minlength=N)

    TH = np.empty((n + 1, N))
    TH[0] = th0
    ptr = 0
    for i in range(n):
        th = TH[i]
        k1 = rhs(th, delayed(0.0))
        k2 = rhs(th + 0.5 * dt * k1, delayed(0.5))
        k3 = rhs(th + 0.5 * dt * k2, delayed(0.5))
        k4 = rhs(th + dt * k3, delayed(1.0))
        TH[i + 1] = th + (dt / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4)
        buf[ptr] = TH[i + 1]
        ptr = (ptr + 1) % M
    return TH


def order_param(TH):
    z = np.exp(1j * TH)
    return float(np.mean(np.abs(z.mean(axis=1))))


def to_signal(TH):
    return np.stack([np.sin(TH), np.cos(TH)], axis=2)   # (T,N,2)


def run(W, tau, kappa, omega, dt=0.005, sample=10, T_use=3000,
        seed=0, Ns=300, Nc=30, cache=None, keep_frac=0.4):
    """RK4 生成 → (sin,cos) → 储备池 → argmax 增益 → 指标。与 sl_crc_rk4.run 同构。"""
    N = W.shape[0]
    dts = dt * sample
    t_end = T_use * dts + 20.0
    TH = simulate_kuramoto(W, tau, t_end, dt, kappa, omega, seed)
    if not np.all(np.isfinite(TH[-1])):
        return dict(diverged=True)
    r_op = order_param(TH[int(len(TH) * keep_frac):])
    Zs = to_signal(TH)[::sample]
    if keep_frac > 0:
        Zs = Zs[int(len(Zs) * keep_frac):]
    Zs = Zs[:T_use]
    T = Zs.shape[0]
    K_max = int(np.ceil(tau[W == 1].max() / dts)) + 2

    if cache and os.path.exists(cache):
        blob = pickle.load(open(cache, "rb"))
        gains, kbests = blob["gains"], blob["kbests"]
    else:
        reservoirs = [Reservoir(Ns, 2, 0.1, 0.3, 0.9, seed=i).run(Zs[:, i, :])
                      for i in range(N)]
        gains, kbests = S.gains_argmax(Zs, reservoirs, N, Nc, K_max, LAM_R)
        if cache:
            pickle.dump({"gains": gains, "kbests": kbests}, open(cache, "wb"))

    true = {(p, q) for p in range(N) for q in range(N) if W[p, q] == 1}
    crit = {}
    for name in ["mean", "gap"]:
        hat = S.crit_edges(gains, N, W, name)
        TP = len(hat & true); FP = len(hat - true); FN = len(true - hat)
        P = TP / (TP + FP) if TP + FP else 0.0
        R = TP / (TP + FN) if TP + FN else 0.0
        crit[name] = dict(P=P, R=R, FP=FP,
                          F1=(2 * P * R / (P + R) if P + R else 0.0))
    hit, errs = 0, []
    for i in range(N):
        for j in range(N):
            if W[i, j]:
                th = kbests[i][j] * dts
                if abs(th - tau[i, j]) <= 1.5 * dts:
                    hit += 1
                    errs.append(abs(th - tau[i, j]))
    pos = np.array([gains[i][j] for (i, j) in true])
    neg = np.array([gains[i][j] for i in range(N) for j in range(N)
                    if j != i and W[i, j] == 0])
    auc = float(np.mean(pos[:, None] > neg[None, :])) if len(neg) else float("nan")
    return dict(diverged=False, r_op=r_op, K_max=K_max, T=T, dt_s=dts,
                crit=crit, hit=hit, n_true=int(W.sum()),
                merr=float(np.mean(errs)) if errs else float("nan"),
                auc=auc, pos_med=float(np.median(pos)),
                neg_med=float(np.median(neg)) if len(neg) else float("nan"),
                gains=gains, kbests=kbests)


def show(tag, r):
    if r.get("diverged"):
        print(f"{tag:<44} DIVERGED", flush=True)
        return
    m, g = r["crit"]["mean"], r["crit"]["gap"]
    print(f"{tag:<44} r={r['r_op']:5.2f} AUC={r['auc']:.3f} | "
          f"mean P={m['P']:.2f} R={m['R']:.2f} F1={m['F1']:.3f} | "
          f"gap P={g['P']:.2f} R={g['R']:.2f} F1={g['F1']:.3f} | "
          f"hit={r['hit']}/{r['n_true']} merr={r['merr']:.4f} | "
          f"pos={r['pos_med']:.2e} neg={r['neg_med']:.2e}", flush=True)


# ---- 拓扑库（N=10） ----
def ring_W(N):
    W = np.zeros((N, N), int)
    for j in range(N):
        W[j, (j - 1) % N] = 1
    return W


def star_W(N):
    W = np.zeros((N, N), int)
    for j in range(1, N):
        W[0, j] = 1
        W[j, 0] = 1
    return W


def complete_W(N):
    W = np.ones((N, N), int)
    np.fill_diagonal(W, 0)
    return W


def er_W(N, d, seed):
    return S.er_directed(N, d, seed=seed)


def make_tau(N, W, lo, hi, seed):
    rng = np.random.default_rng(seed)
    tau = rng.uniform(lo, hi, (N, N))
    np.fill_diagonal(tau, 0.0)
    return tau * W
