"""
review_c2b_dense_bigtau.py — 审稿 1.5: 稠密拓扑 + 大时延补种子 (tab:dense / tab:bigtau)
=================================================================
配置与论文一致: Δt=0.05, T=12000, Ns=300, Nc=30, λ=1e-6.
[A] 星 N=7 ε=1.5; 稠密ER N=10 d̄=6 ε=0.6  → 3种子(0-2)
[B] 大时延 W7 τ∈[3,7]: ε=1.0, 1.5        → 3种子(0-2)
判据后置: α=0 / gap / gap+回退(r_min=1.5); 时延命中≤0.1s + exact-step。
JSON: results_c2b.json
"""
import os
for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
           "NUMEXPR_NUM_THREADS"):
    os.environ[_v] = "1"
import json
import time
import numpy as np

from pre2025_crc import W7, Reservoir
from lorenz_tune import simulate
from lorenz_generalize import er
from sindy_argmax import sindy_argmax
import review_common as RC

DT_S = 0.05


def star(N):
    W = np.zeros((N, N), int)
    for i in range(1, N):
        W[0, i] = 1
        W[i, 0] = 1
    return W


def eval_criterion(gains, N, W, kind, r_min=1.5):
    true = {(i, j) for i in range(N) for j in range(N) if W[i, j] == 1}
    hat = set()
    for i in range(N):
        gm = gains[i]
        if kind == "alpha0":
            thr = float(np.mean(list(gm.values())))
            for j, v in gm.items():
                if v > thr:
                    hat.add((i, j))
            continue
        items = sorted(gm.items(), key=lambda x: -x[1])
        g = np.array([v for _, v in items])
        if len(g) < 2:
            hat.add((i, items[0][0]))
            continue
        ratio = g[:-1] / (g[1:] + 1e-30)
        m = int(np.argmax(ratio))
        if kind == "gap_fb" and ratio[m] < r_min:
            for j, _ in items:
                hat.add((i, j))
        else:
            for j, _ in items[:m + 1]:
                hat.add((i, j))
    return RC._prf(hat, true)


def auc_mw(gains, W, N):
    pos = []; neg = []
    for i in range(N):
        for j, v in gains[i].items():
            (pos if W[i, j] == 1 else neg).append(v)
    if not pos or not neg:
        return None
    pos = np.array(pos); neg = np.array(neg)
    wins = sum(np.sum(p > neg) + 0.5 * np.sum(p == neg) for p in pos)
    return float(wins / (len(pos) * len(neg)))


def run(W, eps, tau_range, seed, T_use=12000):
    N = W.shape[0]
    tau = RC.make_tau(W, tau_range, seed)
    t_end = T_use * DT_S + 20.0
    X = simulate(W, tau, t_end, dt=0.005, eps=eps, seed=seed, sample=10)[:T_use]
    s_sync, rho = RC.sync_metrics(X)
    res = [Reservoir(300, 3, 0.1, 0.3, 0.9, seed=i).run(X[:, i, :]) for i in range(N)]
    K_max = int(np.ceil(tau[W == 1].max() / DT_S)) + 2
    gains = {}
    h10 = h0 = h1 = nt = 0
    errs = []
    for i in range(N):
        gm, kb = sindy_argmax(X, i, res, 30, K_max, 1e-6)
        gains[i] = gm
        for j in range(N):
            if W[i, j] == 1:
                nt += 1
                k = kb[j]
                kt = int(round(tau[i, j] / DT_S))
                e = abs(k * DT_S - tau[i, j])
                errs.append(e)
                h10 += int(e <= 0.1)
                h0 += int(abs(k - kt) == 0)
                h1 += int(abs(k - kt) <= 1)
    out = dict(
        a0=eval_criterion(gains, N, W, "alpha0"),
        gap=eval_criterion(gains, N, W, "gap"),
        gapfb=eval_criterion(gains, N, W, "gap_fb"),
        auc=auc_mw(gains, W, N),
        hit10=h10, exact0=h0, exact1=h1, nt=nt,
        merr=float(np.mean(errs)), s_sync=s_sync, rho=rho)
    return out


def show(tag, rows):
    nt = rows[0]["nt"]
    f = lambda k, sub: np.mean([r[sub][k] for r in rows])
    aucs = [r["auc"] for r in rows if r["auc"] is not None]
    aucs = np.mean(aucs) if aucs else float("nan")
    print(f"{tag:<26} n={len(rows)} a0F1={f('F1','a0'):.3f} "
          f"gapF1={f('F1','gap'):.3f} gapfb P/R/F1="
          f"{f('P','gapfb'):.0%}/{f('R','gapfb'):.0%}/{f('F1','gapfb'):.3f} "
          f"AUC={aucs:.3f} "
          f"hit={np.mean([r['hit10'] for r in rows]):.1f}/{nt} "
          f"exact0={np.mean([r['exact0'] for r in rows]):.1f} "
          f"merr={np.mean([r['merr'] for r in rows]):.3f}s "
          f"s_sync={np.mean([r['s_sync'] for r in rows]):.2f}", flush=True)


def main():
    t0 = time.time()
    try:
        with open("results_c2b.json") as fh:
            results = json.load(fh)
    except Exception:
        results = {}
    cases = [
        ("star7_e1.5", star(7), 1.5, (0.3, 1.2)),
        ("ER10d6_e0.6", er(10, 6, 6), 0.6, (0.3, 1.2)),
        ("W7_tau37_e1.0", W7, 1.0, (3.0, 7.0)),
        ("W7_tau37_e1.5", W7, 1.5, (3.0, 7.0)),
    ]
    for name, W, eps, trng in cases:
        if name in results and len(results[name]) >= 3:
            show(f"[{name}]", results[name])
            continue
        rows = []
        for s in range(3):
            d = run(W, eps, trng, s)
            rows.append(d)
            print(f"  {name} seed{s}: gapfb F1={d['gapfb']['F1']:.3f} "
                  f"hit={d['hit10']}/{d['nt']} exact0={d['exact0']} "
                  f"merr={d['merr']:.3f}s [{time.time()-t0:.0f}s]", flush=True)
        results[name] = rows
        show(f"[{name}]", rows)
        with open("results_c2b.json", "w") as fh:
            json.dump(results, fh, indent=1, default=float)
    print(f"总耗时 {time.time()-t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
