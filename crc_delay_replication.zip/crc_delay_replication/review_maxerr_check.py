"""review_maxerr_check.py — 验证主实验"最大时延误差 0.057 s"声明
最优配置 eps=1.5, tau[0.3,1.2], Ns/Nc=300/30, T=20000, 4 seeds。
逐边计算 |tau_hat - tau|，报告每种子 max 与总体 max。
"""
import os
for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
           "NUMEXPR_NUM_THREADS"):
    os.environ[_v] = "1"
import numpy as np

from pre2025_crc import W7, Reservoir
from lorenz_tune import simulate
import review_common as RC

DT = 0.05
T = 20000

maxes = []
for seed in range(4):
    tau = RC.make_tau(W7, (0.3, 1.2), seed)
    X = simulate(W7, tau, T * DT + 20.0, dt=0.005, eps=1.5,
                 seed=seed, sample=10)[:T]
    res = [Reservoir(300, 3, 0.1, 0.3, 0.9, seed=i).run(X[:, i, :])
           for i in range(7)]
    K_max = int(np.ceil(tau[W7 == 1].max() / DT)) + 2
    errs = []
    for i in range(7):
        gm, kb = RC.argmax_eval(X, i, res, 30, K_max, 1e-6, 3)
        for j in range(7):
            if W7[i, j] == 1:
                errs.append(abs(kb[j] * DT - tau[i, j]))
    maxes.append(max(errs))
    print("seed %d: n=%d max=%.4f mean=%.4f" % (seed, len(errs), max(errs),
                                                np.mean(errs)), flush=True)
print("OVERALL max=%.4f" % max(maxes))
