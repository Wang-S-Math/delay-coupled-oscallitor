"""
review_b1_closedloop.py — 审稿 1.2: 基于重构 (Ŵ, k̂) 的闭环预测 k_eff
=================================================================
论文 §3.2(6)/§4.1 的 k_eff 此前在 oracle 设定（真边+真时延）下评估。
本脚本在同一数据上先做完整重构（argmax 增益 + 均值阈值判据），得到
(Ŵ, k̂)，再用重构项 (j, k̂_ij) 拟合读出并自由运行推演，报告:
  - 重构指标 P/R/F1、hit(≤0.1s)、exact0/exact1、merr
  - k_eff(θ=1.0/0.5): oracle 项 vs 闭环(重构)项 —— 闭环是主指标,
    oracle 是"重构完美时"的上限参照
  - 边/时延错误对推演能力的影响（若 Ŵ 少边或 k̂ 偏一步, k_eff 掉多少）
两组超参: default(Ns=300,Nc=30,λ_pred=1e-2) 与 optimized(Ns=500,Nc=60,
sp=0.1,α=0.3,ρ=0.9,λ_pred=1e-3)。数据与 §4.1 相同: W7, ε=1.5, Δt=0.05,
τ∈[0.3,1.2], seed=0, T=20000, 20 起点, S=300。
JSON: results_b1_closedloop.json
"""
import os
for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
           "NUMEXPR_NUM_THREADS"):
    os.environ[_v] = "1"
import json
import time

import numpy as np

from pre2025_crc import W7, Reservoir
import review_common as RC
from effective_horizon_opt import (N, DT_S, K_MAX, THETA_STRICT, THETA_MAIN,
                                   F_T, F_TR, F_NS, F_S, START0, STRIDE,
                                   make_data, build_reservoirs,
                                   eval_with_states, keff_of)

EPS = 1.5
TAU_RANGE = (0.3, 1.2)

CFG_DEF = dict(Ns=300, Nc=30, sparsity=0.1, alpha=0.3, rho=0.9, lam_pred=1e-2)
CFG_OPT = dict(Ns=500, Nc=60, sparsity=0.1, alpha=0.3, rho=0.9, lam_pred=1e-3)


def reconstruct(X, W, tau, reservoirs, Nc):
    """argmax 增益 + 均值阈值 → (hat, kb, metrics). 与主表判据一致."""
    K_max = int(np.ceil(tau[W == 1].max() / DT_S)) + 2
    true = {(i, j) for i in range(N) for j in range(N) if W[i, j] == 1}
    hat, kb_all, gains = set(), {}, {}
    for i in range(N):
        gm, kb = RC.argmax_eval(X, i, reservoirs, Nc, K_max, 1e-6)
        gains[i] = gm
        kb_all[i] = kb
        thr = float(np.mean(list(gm.values())))
        for j, v in gm.items():
            if v > thr:
                hat.add((i, j))
    d = RC._prf(hat, true)
    h10 = h0 = h1 = nt = 0
    errs = []
    for (i, j) in true:
        nt += 1
        k = kb_all[i][j]
        kt = int(round(tau[i, j] / DT_S))
        e = abs(k * DT_S - tau[i, j])
        errs.append(e)
        h10 += int(e <= 0.1)
        h0 += int(abs(k - kt) == 0)
        h1 += int(abs(k - kt) <= 1)
    d.update(hit10=h10, exact0=h0, exact1=h1, nt=nt,
             merr=float(np.mean(errs)))
    terms_recon = {i: [(j, kb_all[i][j]) for j in range(N)
                       if (i, j) in hat] for i in range(N)}
    return hat, kb_all, d, terms_recon


def main():
    t0 = time.time()
    X, tau = make_data(F_T)
    t_idx = np.arange(K_MAX, F_TR - 1)
    sigma = np.array([X[F_TR:, i, :].std(axis=0) for i in range(N)])
    starts = [START0 + m * STRIDE for m in range(F_NS)]

    try:
        with open("results_b1_closedloop.json") as fh:
            log = json.load(fh)
    except Exception:
        log = {}
    for tag, cfg in (("default", CFG_DEF), ("optimized", CFG_OPT)):
        if tag in log:
            print(f"\n[{tag}] (cached)", flush=True)
            continue
        print(f"\n[{tag}] {cfg}", flush=True)
        reservoirs = build_reservoirs(cfg)
        R_all = [r.run(X[:, i, :]) for i, r in enumerate(reservoirs)]
        hat, kb, drec, terms_recon = reconstruct(X, W7, tau, R_all,
                                                 cfg["Nc"])
        print(f"  重构: P={drec['P']:.0%} R={drec['R']:.0%} "
              f"hit={drec['hit10']}/{drec['nt']} exact0={drec['exact0']} "
              f"exact<=1={drec['exact1']} merr={drec['merr']:.4f}s "
              f"FP={drec['FP']} FN={drec['FN']} [{time.time()-t0:.0f}s]",
              flush=True)
        out = {"recon": drec,
               "terms_recon": {i: [[j, k] for (j, k) in terms_recon[i]]
                               for i in range(N)}}
        for mode, terms in (("oracle", {i: [(j, int(round(tau[i, j] / DT_S)))
                                            for j in range(N)
                                            if W7[i, j] == 1]
                                        for i in range(N)}),
                            ("closedloop", terms_recon)):
            res, per, _ = eval_with_states(R_all, reservoirs, X, terms,
                                           t_idx, starts, F_S, sigma,
                                           cfg["lam_pred"], cfg["Nc"])
            k10 = {i: keff_of(per[i].mean(axis=0), THETA_MAIN, F_S)
                   for i in range(N)}
            k05 = {i: keff_of(per[i].mean(axis=0), THETA_STRICT, F_S)
                   for i in range(N)}
            res["keff10_per_osc"] = k10
            res["keff05_per_osc"] = k05
            out[mode] = res
            print(f"  [{mode}] k_eff(agg)={res['keff05']}/{res['keff10']} "
                  f"一步={res['nrmse1']:.4f} 逐振子(1.0)="
                  f"{list(k10.values())} [{time.time()-t0:.0f}s]", flush=True)
        log[tag] = out
        del R_all, reservoirs
        with open("results_b1_closedloop.json", "w") as fh:
            json.dump(log, fh, indent=1, default=float)
    print(f"\n[done] {time.time()-t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
