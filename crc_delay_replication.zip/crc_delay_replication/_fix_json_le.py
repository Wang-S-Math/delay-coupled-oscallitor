# -*- coding: utf-8 -*-
import json, io
p = "results_effective_horizon_opt.json"
d = json.load(io.open(p, encoding="utf-8"))
LAM = 1.160; DT_S = 0.05
T_LE_s = 1.0/LAM; T_LE_steps = T_LE_s/DT_S
d["maxLE"] = LAM; d["T_LE_s"] = T_LE_s; d["T_LE_steps"] = T_LE_steps
d["le_note"] = ("delay-coupled network lambda_max measured ON the data-generation map "
  "(forward Euler dt=0.005, integer-rounded lags), Benettin with segment t_ren=10s > tau_max=1.2s: "
  "1.160/s (seeds 0-2: 1.134/1.174/1.172); t_ren=5s -> 1.233, t_ren=2s -> 1.355 (short-segment bias); "
  "isolated-oscillator control on same map 1.14-1.19; pairwise divergence (delta=1e-8/1e-6, scale-invariant) "
  "gives 1.3-1.4/s. Continuous DDE (RK4) is multistable/branch-dependent -> not used as unit. "
  "T_LE = 0.862 s = 17.2 steps.")
r2 = lambda x: round(x/T_LE_steps, 2)
for tag in ("optimized","default","plain_rc"):
    f = d["final"][tag]
    f["keff10_lyap"] = r2(f["keff10"]); f["keff05_lyap"] = r2(f["keff05"])
    f["keff10_per_osc_lyap"] = {k: r2(v) for k,v in f["keff10_per_osc"].items()}
    f["keff05_per_osc_lyap"] = {k: r2(v) for k,v in f["keff05_per_osc"].items()}
tr = d["traj"]
for k,pan in tr["panels"].items():
    pan["keff10_lyap"] = r2(pan["keff10"]); pan["keff05_lyap"] = r2(pan["keff05"])
for key in ("keff10","keff05"):
    tr[key+"_lyap"] = {k: r2(v) for k,v in tr[key].items()}
io.open(p,"w",encoding="utf-8").write(json.dumps(d,ensure_ascii=False,indent=1))
print("T_LE_steps =", round(T_LE_steps,2))
print("optimized keff10_lyap:", d["final"]["optimized"]["keff10_lyap"],
      "per-osc:", d["final"]["optimized"]["keff10_per_osc_lyap"])
print("default:", d["final"]["default"]["keff10_lyap"], "plain_rc:", d["final"]["plain_rc"]["keff10_lyap"])
print("traj panels:", {k: pan["keff10_lyap"] for k,pan in d["traj"]["panels"].items()})
