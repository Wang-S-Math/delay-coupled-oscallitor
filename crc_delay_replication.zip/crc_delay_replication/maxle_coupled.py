"""maxle_coupled.py — 耦合异构时延 Lorenz 网络的最大 Lyapunov 指数 (Benettin)
与 lorenz_tune.simulate 同一积分(欧拉 dt=0.005, 时延取整到步)。
参考轨迹全程分配(内存 ~MB 级), 每段 t_ren 后与扰动轨迹的距离缩回 delta 并
累加 log 增长(单切向量 Benettin)。
"""
import numpy as np

from pre2025_crc import W7
from effective_horizon_opt import make_data


def max_le_benettin(W, tau, eps, dt, t_warm=20.0, t_ren=2.0, n_ren=60,
                    seed=0, delta=1e-9):
    Nn = W.shape[0]
    rng = np.random.default_rng(seed)
    X0 = rng.uniform(1.0, 5.0, (Nn, 3))
    lags = np.zeros((Nn, Nn), int)
    for p in range(Nn):
        for q in range(Nn):
            if W[p, q] != 0:
                lags[p, q] = max(1, int(round(tau[p, q] / dt)))
    max_lag = int(lags.max()) + 1
    Wm = W.astype(float)
    ar = np.arange(Nn)
    a, b, c = 10.0, 28.0, 8.0 / 3.0

    def step(X, idx):
        x = X[idx]
        dX = np.empty_like(x)
        dX[:, 0] = a * (x[:, 1] - x[:, 0])
        dX[:, 1] = b * x[:, 0] - x[:, 1] - x[:, 0] * x[:, 2]
        dX[:, 2] = x[:, 0] * x[:, 1] - c * x[:, 2]
        lagX = X[idx - lags, ar, 0]
        coup = (Wm * (lagX - x[:, 0][:, None])).sum(axis=1)
        dX[:, 1] += eps * coup
        X[idx + 1] = x + dt * dX

    n_warm = int(round(t_warm / dt))
    n_seg = int(round(t_ren / dt))
    n_tot = max_lag + 1 + n_warm + n_ren * n_seg + 1
    X = np.tile(X0, (n_tot, 1, 1))
    idx = max_lag
    for _ in range(n_warm):
        step(X, idx)
        idx += 1
    total = 0.0
    tsum = 0.0
    for _ in range(n_ren):
        Xp = X[idx - max_lag: idx + n_seg + 1].copy()
        d0v = rng.standard_normal((Nn, 3))
        d0v /= np.linalg.norm(d0v)
        Xp[max_lag] = Xp[max_lag] + delta * d0v
        ip = max_lag
        for _ in range(n_seg):
            step(Xp, ip)
            step(X, idx)
            ip += 1
            idx += 1
        d = np.linalg.norm(Xp[ip] - X[idx])
        total += np.log(d / delta)
        tsum += t_ren
    return total / tsum


if __name__ == "__main__":
    X, tau = make_data(100)
    for s in (0, 1, 2):
        le = max_le_benettin(W7, tau, 1.5, 0.005, seed=s)
        print(f"seed={s}  coupled maxLE={le:.4f}  T_LE={1/le:.3f}s "
              f"= {1/le/0.05:.1f} steps", flush=True)
