"""
review_b3_epsscan.py — 审稿 1.4(2): ε∈[0.3,3.0] 扫描的定量数据
=================================================================
论文 §3.4(2) 目前只有文字（s_sync 恒 1.53、ρ 0→0.22、最优平台 [1.5,2.0]）。
本脚本给出双轴图所需数据: ε → (P, R, gapF1, hit/nt, merr) 与 (s_sync, ρ)。
配置与主表一致: W7, Δt=0.05, τ∈[0.3,1.2], Ns=300, Nc=30, λ=1e-6, T=12000,
种子 0-1（2 种子取均值）。JSON: results_b3_epsscan.json
"""
import os
for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
           "NUMEXPR_NUM_THREADS"):
    os.environ[_v] = "1"
import json
import time
import numpy as np

from pre2025_crc import W7, Reservoir
from lorenz_tune import simulate
import review_common as RC

EPS_LIST = [0.3, 0.6, 0.9, 1.2, 1.5, 1.8, 2.0, 2.5, 3.0]
TAU_RANGE = (0.3, 1.2)
DT_S = 0.05
T = 12000
SEEDS = (0, 1)


def run(eps, seed):
    N = W7.shape[0]
    tau = RC.make_tau(W7, TAU_RANGE, seed)
    X = simulate(W7, tau, T * DT_S + 20.0, dt=0.005, eps=eps,
                 seed=seed, sample=10)[:T]
    s_sync, rho = RC.sync_metrics(X)
    res = [Reservoir(300, 3, 0.1, 0.3, 0.9, seed=i).run(X[:, i, :])
           for i in range(N)]
    d = RC.full_pipeline(X, W7, tau, DT_S, res)
    d["s_sync"] = s_sync
    d["rho"] = rho
    return d


def main():
    t0 = time.time()
    try:
        with open("results_b3_epsscan.json") as fh:
            out = json.load(fh)
    except Exception:
        out = []
    done_eps = {r["eps"] for r in out}
    for eps in EPS_LIST:
        if eps in done_eps:
            rec = next(r for r in out if r["eps"] == eps)
            print(f"  ε={eps:<4g} (cached) P={rec['P']:.0%} hit={rec['hit']:.1f}", flush=True)
            continue
        rows = [run(eps, s) for s in SEEDS]
        m = lambda k: float(np.mean([r[k] for r in rows]))
        mm = lambda k: float(np.mean([r["mean"][k] for r in rows]))
        mg = lambda k: float(np.mean([r["gap"][k] for r in rows]))
        rec = dict(eps=eps,
                   P=mm("P"), R=mm("R"), F1=mm("F1"), gapF1=mg("F1"),
                   FP=mm("FP"),
                   hit=m("hit10"), exact0=m("exact0"), exact1=m("exact1"),
                   nt=rows[0]["nt"], merr=m("merr"),
                   s_sync=m("s_sync"), rho=m("rho"))
        out.append(rec)
        print(f"  ε={eps:<4g} P={rec['P']:.0%} R={rec['R']:.0%} "
              f"F1={rec['F1']:.3f} gapF1={rec['gapF1']:.3f} FP={rec['FP']:.1f} "
              f"hit={rec['hit']:.1f}/{rec['nt']} exact0={rec['exact0']:.1f} "
              f"merr={rec['merr']:.3f}s | s_sync={rec['s_sync']:.3f} "
              f"ρ={rec['rho']:+.3f} [{time.time()-t0:.0f}s]", flush=True)
        with open("results_b3_epsscan.json", "w") as fh:
            json.dump(out, fh, indent=1)
    print(f"总耗时 {time.time()-t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
