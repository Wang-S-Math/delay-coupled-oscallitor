"""
het_delay_structure.py — 异质时延 (每边 τ_ij 不同) + 结构联合辨识
==================================================================
真值: 7节点 13边, 每条边有独立 τ_ij (3.0~7.0, 全不同)
方法: SINDy 逐候选 (k, τ_k) 二维扫描 -> 结构 + 异质时延联合恢复
核心假设: 异质时延 -> 各驱动者的延迟态相位错开 -> 打破共线 -> 结构可辨识性改善
对照: 同质 (全边 τ=5.0) vs 异质 (每边不同 τ) 的共线性 + 结构命中率
"""
import os, json, time
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
FIGS = os.path.join(HERE, "figs"); os.makedirs(FIGS, exist_ok=True)

N = 7
# 7x7 非对称 0/1 (行=受驱 i, 列=驱动 j)
W_TRUE = np.array([
    [0, 0, 0, 1, 0, 0, 1],   # 0 <- 3,6
    [0, 0, 0, 0, 0, 1, 0],   # 1 <- 5
    [0, 1, 0, 0, 0, 1, 0],   # 2 <- 1,5
    [1, 1, 1, 0, 0, 0, 0],   # 3 <- 0,1,2
    [1, 0, 0, 1, 0, 0, 0],   # 4 <- 0,3
    [0, 1, 0, 0, 0, 0, 1],   # 5 <- 1,6
    [0, 0, 0, 0, 0, 1, 0]],  # 6 <- 5
    dtype=float)
N_EDGES = int(W_TRUE.sum())   # 13

# 异质时延矩阵 (行=受驱 i, 列=驱动 j; 0 表示无边)
TAUS_TRUE = np.array([
    [0.0, 0.0, 0.0, 3.5, 0.0, 0.0, 6.0],
    [0.0, 0.0, 0.0, 0.0, 0.0, 4.0, 0.0],
    [0.0, 5.5, 0.0, 0.0, 0.0, 4.5, 0.0],
    [3.0, 7.0, 5.0, 0.0, 0.0, 0.0, 0.0],
    [6.5, 0.0, 0.0, 3.5, 0.0, 0.0, 0.0],
    [0.0, 4.0, 0.0, 0.0, 0.0, 0.0, 5.5],
    [0.0, 0.0, 0.0, 0.0, 0.0, 6.0, 0.0]], dtype=float)
TAU_HOMO = 5.0                # 同质对照: 全边 5.0
LORENZ = dict(a=10.0, b=28.0, c=8.0 / 3.0)
EPS = 0.4                     # 中耦合 (之前共线性边界区)

# =============================================================
# 1) DDE 仿真: 异质时延 (逐边 τ_ij)
# =============================================================
def simulate_het(W, eps, TAUS, t_end, h=0.005, seed=0):
    """返回 (t, X), X (T,21)=[x0..x6,y0..y6,z0..z6]. TAUS[i,j]=边 i<-j 的时延."""
    a, b, c = LORENZ["a"], LORENZ["b"], LORENZ["c"]
    D = 3 * N
    n = int(round(t_end / h))
    tau_max = float(np.max(TAUS))
    M = int(np.ceil(tau_max / h)) + 5
    rng = np.random.default_rng(seed)
    x0 = rng.standard_normal(D) * 3.0
    x0[:N] += 1.0; x0[3*N:3*N+N] += 5.0
    buf = np.tile(x0.reshape(1, -1), (M, 1))
    ptr = 0
    t = np.linspace(0, t_end, n + 1)
    X = np.zeros((n + 1, D)); X[0] = x0

    def xdel(j, delay, a_=0.0):
        """x_j(t + a_*h - delay) 三次 Lagrange 插值."""
        idx = M - 1 - delay / h + a_
        i0 = int(np.floor(idx)); w = idx - i0
        R = (w*(w-1)*(w-2)/(-6.0) * buf[(ptr+i0-1)%M, j]
             + (w+1)*(w-1)*(w-2)/2.0 * buf[(ptr+i0)%M, j]
             + (w+1)*w*(w-2)/(-2.0) * buf[(ptr+i0+1)%M, j]
             + (w+1)*w*(w-1)/6.0 * buf[(ptr+i0+2)%M, j])
        return float(R)

    def rhs(Xv, a_=0.0):
        dX = np.zeros(D)
        for i in range(N):
            xi = Xv[3*i]; yi = Xv[3*i+1]; zi = Xv[3*i+2]
            dX[3*i] = a * (yi - xi)
            coup = 0.0
            for j in range(N):
                if W[i, j] > 0.5:
                    coup += eps * (xdel(j, TAUS[i, j], a_) - xi)
            dX[3*i+1] = b*xi - yi - xi*zi + coup
            dX[3*i+2] = xi*yi - c*zi
        return dX

    for i in range(n):
        k1 = rhs(X[i], 0.0)
        k2 = rhs(X[i] + 0.5*h*k1, 0.5)
        k3 = rhs(X[i] + 0.5*h*k2, 0.5)
        k4 = rhs(X[i] + h*k3, 1.0)
        X[i+1] = X[i] + (h/6.0)*(k1 + 2*k2 + 2*k3 + k4)
        buf[ptr] = X[i+1]; ptr = (ptr+1) % M
    return t, X

# =============================================================
# 2) 工具: 数值微分 + 延迟采样
# =============================================================
def deriv5(Z, h):
    dZ = np.zeros_like(Z); n = len(Z)
    dZ[2:n-2] = (-Z[4:n] + 8*Z[3:n-1] - 8*Z[1:n-3] + Z[0:n-4]) / (12.0*h)
    dZ[0:2] = dZ[2]; dZ[n-2:n] = dZ[n-3]
    return dZ

def delayed(col, h, tau):
    T = len(col)
    idx = np.arange(T, dtype=float) - tau / h
    i0 = np.floor(np.clip(idx, 0.0, T-1.0)).astype(int)
    w = np.clip(idx - i0, 0.0, 1.0)
    im1 = np.clip(i0-1, 0, T-1); ip1 = np.clip(i0+1, 0, T-1); ip2 = np.clip(i0+2, 0, T-1)
    return (w*(w-1)*(w-2)/(-6.0)*col[im1]
            + (w+1)*(w-1)*(w-2)/2.0*col[i0]
            + (w+1)*w*(w-2)/(-2.0)*col[ip1]
            + (w+1)*w*(w-1)/6.0*col[ip2])

# =============================================================
# 3) 共线性诊断: 延迟驱动态 x_k(t-τ_ik) 之间相关
# =============================================================
def collinearity(Xs, hs, TAUS):
    """对每个节点 i 的真实驱动者集合, 算它们延迟态之间的 off-diag |corr|."""
    results = {}
    for i in range(N):
        drivers = [k for k in range(N) if W_TRUE[i, k] > 0.5]
        if len(drivers) < 2:
            continue
        cols = [delayed(Xs[:, 3*k], hs, TAUS[i, k]) for k in drivers]
        M = np.column_stack(cols)
        C = np.corrcoef(M, rowvar=False)
        off = C[~np.eye(len(drivers), dtype=bool)]
        results[i] = dict(drivers=drivers, offmean=float(np.mean(np.abs(off))),
                          offmax=float(np.max(np.abs(off))))
    return results

# =============================================================
# 4) SINDy: 逐候选 (k, τ_k) 二维扫描
# =============================================================
def fit_node_het(X, i, h, tau_grid):
    """节点 i: 对每个候选驱动者 k, 扫 τ_k 找最优; 返回 {k: dict(tau, improvement, coeff)}."""
    dX = deriv5(X, h)
    target = dX[:, 3*i+1]
    xi = X[:, 3*i]; yi = X[:, 3*i+1]; zi = X[:, 3*i+2]
    base_cols = [np.ones_like(xi), xi, yi, xi*zi]

    # 基线 (无耦合)
    blib = np.column_stack(base_cols)
    ob, *_ = np.linalg.lstsq(blib, target, rcond=None)
    base_rss = float(np.linalg.norm(target - blib @ ob)) ** 2

    out = {}
    for k in range(N):
        if k == i:
            continue
        col = X[:, 3*k]
        best_tau, best_rss2, best_coef = None, np.inf, 0.0
        for tau in tau_grid:
            xkt = delayed(col, h, tau)
            lib = np.column_stack(base_cols + [xkt])
            om, *_ = np.linalg.lstsq(lib, target, rcond=None)
            rss2 = float(np.linalg.norm(target - lib @ om)) ** 2
            if rss2 < best_rss2:
                best_rss2, best_tau, best_coef = rss2, tau, float(om[-1])
        # 方差解释率 (improvement)
        imp = (base_rss - best_rss2) / (base_rss + 1e-30)
        out[k] = dict(tau=best_tau, improvement=imp, coeff=best_coef)
    return out, base_rss

def recover_het(X, h, tau_grid, imp_thresh=0.02):
    """结构 + 异质时延联合恢复. imp_thresh: 方差解释率阈值."""
    W_rec = np.zeros((N, N)); TAUS_rec = np.zeros((N, N))
    all_cands = {}
    for i in range(N):
        cands, base_rss = fit_node_het(X, i, h, tau_grid)
        all_cands[i] = cands
        # 选 improvement 超过阈值的 (k, tau_k)
        ranked = sorted(cands.items(), key=lambda kv: -kv[1]["improvement"])
        for k, info in ranked:
            if info["improvement"] > imp_thresh:
                W_rec[i, k] = 1.0
                TAUS_rec[i, k] = info["tau"]
    return W_rec, TAUS_rec, all_cands

# =============================================================
# 5) 主流程
# =============================================================
def main():
    t0 = time.time()
    print("=" * 78)
    print("异质时延 (每边 τ_ij 不同) + 结构联合辨识  (7节点, 13边, 13个独立时延)")
    print("=" * 78)
    print(f"真值: eps={EPS}, 边数={N_EDGES}, τ_ij 范围 = "
          f"[{TAUS_TRUE[W_TRUE>0.5].min():.1f}, {TAUS_TRUE[W_TRUE>0.5].max():.1f}] (全异质)")
    print(f"同质对照: 全边 τ={TAU_HOMO}")

    # ---------- 异质仿真 ----------
    print("\n[1] 异质时延 DDE 仿真 (h=0.005, t_end=150)...")
    t, X = simulate_het(W_TRUE, EPS, TAUS_TRUE, t_end=150.0, h=0.005, seed=0)
    Msub = 4
    sl = slice(30, -30)
    Xs = X[sl][::Msub]; hs = 0.005 * Msub
    x = Xs[:, :N]
    C0 = np.corrcoef(x - x.mean(axis=0), rowvar=False)
    print(f"    轨迹长度 T={len(Xs)}, 节点 x 同时刻 |corr| 均值="
          f"{np.mean(np.abs(C0[~np.eye(N,dtype=bool)])):.3f}")

    # ---------- 共线性对照 (同质 vs 异质) ----------
    print("\n[2] 延迟驱动态共线性 (结构可辨识性的数据层根因):")
    col_het = collinearity(Xs, hs, TAUS_TRUE)
    # 同质: 全边 TAU_HOMO
    TAUS_HOMO = np.where(W_TRUE > 0.5, TAU_HOMO, 0.0)
    col_homo = collinearity(Xs, hs, TAUS_HOMO)
    print("    节点  驱动者      异质|corr|均值  同质|corr|均值   差异")
    het_means, homo_means = [], []
    for i in range(N):
        if i in col_het and i in col_homo:
            hm = col_het[i]["offmean"]; om = col_homo[i]["offmean"]
            het_means.append(hm); homo_means.append(om)
            print(f"    node{i}  {col_het[i]['drivers']}  "
                  f"{hm:.3f}          {om:.3f}         {hm-om:+.3f}")
    if het_means:
        print(f"    => 异质 mean={np.mean(het_means):.3f} vs 同质 mean={np.mean(homo_means):.3f}")
        print(f"       (异质性{'打破' if np.mean(het_means)<np.mean(homo_means) else '未打破'}共线)")

    # ---------- SINDy 异质结构+时延恢复 ----------
    print("\n[3] SINDy 逐候选 (k, τ_k) 二维扫描 (τ_grid: 2.0~8.0 步 0.25):")
    tau_grid = np.arange(2.0, 8.01, 0.25)
    W_rec, TAUS_rec, all_cands = recover_het(Xs, hs, tau_grid, imp_thresh=0.02)

    hit = int(np.sum((W_rec > 0.5) & (W_TRUE > 0.5)))
    fake = int(np.sum((W_rec > 0.5) & (W_TRUE == 0)))
    miss = int(np.sum((W_rec == 0) & (W_TRUE > 0.5)))
    print(f"    结构: hit={hit}/{N_EDGES}, fake={fake}, miss={miss}")

    # 时延恢复 (对命中的边)
    print("\n    边 (i<-j)     真τ_ij    估τ_ij    误差")
    tau_errs = []
    for i in range(N):
        for j in range(N):
            if W_TRUE[i, j] > 0.5:
                if W_rec[i, j] > 0.5:
                    te = abs(TAUS_rec[i, j] - TAUS_TRUE[i, j])
                    tau_errs.append(te)
                    print(f"    {i}<-{j}       {TAUS_TRUE[i,j]:.2f}   {TAUS_rec[i,j]:.2f}   {te:.2f}  (命中)")
                else:
                    print(f"    {i}<-{j}       {TAUS_TRUE[i,j]:.2f}   --       --     (未命中)")
    if tau_errs:
        print(f"    命中边时延 mean|δτ| = {np.mean(tau_errs):.3f}, max|δτ| = {np.max(tau_errs):.3f}")

    # ---------- 保存 + 图 ----------
    res = dict(
        true=dict(eps=EPS, n_edges=N_EDGES, W=W_TRUE.tolist(),
                  TAUS=TAUS_TRUE.tolist(),
                  tau_range=[float(TAUS_TRUE[W_TRUE>0.5].min()), float(TAUS_TRUE[W_TRUE>0.5].max())]),
        collinearity=dict(het={str(k): v for k, v in col_het.items()},
                          homo={str(k): v for k, v in col_homo.items()},
                          het_mean=float(np.mean(het_means)) if het_means else None,
                          homo_mean=float(np.mean(homo_means)) if homo_means else None),
        structure=dict(hit=hit, fake=fake, miss=miss,
                       W_rec=W_rec.astype(int).tolist(),
                       TAUS_rec=TAUS_rec.tolist()),
        tau_errors=tau_errs,
        all_candidates={str(i): {str(k): v for k, v in c.items()} for i, c in all_cands.items()},
        elapsed_sec=time.time() - t0,
    )
    with open(os.path.join(HERE, "results_het_delay.json"), "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=2)

    make_figure(Xs, W_rec, TAUS_rec, col_het, col_homo, all_cands, res)
    print(f"\n完成 ({time.time()-t0:.1f}s) -> results_het_delay.json\n"
          f"              -> figs/fig_het_delay_structure.png")
    return res

# =============================================================
# 6) 绘图
# =============================================================
def make_figure(Xs, W_rec, TAUS_rec, col_het, col_homo, all_cands, res):
    plt.rcParams.update({"font.size": 10, "font.sans-serif": ["DejaVu Sans"]})
    fig, axes = plt.subplots(2, 3, figsize=(18, 11))
    x = Xs[:, :N]

    # (a) 轨迹
    ax = axes[0, 0]
    i = min(600, len(Xs))
    for j, col in [(0, "tab:blue"), (3, "tab:orange"), (5, "tab:green")]:
        ax.plot(np.arange(i) * 0.02, x[:i, j], lw=0.8, color=col, label=f"x_{j}")
    ax.set_xlabel("t (s)"); ax.set_ylabel("x_i(t)")
    ax.set_title("(a) Heterogeneous-delay data (chaotic, distinct nodes)")
    ax.legend(fontsize=8); ax.grid(alpha=0.3)

    # (b) 重构拓扑 (异质时延标注)
    ax = axes[0, 1]
    pos = {j: (np.cos(2*np.pi*j/N), np.sin(2*np.pi*j/N)) for j in range(N)}
    for i in range(N):
        for j in range(N):
            if W_TRUE[i, j] > 0.5:
                x1, y1 = pos[j]; x2, y2 = pos[i]
                hit = W_rec[i, j] > 0.5
                ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                            arrowprops=dict(arrowstyle="-|>",
                                color=("tab:blue" if hit else "red"), lw=2.0,
                                mutation_scale=14, shrinkA=16, shrinkB=20))
                midx, midy = (x1+x2)/2, (y1+y2)/2
                ax.text(midx, midy, f"{TAUS_TRUE[i,j]:.1f}", fontsize=7, color="gray",
                        ha="center", va="center")
    for i in range(N):
        px, py = pos[i]
        ax.plot(px, py, "o", ms=24, color="tab:orange", zorder=3)
        ax.text(px, py, str(i), ha="center", va="center", fontsize=12)
    hit = int(np.sum((W_rec>0.5)&(W_TRUE>0.5)))
    fake = int(np.sum((W_rec>0.5)&(W_TRUE==0)))
    miss = int(np.sum((W_rec==0)&(W_TRUE>0.5)))
    ax.set_xlim(-1.5, 1.5); ax.set_ylim(-1.5, 1.5); ax.set_aspect("equal"); ax.axis("off")
    ax.set_title(f"(b) Structure recovery (labels=true τ_ij)\n"
                 f"hit={hit}/{N_EDGES}  fake={fake}  miss={miss}")

    # (c) 共线性对照 (异质 vs 同质)
    ax = axes[0, 2]
    nodes = [i for i in range(N) if i in col_het and i in col_homo]
    hm = [col_het[i]["offmean"] for i in nodes]
    om = [col_homo[i]["offmean"] for i in nodes]
    xpos = np.arange(len(nodes)); wd = 0.35
    ax.bar(xpos - wd/2, hm, wd, label="hetero τ", color="tab:blue")
    ax.bar(xpos + wd/2, om, wd, label="homo τ=5.0", color="tab:orange")
    ax.set_xticks(xpos); ax.set_xticklabels([f"n{i}" for i in nodes])
    ax.set_ylabel("off-diag |corr| mean")
    ax.set_title("(c) Collinearity of delayed drivers\n(hetero breaks it?)")
    ax.legend(fontsize=8); ax.grid(alpha=0.3, axis="y")

    # (d) 逐候选 improvement 热图 (节点 i × 候选 k)
    ax = axes[1, 0]
    imp_mat = np.zeros((N, N))
    for i in range(N):
        for k in range(N):
            if k in all_cands.get(i, {}):
                imp_mat[i, k] = all_cands[i][k]["improvement"]
    im = ax.imshow(imp_mat, cmap="hot_r", aspect="auto", vmin=0, vmax=np.max(imp_mat))
    ax.set_xlabel("candidate driver k"); ax.set_ylabel("driven node i")
    ax.set_xticks(range(N)); ax.set_yticks(range(N))
    for i in range(N):
        for j in range(N):
            if W_TRUE[i, j] > 0.5:
                ax.plot(j, i, "k+", ms=12, mew=2)
    ax.set_title("(d) Per-candidate variance explained\n(+=true edge; bright=high signal)")
    fig.colorbar(im, ax=ax, fraction=0.046)

    # (e) 时延恢复散点 (真 vs 估)
    ax = axes[1, 1]
    true_taus, rec_taus = [], []
    for i in range(N):
        for j in range(N):
            if W_TRUE[i, j] > 0.5 and W_rec[i, j] > 0.5:
                true_taus.append(TAUS_TRUE[i, j]); rec_taus.append(TAUS_rec[i, j])
    ax.scatter(true_taus, rec_taus, s=60, color="tab:blue", edgecolor="k", zorder=3)
    lo = min(min(true_taus), min(rec_taus) if rec_taus else 2) - 0.3
    hi = max(max(true_taus), max(rec_taus) if rec_taus else 8) + 0.3
    ax.plot([lo, hi], [lo, hi], "k--", lw=1, label="y=x")
    ax.set_xlabel("true τ_ij"); ax.set_ylabel("recovered τ_ij")
    ax.set_title(f"(e) Delay recovery (hit edges only)\nn={len(true_taus)}")
    ax.legend(fontsize=8); ax.grid(alpha=0.3)

    # (f) 文字总结
    ax = axes[1, 2]; ax.axis("off")
    hit = int(np.sum((W_rec>0.5)&(W_TRUE>0.5)))
    lines = [
        "异质时延 + 结构联合辨识  结果",
        "",
        f"  真值: {N_EDGES} 边, τ_ij ∈ [3.0, 7.0] 全异质",
        f"  结构: hit={hit}/{N_EDGES}",
        f"  时延: mean|δτ| = {np.mean(res['tau_errors']):.3f}" if res['tau_errors'] else "  时延: 无命中边",
        "",
        f"  共线性 (延迟态 |corr| 均值):",
        f"    异质 = {res['collinearity']['het_mean']:.3f}",
        f"    同质 = {res['collinearity']['homo_mean']:.3f}",
        "",
        "  核心: 异质时延是否打破共线",
        "  -> 是则结构可辨识性改善",
    ]
    ax.text(0.05, 0.95, "\n".join(lines), transform=ax.transAxes,
            fontsize=10, verticalalignment="top",
            bbox=dict(boxstyle="round", facecolor="lightyellow", alpha=0.8))

    fig.suptitle("Heterogeneous delays (per-edge τ_ij) + structure joint inference\n"
                 f"SINDy 2D scan (k × τ),  N={N}, edges={N_EDGES}, eps={EPS}",
                 fontsize=14, y=1.00)
    fig.tight_layout()
    out = os.path.join(FIGS, "fig_het_delay_structure.png")
    fig.savefig(out, dpi=120, bbox_inches="tight")
    plt.close(fig)
    return out

if __name__ == "__main__":
    main()
