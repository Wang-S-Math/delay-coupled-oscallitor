# -*- coding: utf-8 -*-
"""
review_e3_kur15.py — E3: Kuramoto 跨规模验证 N=15(论文现仅 N=10)
==================================================================
审稿风险: 跨动力学类型验证规模偏小(SL N=5, Kuramoto N=10, Lorenz 到 N=30)。
本实验把 Kuramoto 推到 N=15, 沿用论文 N=10 的设定:
  ring(单向环) κ=8 τ~U(2.5,4.0) dt=0.005 sample=10(dt_s=0.05) T_use=3000
  ω 三档: const=2.0 / narrow=U(1.5,2.5)(rng7) / wide=U(0.5,4.0)(rng7)
  种子 0-2(与 N=10 的 6 种子稳健性同风格, 先 3 种子)
同步诊断 r_op 同时输出: 若 N=15 下 r_op 明显升高 → 同步边界随 N 收紧,
本身就是论文 §4.6/§5 需要的物理证据(正面框架: 给出边界标度而非失败)。
"""
import json
import time

import numpy as np

import kuramoto_rk4_crc as KU

CACHE = "results_e3_kur15.json"


def one(N, om_kind, seed):
    W = KU.ring_W(N)
    tau = KU.make_tau(N, W, 2.5, 4.0, seed + 1000)
    rng = np.random.default_rng(7)
    if om_kind == "const":
        omega = np.full(N, 2.0)
    elif om_kind == "narrow":
        omega = rng.uniform(1.5, 2.5, N)
    else:
        omega = rng.uniform(0.5, 4.0, N)
    return KU.run(W, tau, kappa=8.0, omega=omega, dt=0.005, sample=10,
                  T_use=3000, seed=seed,
                  cache=f"gains_e3_kur15_{om_kind}_s{seed}.pkl")


def main():
    t0 = time.time()
    res = {}
    try:
        res = json.load(open(CACHE, encoding="utf-8"))
    except FileNotFoundError:
        pass
    print("=" * 110, flush=True)
    print("E3: Kuramoto ring N=15, kappa=8, tau~U(2.5,4.0), dt_s=0.05, T_use=3000", flush=True)
    print("=" * 110, flush=True)
    for om in ["const", "narrow", "wide"]:
        rows = []
        for s in range(3):
            tag = f"N15_{om}_s{s}"
            if tag in res:
                r = res[tag]
            else:
                r = one(15, om, s)
                res[tag] = r
                json.dump(res, open(CACHE, "w", encoding="utf-8"), default=float)
            rows.append(r)
            KU.show(f"  {tag}", r)
        ok = [r for r in rows if not r.get("diverged")]
        if ok:
            print(f"  ==> N15 {om}: r_op={np.mean([r['r_op'] for r in ok]):.2f} "
                  f"AUC={np.mean([r['auc'] for r in ok]):.3f} "
                  f"gapF1={np.mean([r['crit']['gap']['F1'] for r in ok]):.3f} "
                  f"hit={np.mean([r['hit'] for r in ok]):.1f}/{ok[0]['n_true']} "
                  f"merr={np.mean([r['merr'] for r in ok]):.4f}", flush=True)
    print(f"\ntotal {time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
