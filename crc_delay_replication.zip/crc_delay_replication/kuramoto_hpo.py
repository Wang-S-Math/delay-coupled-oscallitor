"""
kuramoto_hpo.py — Kuramoto N=10 超参数优化（对照论文主实验设置）
================================================================
Stage A（便宜）: 模拟-only 同步扫描
    网格: 拓扑{ring,star,ER_d3,complete} × ω{const2.0, U(1.8,2.2), U(0.5,4.0)}
          × τ{[0.3,1.2](论文口径), [2.5,4.0]} × κ{0.5,1,2,4,8}
    输出 r_op（序参量）。r_op<0.6 = 去同步可辨识区。
Stage B: 对每个 (拓扑,ω,τ) 组取"去同步区内最大 κ"跑完整 C-RC（论文储备池参数）。
Stage C: 对 AUC 最好的一组做储备池微调 α∈{0.1,0.3,0.6} × Nc∈{30,60}。
增益缓存 pkl，判据(mean/gap)零成本。
"""
import numpy as np
import time
import pickle
import os

import kuramoto_rk4_crc as K
import sl_l50 as S
from pre2025_crc import Reservoir

N = 10
TOPOS = {
    "ring": K.ring_W(N),
    "star": K.star_W(N),
    "ER_d3": K.er_W(N, 3, seed=11),
    "complete": K.complete_W(N),
}
OMEGA = {
    "const": np.full(N, 2.0),
    "narrow": np.random.default_rng(7).uniform(1.8, 2.2, N),
    "wide": np.random.default_rng(7).uniform(0.5, 4.0, N),
}
TAUR = {"paper": (0.3, 1.2), "big": (2.5, 4.0)}
KAPPAS = [0.5, 1.0, 2.0, 4.0, 8.0]


def run_cfg(W, tau, kappa, omega, alpha=0.3, Nc=30, Ns=300, rho=0.9,
            dt=0.005, sample=10, T_use=3000, keep_frac=0.4, cache=None):
    """与 K.run 同构，但暴露储备池超参（Stage C 用）。"""
    dts = dt * sample
    t_end = T_use * dts + 20.0
    TH = K.simulate_kuramoto(W, tau, t_end, dt, kappa, omega, seed=0)
    if not np.all(np.isfinite(TH[-1])):
        return dict(diverged=True)
    r_op = K.order_param(TH[int(len(TH) * keep_frac):])
    Zs = K.to_signal(TH)[::sample]
    if keep_frac > 0:
        Zs = Zs[int(len(Zs) * keep_frac):]
    Zs = Zs[:T_use]
    K_max = int(np.ceil(tau[W == 1].max() / dts)) + 2

    if cache and os.path.exists(cache):
        blob = pickle.load(open(cache, "rb"))
        gains, kbests = blob["gains"], blob["kbests"]
    else:
        reservoirs = [Reservoir(Ns, 2, 0.1, alpha, rho, seed=i).run(Zs[:, i, :])
                      for i in range(N)]
        gains, kbests = S.gains_argmax(Zs, reservoirs, N, Nc, K_max, 1e-6)
        if cache:
            pickle.dump({"gains": gains, "kbests": kbests}, open(cache, "wb"))

    true = {(p, q) for p in range(N) for q in range(N) if W[p, q] == 1}
    crit = {}
    for name in ["mean", "gap"]:
        hat = S.crit_edges(gains, N, W, name)
        TP = len(hat & true); FP = len(hat - true); FN = len(true - hat)
        P = TP / (TP + FP) if TP + FP else 0.0
        R = TP / (TP + FN) if TP + FN else 0.0
        crit[name] = dict(P=P, R=R, FP=FP,
                          F1=(2 * P * R / (P + R) if P + R else 0.0))
    hit, errs = 0, []
    for i in range(N):
        for j in range(N):
            if W[i, j]:
                th = kbests[i][j] * dts
                if abs(th - tau[i, j]) <= 1.5 * dts:
                    hit += 1
                    errs.append(abs(th - tau[i, j]))
    pos = np.array([gains[i][j] for (i, j) in true])
    neg = np.array([gains[i][j] for i in range(N) for j in range(N)
                    if j != i and W[i, j] == 0])
    auc = float(np.mean(pos[:, None] > neg[None, :])) if len(neg) else float("nan")
    return dict(diverged=False, r_op=r_op, K_max=K_max, crit=crit, hit=hit,
                n_true=int(W.sum()), merr=float(np.mean(errs)) if errs else float("nan"),
                auc=auc, pos_med=float(np.median(pos)),
                neg_med=float(np.median(neg)) if len(neg) else float("nan"),
                gains=gains, kbests=kbests)


def show(tag, r):
    if r.get("diverged"):
        print(f"{tag:<52} DIVERGED", flush=True); return
    m, g = r["crit"]["mean"], r["crit"]["gap"]
    bf1 = max(m["F1"], g["F1"])
    print(f"{tag:<52} r={r['r_op']:5.2f} AUC={r['auc']:.3f} | "
          f"mean F1={m['F1']:.3f} gap F1={g['F1']:.3f} | "
          f"hit={r['hit']}/{r['n_true']} merr={r['merr']:.4f} | "
          f"pos={r['pos_med']:.2e} neg={r['neg_med']:.2e}", flush=True)
    return bf1


if __name__ == "__main__":
    import sys
    stage = sys.argv[1] if len(sys.argv) > 1 else "A"
    t0 = time.time()

    if stage == "A":
        print("Stage A: sync scan (simulate only, 600s)", flush=True)
        for tn, W in TOPOS.items():
            for on, om in OMEGA.items():
                for tr, (lo, hi) in TAUR.items():
                    tau = K.make_tau(N, W, lo, hi, seed=1000)
                    row = []
                    for kap in KAPPAS:
                        TH = K.simulate_kuramoto(W, tau, 600.0, 0.005, kap, om, seed=0)
                        r_op = K.order_param(TH[200:])
                        row.append(f"k={kap}:r={r_op:.2f}")
                    print(f"{tn:<8} om={on:<6} tau={tr:<5} | " + "  ".join(row)
                          + f"  [{time.time()-t0:.0f}s]", flush=True)

    elif stage == "B":
        # 对每组 (topo, omega, tau) 取去同步区内最大 κ 跑 C-RC
        print("Stage B: C-RC at max desync kappa per group", flush=True)
        results = {}
        for tn, W in TOPOS.items():
            for on, om in OMEGA.items():
                for tr, (lo, hi) in TAUR.items():
                    tau = K.make_tau(N, W, lo, hi, seed=1000)
                    best_k = None
                    for kap in KAPPAS:
                        TH = K.simulate_kuramoto(W, tau, 600.0, 0.005, kap, om, seed=0)
                        if K.order_param(TH[200:]) < 0.6:
                            best_k = kap
                    if best_k is None:
                        print(f"{tn} om={on} tau={tr}: all synced, skip", flush=True)
                        continue
                    r = run_cfg(W, tau, best_k, om,
                                cache=f"gains_kurhpo_{tn}_{on}_{tr}_k{best_k}.pkl")
                    bf1 = show(f"{tn} om={on} tau={tr} k={best_k}", r)
                    results[(tn, on, tr, best_k)] = (r["auc"], bf1 or 0.0)
        print("\n-- ranking by AUC --", flush=True)
        for kk, v in sorted(results.items(), key=lambda x: -x[1][0]):
            print(f"  {kk}: AUC={v[0]:.3f} bestF1={v[1]:.3f}", flush=True)
        print(f"[{time.time()-t0:.0f}s]", flush=True)
