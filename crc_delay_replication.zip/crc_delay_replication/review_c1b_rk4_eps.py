"""
review_c1b_rk4_eps.py — C1 续: RK4+Lagrange 连续 DDE 下的 ε 回退验证
====================================================================
C1 发现: 连续 DDE(RK4+Lagrange, 分数时延) 在 ε=1.5 时 ρ≈0.40-0.53、
s_sync≈1.39, 比 Euler+取整映射(ρ≈0.10, s_sync≈1.53)更靠近同步边界,
重构性能随之下降——这正是准则二(有效耦合以不引发同步为上限)的预测。
本脚本按准则二回退 ε: RK4 下 ε=1.0 与 0.6, 种子 0-3, 验证分离度恢复。
JSON: results_c1b_rk4eps.json (断点续跑)
"""
import os
for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
           "NUMEXPR_NUM_THREADS"):
    os.environ[_v] = "1"
import json
import time
import numpy as np

from pre2025_crc import W7, Reservoir
from sindy_argmax import sindy_argmax
from review_c1_rk4 import simulate_lorenz_rk4
import review_common as RC


def run_one(W, seed, eps):
    N = W.shape[0]
    dt_s = 0.05
    tau = RC.make_tau(W, (0.3, 1.2), seed)
    X = simulate_lorenz_rk4(W, tau, 20000 * dt_s + 20.0, dt=0.005,
                            eps=eps, seed=seed, sample=10)[:20000]
    s_sync, rho = RC.sync_metrics(X)
    reservoirs = [Reservoir(300, 3, 0.1, 0.3, 0.9, seed=i).run(X[:, i, :])
                  for i in range(N)]
    K_max = int(np.ceil(tau[W == 1].max() / dt_s)) + 2
    true = {(i, j) for i in range(N) for j in range(N) if W[i, j] == 1}
    hat = set()
    h10 = h0 = h1 = nt = 0
    errs = []
    for i in range(N):
        gm, kb = sindy_argmax(X, i, reservoirs, 30, K_max, 1e-6)
        thr = float(np.mean(list(gm.values())))
        for j, v in gm.items():
            if v > thr:
                hat.add((i, j))
        for j in range(N):
            if W[i, j] == 1:
                nt += 1
                k = kb[j]
                kt = int(round(tau[i, j] / dt_s))
                e = abs(k * dt_s - tau[i, j])
                errs.append(e)
                h10 += int(e <= 0.1)
                h0 += int(abs(k - kt) == 0)
                h1 += int(abs(k - kt) <= 1)
    d = RC._prf(hat, true)
    d.update(hit10=h10, exact0=h0, exact1=h1, nt=nt,
             merr=float(np.mean(errs)), s_sync=s_sync, rho=rho)
    return d


def main():
    t0 = time.time()
    try:
        with open("results_c1b_rk4eps.json") as fh:
            log = json.load(fh)
    except Exception:
        log = {}
    print("=" * 100, flush=True)
    print("[C1b] RK4+Lagrange 连续 DDE: 准则二 ε 回退 (ε=1.0, 0.6), 种子0-3", flush=True)
    print("=" * 100, flush=True)
    for eps in (1.0, 0.6):
        rows = []
        for s in range(4):
            key = f"eps{eps}_s{s}"
            if key in log:
                rows.append(log[key])
                continue
            d = run_one(W7, s, eps)
            rows.append(d)
            log[key] = d
            with open("results_c1b_rk4eps.json", "w") as fh:
                json.dump(log, fh, indent=1, default=float)
            print(f"  RK4 eps={eps} seed{s}: P={d['P']:.0%} R={d['R']:.0%} FP={d['FP']} "
                  f"hit={d['hit10']}/{d['nt']} exact0={d['exact0']}/{d['nt']} "
                  f"exact<=1={d['exact1']}/{d['nt']} merr={d['merr']:.4f}s "
                  f"s_sync={d['s_sync']:.2f} rho={d['rho']:+.2f} [{time.time()-t0:.0f}s]", flush=True)
        m = lambda k: np.mean([r[k] for r in rows])
        sd = lambda k: np.std([r[k] for r in rows])
        print(f"  RK4 eps={eps} 汇总: P={m('P'):.0%}+-{sd('P'):.0%} R={m('R'):.0%} "
              f"hit={m('hit10'):.1f}/{rows[0]['nt']} exact0={m('exact0'):.1f} "
              f"exact<=1={m('exact1'):.1f} merr={m('merr'):.4f}+-{sd('merr'):.4f}s "
              f"s_sync={m('s_sync'):.2f} rho={m('rho'):+.2f}", flush=True)
        print(flush=True)
    print(f"总耗时 {time.time()-t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
