"""
review_b1b_tuneexact.py — tab:tune 三配置的 exact-step match（审稿 1.3）
=================================================================
与 lorenz_tune 调参路径一致:
  baseline: ε=0.3, τ∈[0.2,0.8], Ns=300,Nc=30, 2种子
  mid     : ε=0.6, τ∈[0.3,1.2], Ns=500,Nc=60, 2种子
  optimum : ε=1.5, τ∈[0.3,1.2], Ns=300,Nc=30, 4种子
输出 hit10/exact0/exact1/merr 均值。JSON: results_b1b_tuneexact.json
"""
import os
for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
           "NUMEXPR_NUM_THREADS"):
    os.environ[_v] = "1"
import json
import time
import numpy as np

from pre2025_crc import W7, Reservoir
from lorenz_tune import simulate
import review_common as RC

DT_S = 0.05
T = 12000

CFGS = [
    ("baseline", 0.3, (0.2, 0.8), 300, 30, 2),
    ("mid", 0.6, (0.3, 1.2), 500, 60, 2),
    ("optimum", 1.5, (0.3, 1.2), 300, 30, 4),
]


def run(eps, trange, Ns, Nc, seed):
    N = W7.shape[0]
    tau = RC.make_tau(W7, trange, seed)
    X = simulate(W7, tau, T * DT_S + 20.0, dt=0.005, eps=eps,
                 seed=seed, sample=10)[:T]
    res = [Reservoir(Ns, 3, 0.1, 0.3, 0.9, seed=i).run(X[:, i, :])
           for i in range(N)]
    return RC.full_pipeline(X, W7, tau, DT_S, res, Nc=Nc)


def main():
    t0 = time.time()
    try:
        with open("results_b1b_tuneexact.json") as fh:
            out = json.load(fh)
    except Exception:
        out = {}
    for name, eps, trange, Ns, Nc, ns in CFGS:
        if name in out:
            rec = out[name]
            print(f"  {name:<9} (cached) hit={rec['hit10']:.1f} "
                  f"exact0={rec['exact0']:.1f} exact<=1={rec['exact1']:.1f} "
                  f"merr={rec['merr']:.3f}s", flush=True)
            continue
        rows = [run(eps, trange, Ns, Nc, s) for s in range(ns)]
        m = lambda k: float(np.mean([r[k] for r in rows]))
        rec = dict(hit10=m("hit10"), exact0=m("exact0"), exact1=m("exact1"),
                   merr=m("merr"), nt=rows[0]["nt"], nseed=ns)
        out[name] = rec
        print(f"  {name:<9} ε={eps} Ns/Nc={Ns}/{Nc}: hit={rec['hit10']:.1f} "
              f"exact0={rec['exact0']:.1f} exact<=1={rec['exact1']:.1f} "
              f"merr={rec['merr']:.3f}s [{time.time()-t0:.0f}s]", flush=True)
        with open("results_b1b_tuneexact.json", "w") as fh:
            json.dump(out, fh, indent=1)
    print(f"总耗时 {time.time()-t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
