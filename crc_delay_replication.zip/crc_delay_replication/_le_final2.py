# -*- coding: utf-8 -*-
import numpy as np, time
from lorenz_tune import simulate
SIG,R,B=10.0,28.0,8.0/3.0; DT=0.005; EPS=1.5
W7=np.array([[0,1,0,0,0,0,1],[1,0,1,0,0,0,0],[0,1,0,1,0,0,0],[0,0,1,0,1,0,0],
             [0,0,0,1,0,1,0],[0,0,0,0,1,0,1],[1,0,0,0,0,1,0]],float)
N=7
rng=np.random.default_rng(1000); tau=rng.uniform(0.3,1.2,size=(N,N)); tau=(tau+tau.T)/2; np.fill_diagonal(tau,0.0)
max_lag=int(np.ceil(tau.max()/DT))
def step(X,Xbuf,idx):
    Xn=X.copy()
    for i in range(N):
        acc=0.0
        for j in range(N):
            if W7[i,j]>0:
                lag=max(1,int(round(tau[i,j]/DT)))
                acc+=W7[i,j]*(Xbuf[idx-lag,j,0]-X[i,0])
        Xn[i,1]+=DT*(R-X[i,2])*X[i,0]+DT*EPS*acc
        Xn[i,0]+=DT*(SIG*(X[i,1]-X[i,0]))
        Xn[i,2]+=DT*(X[i,0]*X[i,1]-B*X[i,2])
    return Xn
def run(seed,n_run,t_warm=30.0):
    rng2=np.random.default_rng(seed); X0=rng2.uniform(1,5,size=(N,3))
    n_warm=int(t_warm/DT); n_tot=max_lag+1+n_warm+n_run+1
    Xb=np.zeros((n_tot,N,3)); Xb[:max_lag+1]=X0
    idx=max_lag
    for k in range(n_warm):
        idx+=1; Xb[idx]=step(Xb[idx-1],Xb,idx)
    return Xb,idx
t0=time.time()
# --- (2) 成对散度: seed=0 吸引子, δ=1e-8, Euler map ---
Xr,idxr=run(0,0)
X0r=Xr[idxr].copy()
rng3=np.random.default_rng(7); X0p=X0r+rng3.normal(0,1e-8,size=(N,3))
n_run=int(4.0/DT)
Xp=np.zeros((max_lag+1+n_run+1,N,3)); Xp[:max_lag+1]=X0p
ip=max_lag
ir=idxr
ds=[]
for k in range(n_run):
    ir+=1; ip+=1
    Xr[ir] if False else None
    # advance reference too (Xr buffer ends at idxr; extend)
    Xr=np.vstack([Xr,np.zeros((1,N,3))]) if ir>=len(Xr) else Xr
    Xr[ir]=step(Xr[ir-1],Xr,ir)
    Xp[ip]=step(Xp[ip-1],Xp,ip)
    if (k+1)%int(0.2/DT)==0:
        d=np.sqrt(np.mean((Xr[ir]-Xp[ip])**2))
        ds.append((round((k+1)*DT,1),d))
print("— 成对散度 (seed=0, δ=1e-8) —")
prev=None
for t,d in ds:
    rate=(np.log(d)-np.log(1e-8))/t if True else 0
    print(f"  t={t:4.1f}s  d={d:.3e}  平均增长率={rate:.3f}/s")
# 拟合
ts=np.array([t for t,_ in ds]); dd=np.log([d for _,d in ds])
A=np.polyfit(ts,dd,1); print(f"  线性拟合斜率 = {A[0]:.3f} /s")
print(f"  末段(2-4s)斜率 = {(np.log(ds[-1][1])-np.log(ds[8][1]))/(ds[-1][0]-ds[8][0]):.3f} /s")
print(f"({time.time()-t0:.0f}s)")
