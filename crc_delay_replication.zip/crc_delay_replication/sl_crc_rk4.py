"""
sl_crc_rk4.py — 标准 Stuart-Landau 时延耦合网络 + C-RC 重构（高精度 RK4 DDE 数据生成）
======================================================================================
模型（用户给的标准式，逐辺异构时延，任意有向拓扑）:
    dz_p/dt = (λ+iω_p) z_p − (1+ic)|z_p|² z_p + Σ_q w_pq κ e^{iβ} z_q(t−τ_pq)

与 sl_l50.simulate 的区别: sl_l50 用前向欧拉+时延取整，会破坏可辨识性；
本模块用 sl_sim_rk4.simulate_rk4（RK4 + 四点 Lagrange 延迟插值）。
重构管线与 Lorenz 完全一致：逐振子储备池 → 时延字典 → 逐邻居 argmax → 判据。
"""
import os
import time

import numpy as np

from pre2025_crc import Reservoir
import sl_l50 as S
import sl_sim_rk4 as K

LAM_R = 1e-6


def run(W, tau, lam, kappa, beta, c, omega, dt=0.005, sample=4, T_use=3000,
        seed=0, dt_s=None, Ns=300, Nc=30, cache=None, keep_frac=0.0,
        t_end=None, x0=None, hist=None):
    """完整一次：RK4 生成轨迹 → 下采样 → 储备池 → argmax 增益 → 指标。"""
    N = W.shape[0]
    sample_ratio = sample if dt_s is None else int(round(dt_s / dt))
    if t_end is None:
        t_end = T_use * dt * sample_ratio + 20.0
    Z = K.simulate_rk4(W, tau, t_end, dt, kappa, beta, lam, c, omega, seed,
                       x0=x0, hist=hist)
    if not np.all(np.isfinite(Z[-1])) or np.abs(Z).max() > 1e4:
        return dict(diverged=True)
    Zs = Z[::sample_ratio]
    if keep_frac > 0:
        Zs = Zs[int(len(Zs) * keep_frac):]
    Zs = Zs[:T_use]
    T = Zs.shape[0]
    dts = dt * sample_ratio
    s_sync, rho, amp = K.sync_diag(Zs, N)
    K_max = int(np.ceil(tau[W == 1].max() / dts)) + 2

    if cache and os.path.exists(cache):
        blob = __import__("pickle").load(open(cache, "rb"))
        gains, kbests = blob["gains"], blob["kbests"]
    else:
        reservoirs = [Reservoir(Ns, 2, 0.1, 0.3, 0.9, seed=i).run(Zs[:, i, :])
                      for i in range(N)]
        gains, kbests = S.gains_argmax(Zs, reservoirs, N, Nc, K_max, LAM_R)
        if cache:
            __import__("pickle").dump({"gains": gains, "kbests": kbests},
                                      open(cache, "wb"))

    true = {(p, q) for p in range(N) for q in range(N) if W[p, q] == 1}
    crit = {}
    for name in ["mean", "gap"]:
        hat = S.crit_edges(gains, N, W, name)
        TP = len(hat & true); FP = len(hat - true); FN = len(true - hat)
        P = TP / (TP + FP) if TP + FP else 0.0
        R = TP / (TP + FN) if TP + FN else 0.0
        crit[name] = dict(P=P, R=R, FP=FP, F1=(2 * P * R / (P + R) if P + R else 0.0))
    hit, errs = 0, []
    for i in range(N):
        for j in range(N):
            if W[i, j]:
                th = kbests[i][j] * dts
                if abs(th - tau[i, j]) <= 1.5 * dts:
                    hit += 1
                    errs.append(abs(th - tau[i, j]))
    return dict(diverged=False, s_sync=s_sync, rho=rho, amp=amp, K_max=K_max,
                T=T, dt_s=dts, crit=crit, hit=hit, n_true=int(W.sum()),
                merr=float(np.mean(errs)) if errs else float("nan"),
                gains=gains, kbests=kbests)


def show(tag, r):
    if r.get("diverged"):
        print(f"{tag:<40} DIVERGED", flush=True)
        return
    m, g = r["crit"]["mean"], r["crit"]["gap"]
    print(f"{tag:<40} s={r['s_sync']:5.2f} ρ={r['rho']:+.2f} |z|={r['amp']:5.3f} "
          f"| mean P={m['P']:.2f} R={m['R']:.2f} F1={m['F1']:.3f} | "
          f"gap P={g['P']:.2f} R={g['R']:.2f} F1={g['F1']:.3f} | "
          f"hit={r['hit']}/{r['n_true']} merr={r['merr']:.4f}", flush=True)


def ring_W_tau(N, tau_range=(2.5, 4.0), seed=1000):
    W = np.zeros((N, N), int)
    for j in range(N):
        W[j, (j - 1) % N] = 1
    rng = np.random.default_rng(seed)
    tv = rng.uniform(*tau_range, N)
    tau = np.zeros((N, N))
    for j in range(N):
        tau[j, (j - 1) % N] = tv[j]
    return W, tau
