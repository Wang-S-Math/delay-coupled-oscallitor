"""diag_vs_pre2025.py — 诊断: 无时延基线(PRE2025 设置) vs 时延耦合, 同一自由运行管线
======================================================================================
用户两个问题:
 1. PRE2025(Zhang&Wang) 无时延耦合 Lorenz 的 C-RC(结构已知)预测很好; 我们结构+时延
    都已知时 k_eff 却只有 ~25 步 — 用同一管线跑无时延基线对照, 定位差距来源。
 2. 折算用的 T_LE 是孤立 Lorenz(0.906) 的, 不是时延耦合系统自身的 — 用 RK4 Benettin
    重算各系统(无时延 ε=0.3 / 无时延 ε=1.5 / 时延 ε=1.5)的 maxLE, 重新折算。

对照矩阵 (同一 oracle C-RC 自由运行管线, 同一 k_eff 定义):
  A. 无时延 ε=0.3 (PRE2025 原始参数, RK4 dt=0.01, sample=5)
  B. 无时延 ε=1.5 (与主实验同耦合强度, 分离"时延"与"耦合强度"两个因素)
  C. 时延 ε=1.5 τ∈[0.3,1.2] (主实验, 欧拉 dt=0.005 sample=10)
每个系统 × {默认超参, 最优超参}。
"""
import json
import time

import numpy as np

from pre2025_crc import W7, Reservoir
from lorenz_tune import simulate as sim_delay_euler
from maxle_dde_rk4 import max_le_dde
from effective_horizon_opt import (fit_out, features, free_run, keff_of,
                                   build_reservoirs, eval_with_states)

N = 7
DT_S = 0.05
K_MAX = 26
TH05, TH10 = 0.5, 1.0
F_T, F_TR, F_NS, F_S = 20000, 15000, 20, 300
START0, STRIDE = F_TR + 500, 100

CFG_DEF = dict(Ns=300, Nc=30, sparsity=0.1, alpha=0.3, rho=0.9, lam_pred=1e-2)
CFG_BEST = dict(Ns=500, Nc=60, sparsity=0.1, alpha=0.3, rho=0.9, lam_pred=1e-3)


def sim_nodelay_rk4(W, eps, T, dt=0.01, sample=5, seed=0):
    """向量化 RK4 耦合 Lorenz(无时延): ẏ_i += ε Σ_j w_ij (x_j - x_i)."""
    Nn = W.shape[0]
    rng = np.random.default_rng(seed)
    X0 = rng.uniform(1.0, 5.0, (Nn, 3))
    n = int(round(T / dt))
    Wm = W.astype(float)
    a, b, c = 10.0, 28.0, 8.0 / 3.0

    def rhs(x):
        dX = np.empty_like(x)
        dX[:, 0] = a * (x[:, 1] - x[:, 0])
        dX[:, 1] = b * x[:, 0] - x[:, 1] - x[:, 0] * x[:, 2]
        dX[:, 2] = x[:, 0] * x[:, 1] - c * x[:, 2]
        dX[:, 1] += eps * (Wm @ x[:, 0]) - eps * Wm.sum(axis=1) * x[:, 0]
        return dX

    X = np.zeros((n + 1, Nn, 3))
    X[0] = X0
    for i in range(n):
        x = X[i]
        k1 = rhs(x)
        k2 = rhs(x + 0.5 * dt * k1)
        k3 = rhs(x + 0.5 * dt * k2)
        k4 = rhs(x + dt * k3)
        X[i + 1] = x + (dt / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4)
    return X[::sample]


def terms_nodelay():
    return {i: [(j, 0) for j in range(N) if W7[i, j] == 1] for i in range(N)}


def terms_delay(tau):
    return {i: [(j, int(round(tau[i, j] / DT_S)))
                for j in range(N) if W7[i, j] == 1] for i in range(N)}


def main():
    t0 = time.time()
    log = {"maxLE": {}, "runs": {}}

    rng = np.random.default_rng(1000)
    tau = rng.uniform(0.3, 1.2, (N, N))
    np.fill_diagonal(tau, 0.0)
    tau = tau * W7

    # ---------- maxLE: 各系统自身 (RK4+Lagrange Benettin, 长重正化段) ----------
    W1 = np.zeros((1, 1))
    t1 = np.zeros((1, 1))
    zero_tau = np.zeros((N, N))
    systems = {
        "isolated": (W1, t1, 0.0),
        "nodelay_eps0.3": (W7, zero_tau, 0.3),
        "nodelay_eps1.5": (W7, zero_tau, 1.5),
        "delay_eps1.5": (W7, tau, 1.5),
    }
    for name, (Wc, tc, ec) in systems.items():
        les = []
        for s in (0, 1, 2):
            le = max_le_dde(Wc, tc, ec, dt=0.005, t_warm=50.0, t_ren=5.0,
                            n_ren=120, seed=s)
            les.append(le)
        les = np.array(les)
        log["maxLE"][name] = dict(vals=les.tolist(), mean=float(les.mean()),
                                  std=float(les.std()),
                                  T_LE_s=float(1.0 / les.mean()),
                                  T_LE_steps=float(1.0 / les.mean() / DT_S))
        print(f"[maxLE] {name}: {np.round(les,3).tolist()} "
              f"mean={les.mean():.4f} σ={les.std():.3f} "
              f"T_LE={1/les.mean():.3f}s={1/les.mean()/DT_S:.1f}步 "
              f"({time.time()-t0:.0f}s)", flush=True)

    # ---------- 数据 ----------
    X_nd03 = sim_nodelay_rk4(W7, 0.3, F_T * DT_S + 10.0)[:F_T]
    X_nd15 = sim_nodelay_rk4(W7, 1.5, F_T * DT_S + 10.0)[:F_T]
    X_dl15 = sim_delay_euler(W7, tau, F_T * DT_S + 20.0, dt=0.005, eps=1.5,
                             seed=0, sample=10)[:F_T]
    print(f"[data] shapes {X_nd03.shape} {X_nd15.shape} {X_dl15.shape} "
          f"({time.time()-t0:.0f}s)", flush=True)

    t_idx = np.arange(K_MAX, F_TR - 1)
    starts = [START0 + m * STRIDE for m in range(F_NS)]

    datasets = {
        "nodelay_eps0.3": (X_nd03, terms_nodelay()),
        "nodelay_eps1.5": (X_nd15, terms_nodelay()),
        "delay_eps1.5": (X_dl15, terms_delay(tau)),
    }

    for ds_name, (X, terms) in datasets.items():
        sigma = np.array([X[F_TR:, i, :].std(axis=0) for i in range(N)])
        for cfg_name, cfg in (("default", CFG_DEF), ("best", CFG_BEST)):
            reservoirs = build_reservoirs(cfg)
            R_all = [r.run(X[:, i, :]) for i, r in enumerate(reservoirs)]
            out, per, wl = eval_with_states(R_all, reservoirs, X, terms,
                                            t_idx, starts, F_S, sigma,
                                            cfg["lam_pred"], cfg["Nc"])
            k10 = {i: keff_of(per[i].mean(axis=0), TH10, F_S) for i in range(N)}
            k05 = {i: keff_of(per[i].mean(axis=0), TH05, F_S) for i in range(N)}
            LE = log["maxLE"][ds_name]["mean"]
            T_LE = 1.0 / LE
            rec = dict(cfg=cfg, keff05=out["keff05"], keff10=out["keff10"],
                       nrmse1=out["nrmse1"], sat=out["sat"],
                       keff05_per=k05, keff10_per=k10,
                       keff10_lyap_sys=round(out["keff10"] * DT_S / T_LE, 2),
                       keff10_per_lyap_sys={i: round(v * DT_S / T_LE, 2)
                                            for i, v in k10.items()})
            log["runs"][f"{ds_name}|{cfg_name}"] = rec
            print(f"[run] {ds_name} {cfg_name}: k_eff={out['keff05']}/"
                  f"{out['keff10']} 一步={out['nrmse1']:.4f} 饱和={out['sat']} "
                  f"逐振子k10={list(k10.values())} "
                  f"= {rec['keff10_lyap_sys']} T_LE(系统) "
                  f"({time.time()-t0:.0f}s)", flush=True)

    json.dump(log, open("results_diag_vs_pre2025.json", "w"), indent=1)
    print(f"\n[done] {time.time()-t0:.0f}s → results_diag_vs_pre2025.json",
          flush=True)


if __name__ == "__main__":
    main()
