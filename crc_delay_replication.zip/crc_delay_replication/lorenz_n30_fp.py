"""
lorenz_n30_fp.py — 诊断 N=30 ER 网络重构中 FP=69 条假边
=================================================================
问题: 随机ER N=30 (100条真边) 用 g_j > mean 判据得 FP=69, P=59%。
      这69条到底是什么? 能不能压下去?

核心思路: 模拟+argmax 只跑一次, 保存完整 gain 字典, 之后所有判据后置扫描(零额外算力)。

四个诊断:
  [D1] 可分性 AUC: 真边增益 vs 假边增益 的 Mann-Whitney AUC。
       AUC=1.0 → 完美可分, 换个阈值就能救; AUC=0.5 → 信息上不可分(纯噪声)。
  [D2] 判据扫描:   (a) mean+α·σ  (b) top-M(取增益最大的M个邻居)
  [D3] 假边构成:   FP 边是"二阶路径"(j→m→i)的富集倍数? → 间接因果混淆
  [D4] 增益分布:   真边/假边 gain 的均值、标准差、分位数, 看阈值落在哪

用法: python lorenz_n30_fp.py [T]
"""
import os
import sys
import time
import pickle
import numpy as np
from pre2025_crc import Reservoir
from sindy_argmax import sindy_argmax
from lorenz_generalize import er
from lorenz_tune import simulate


def build(W, T, seed=0, eps=1.5, Ns=300, Nc=30, lam=1e-6, sample=10, dt_int=0.005):
    """模拟 + 逐邻居argmax, 返回完整 gain 字典(供判据后置)."""
    N = W.shape[0]
    dt_s = sample * dt_int
    rng = np.random.default_rng(seed + 1000)
    tau = rng.uniform(0.3, 1.2, (N, N))
    np.fill_diagonal(tau, 0.0)
    tau = tau * W
    t_end = T * dt_s + 20.0
    X = simulate(W, tau, t_end, dt=dt_int, eps=eps, seed=seed, sample=sample)[:T]
    res = [Reservoir(Ns, 3, 0.1, 0.3, 0.9, seed=i).run(X[:, i, :]) for i in range(N)]
    K_max = int(np.ceil(tau[W == 1].max() / dt_s)) + 2
    gains, kb = {}, {}
    for i in range(N):
        gains[i], kb[i] = sindy_argmax(X, i, res, Nc, K_max, lam)
        print(f"      i={i}/{N-1} done", flush=True)
    return dict(W=W, tau=tau, gains=gains, kb=kb, K_max=K_max, dt_s=dt_s, N=N, T=T, seed=seed)


def auc_per_i(gains, W):
    """per-振子 AUC: P(g_true > g_false). 1.0完美可分, 0.5随机."""
    N = W.shape[0]
    out = []
    for i in range(N):
        g = gains[i]
        gt = np.array([g[j] for j in g if W[i, j] == 1])
        gf = np.array([g[j] for j in g if W[i, j] == 0])
        if len(gt) == 0 or len(gf) == 0:
            continue
        # Mann-Whitney U / (n1*n2)
        diff = gt[:, None] - gf[None, :]
        out.append(float((diff > 0).mean() + 0.5 * (diff == 0).mean()))
    return float(np.mean(out)), out


def eval_hat(hat, true):
    TP = len(hat & true); FP = len(hat - true); FN = len(true - hat)
    P = TP / (TP + FP) if TP + FP else 0.0
    R = TP / (TP + FN) if TP + FN else 0.0
    F1 = 2 * P * R / (P + R) if P + R else 0.0
    return P, R, F1, TP, FP, FN


def diagnose(D, tag=""):
    W, gains, N = D["W"], D["gains"], D["N"]
    true = set((i, j) for i in range(N) for j in range(N) if W[i, j] == 1)
    n_true = len(true)
    n_cand = N * (N - 1)

    print("\n" + "=" * 92)
    print(f"[诊断] {tag}   N={N}  真边={n_true}  候选={n_cand}  非边候选={n_cand - n_true}")
    print("=" * 92)

    # ---------- D4 增益分布 ----------
    gt_all = np.array([gains[i][j] for i in gains for j in gains[i] if W[i, j] == 1])
    gf_all = np.array([gains[i][j] for i in gains for j in gains[i] if W[i, j] == 0])
    print("\n[D4] 增益分布 (量级可比性)")
    print(f"    真边 gain: mean={gt_all.mean():.3e}  std={gt_all.std():.3e}  "
          f"median={np.median(gt_all):.3e}  min={gt_all.min():.3e}")
    print(f"    假边 gain: mean={gf_all.mean():.3e}  std={gf_all.std():.3e}  "
          f"median={np.median(gf_all):.3e}  max={gf_all.max():.3e}")
    print(f"    真/假 均值比 = {gt_all.mean() / (gf_all.mean() + 1e-30):.2f}×   "
          f"(命中率下界: 假边中 gain > 真边均值 的比例 = "
          f"{(gf_all > gt_all.mean()).mean():.1%})")

    # ---------- D1 可分性 AUC ----------
    auc_m, auc_list = auc_per_i(gains, W)
    print(f"\n[D1] 真/假边可分性 AUC(per-振子平均) = {auc_m:.3f}   "
          f"(1.0=完美可分, 0.5=完全不可分)")
    print(f"     per-振子 AUC 分布: min={min(auc_list):.2f} "
          f"median={np.median(auc_list):.2f} max={max(auc_list):.2f}  "
          f"AUC=1.0 的振子数 = {sum(1 for a in auc_list if a >= 0.999)}/{len(auc_list)}")
    if auc_m > 0.95:
        print("     → 真/假边本质可分, FP=69 是【判据阈值】问题, 可调阈值修复")
    elif auc_m > 0.8:
        print("     → 大部分可分, 调阈值可显著改善但难归零")
    else:
        print("     → 真/假边增益严重重叠, 属【信息层面】不可分, 调阈值无效")

    # ---------- D2(a) mean + α·σ 扫描 ----------
    print("\n[D2a] 判据扫描: g_j > mean_i + α·σ_i")
    print(f"     {'α':>5} {'P':>6} {'R':>6} {'F1':>6} {'TP':>4} {'FP':>4} {'FN':>4}")
    best = (0, 0.0)
    for alpha in [0.0, 0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 2.0, 2.5, 3.0]:
        hat = set()
        for i in range(N):
            v = np.array(list(gains[i].values()))
            thr = v.mean() + alpha * v.std()
            for j, gv in gains[i].items():
                if gv > thr:
                    hat.add((i, j))
        P, R, F1, TP, FP, FN = eval_hat(hat, true)
        mark = " ←基线" if alpha == 0 else ""
        print(f"     {alpha:>5.2f} {P:>6.0%} {R:>6.0%} {F1:>6.3f} {TP:>4} {FP:>4} {FN:>4}{mark}")
        if F1 > best[0]:
            best = (F1, alpha)
    print(f"     → 最优 α={best[1]:.2f} (F1={best[0]:.3f}); 若最优F1仍低 → 阈值救不动, "
          f"须换 top-M 类判据")

    # ---------- D2(b) top-M ----------
    dbar = n_true / N
    print(f"\n[D2b] 判据扫描: top-M (取每个振子增益最大的 M 个候选; 真实平均出度 d̄={dbar:.2f})")
    print(f"     {'M':>5} {'P':>6} {'R':>6} {'F1':>6} {'TP':>4} {'FP':>4} {'FN':>4}")
    bestM = (0, 0)
    for M in [1, 2, 3, 4, 5, 6, 8, 10]:
        hat = set()
        for i in range(N):
            top = sorted(gains[i].items(), key=lambda x: -x[1])[:M]
            for j, _ in top:
                hat.add((i, j))
        P, R, F1, TP, FP, FN = eval_hat(hat, true)
        print(f"     {M:>5} {P:>6.0%} {R:>6.0%} {F1:>6.3f} {TP:>4} {FP:>4} {FN:>4}")
        if F1 > bestM[0]:
            bestM = (F1, M)
    print(f"     → 最优 M={bestM[1]} (F1={bestM[0]:.3f})")

    # ---------- D3 假边构成: 二阶路径富集 ----------
    W2 = ((W @ W) > 0).astype(int)          # j→m→i 两步可达
    np.fill_diagonal(W2, 0)
    W2_only = W2 * (1 - W)                  # 排除本身即一阶真边
    base_rate = W2_only.sum() / (n_cand - n_true)
    hat0 = set()
    for i in range(N):
        v = np.array(list(gains[i].values()))
        thr = v.mean()
        for j, gv in gains[i].items():
            if gv > thr:
                hat0.add((i, j))
    FP_set = hat0 - true
    if FP_set:
        fp_in2 = sum(1 for e in FP_set if W2_only[e[0], e[1]] == 1)
        rate = fp_in2 / len(FP_set)
        print(f"\n[D3] 假边构成 (基线判据 FP={len(FP_set)} 条)")
        print(f"     非边候选中'二阶路径'(j→m→i)的基础占比 = {base_rate:.1%}")
        print(f"     FP 中二阶路径占比 = {rate:.1%}  → 富集倍数 = {rate / (base_rate + 1e-12):.2f}×")
        # 反向: i→m→j
        W2r = ((W.T @ W.T) > 0).astype(int); np.fill_diagonal(W2r, 0)
        W2r_only = W2r * (1 - W)
        fp_in2r = sum(1 for e in FP_set if W2r_only[e[0], e[1]] == 1)
        print(f"     FP 中反向二阶(i→m→j)占比 = {fp_in2r / len(FP_set):.1%} "
              f"(基础 {W2r_only.sum() / (n_cand - n_true):.1%})")
        if rate / (base_rate + 1e-12) > 1.5:
            print("     → FP 显著富集于二阶路径 = 间接因果被误判为直接边 (网络直径小+强耦合)")
        else:
            print("     → FP 与二阶路径无显著关系, 更像是有限数据的统计涨落")
        # FP 的源节点度分布
        indeg = W.sum(axis=0)   # j 作为源被多少 i 连接 = 出度
        fp_src = [e[1] for e in FP_set]
        print(f"     FP 源节点平均出度 = {np.mean([indeg[j] for j in fp_src]):.2f}  "
              f"vs 全网平均出度 = {indeg.mean():.2f}"
              f"  → {'FP 偏向 hub(高度数节点)' if np.mean([indeg[j] for j in fp_src]) > indeg.mean() * 1.2 else '无 hub 偏好'}")
    return auc_m, best, bestM


def main():
    t0 = time.time()
    T = int(sys.argv[1]) if len(sys.argv) > 1 else 12000
    print("=" * 92)
    print("N=30 随机ER 假边诊断  (ε=1.5, Δt=0.05, τ∈[0.3,1.2]s, Ns=300, Nc=30)")
    print("=" * 92)
    W = er(30, 3, 5)
    print(f"拓扑: 随机ER N={W.shape[0]}  真边={int(W.sum())}  平均出度={W.sum()/30:.2f}")
    cache = "n30_gains_T%d.pkl" % T
    if os.path.exists(cache):
        with open(cache, "rb") as f:
            D = pickle.load(f)
        print(f"[缓存] 直接加载 {cache} (跳过 {T} 点模拟+argmax)", flush=True)
    else:
        print(f"\n[构建] 模拟 T={T} + 逐邻居argmax (30振子 × 29候选 × K_max) ...", flush=True)
        D = build(W, T, seed=0)
        with open(cache, "wb") as f:
            pickle.dump(D, f)
        print(f"[构建] 完成 ({time.time()-t0:.0f}s), 已保存 {cache}", flush=True)
    diagnose(D, tag=f"ER N=30, T={T}")
    print(f"\n总耗时 {time.time()-t0:.0f}s")


if __name__ == "__main__":
    main()
