"""
review_c2c_sl_kur.py — 审稿 1.5: SL / Kuramoto 补种子
=================================================================
用法: python review_c2c_sl_kur.py [sl|kur|all]

[A] SL N=5 环 (λ=-0.7 ω=2.0 c=0.5 β=0 κ=0.8 τ~U(2.5,4.0)):
    dt_s=0.02 与 0.05, 种子 0-2 (3种子). 复用 sl_crc_rk4.run.
    → results_c2c_sl.json
[B] Kuramoto ring N=10 κ=8 τ~U(2.5,4.0):
    ω identical=2 与 wide=U(0.5,4.0)(rng seed7), 新增种子 4-7
    (log_kur_robust.txt 已有种子1-3, 合并后共 7 种子). 复用 kuramoto_rk4_crc.run.
    → results_c2c_kur.json
"""
import json
import sys
import time

import numpy as np

import sl_crc_rk4 as SL
import kuramoto_rk4_crc as KU


def sl_case(dt_s, seed):
    W, tau = SL.ring_W_tau(5, (2.5, 4.0), seed=1000)
    return SL.run(W, tau, lam=-0.7, kappa=0.8, beta=0.0, c=0.5,
                  omega=2.0, dt=0.005, dt_s=dt_s, T_use=3000, seed=seed)


def kur_case(om_kind, seed):
    W = KU.ring_W(10)
    tau = KU.make_tau(10, W, 2.5, 4.0, seed + 1000)
    if om_kind == "const":
        omega = np.full(10, 2.0)
    else:
        omega = np.random.default_rng(7).uniform(0.5, 4.0, 10)
    return KU.run(W, tau, kappa=8.0, omega=omega, dt=0.005, sample=10,
                  T_use=3000, seed=seed)


def summarize(rows, key_sync):
    out = {}
    for k in ["P", "R", "F1"]:
        out[f"gap_{k}"] = (float(np.mean([r["crit"]["gap"][k] for r in rows])),
                           float(np.std([r["crit"]["gap"][k] for r in rows])))
    for k in ["hit", "merr", key_sync]:
        out[k] = (float(np.mean([r[k] for r in rows])),
                  float(np.std([r[k] for r in rows])))
    if "auc" in rows[0]:
        out["auc"] = (float(np.mean([r["auc"] for r in rows])),
                      float(np.std([r["auc"] for r in rows])))
    out["nt"] = rows[0]["n_true"]
    out["n_seeds"] = len(rows)
    return out


def save(path, results):
    with open(path, "w") as fh:
        json.dump(results, fh, indent=1, default=float)


def sl_part(t0):
    results = {}
    print("=" * 100, flush=True)
    print("[C2c-A] SL N=5 ring: λ=-0.7 ω=2.0 c=0.5 β=0 κ=0.8 τ~U(2.5,4.0), 种子0-2",
          flush=True)
    for dt_s in [0.02, 0.05]:
        rows = []
        for s in range(3):
            r = sl_case(dt_s, s)
            rows.append(r)
            g = r["crit"]["gap"]
            print(f"  SL dt_s={dt_s} seed{s}: s={r['s_sync']:.2f} ρ={r['rho']:+.2f} "
                  f"gap P/R/F1={g['P']:.2f}/{g['R']:.2f}/{g['F1']:.3f} "
                  f"hit={r['hit']}/{r['n_true']} merr={r['merr']:.4f} "
                  f"[{time.time()-t0:.0f}s]", flush=True)
        u = summarize(rows, "s_sync")
        results[f"SL_dt{dt_s}"] = u
        print(f"  [SL dt_s={dt_s}] gapF1={u['gap_F1'][0]:.3f}±{u['gap_F1'][1]:.3f} "
              f"hit={u['hit'][0]:.1f}/{u['nt']} merr={u['merr'][0]:.4f} "
              f"s={u['s_sync'][0]:.2f}", flush=True)
        save("results_c2c_sl.json", results)


KUR_OLD = {
    "const": dict(gap_F1=[1.000, 0.952, 0.952], hit=[9, 10, 8],
                  merr=[0.0391, 0.0465, 0.0524], r_op=[0.38, 0.42, 0.42],
                  auc=[1.000, 1.000, 1.000]),
    "wide": dict(gap_F1=[0.952, 1.000, 1.000], hit=[7, 9, 8],
                 merr=[0.0474, 0.0442, 0.0505], r_op=[0.43, 0.47, 0.47],
                 auc=[0.998, 1.000, 0.998]),
}


def kur_part(t0):
    results = {}
    print("=" * 100, flush=True)
    print("[C2c-B] Kuramoto ring N=10 κ=8 τ~U(2.5,4.0): 新增种子4-7 (已有1-3)", flush=True)
    for om_kind in ["const", "wide"]:
        rows = []
        for s in range(4, 8):
            r = kur_case(om_kind, s)
            rows.append(r)
            g = r["crit"]["gap"]
            print(f"  Kur {om_kind} seed{s}: r={r['r_op']:.2f} AUC={r['auc']:.3f} "
                  f"gap P/R/F1={g['P']:.2f}/{g['R']:.2f}/{g['F1']:.3f} "
                  f"hit={r['hit']}/{r['n_true']} merr={r['merr']:.4f} "
                  f"[{time.time()-t0:.0f}s]", flush=True)
        # 合并旧种子1-3（log_kur_robust.txt）
        comb = {}
        for key in ["gap_F1", "hit", "merr", "r_op", "auc"]:
            if key == "gap_F1":
                new_vals = [r["crit"]["gap"]["F1"] for r in rows]
            else:
                new_vals = [r[key] for r in rows]
            allv = np.array(KUR_OLD[om_kind][key] + list(new_vals), float)
            comb[key] = (float(allv.mean()), float(allv.std()))
        comb["nt"] = 10
        comb["n_seeds"] = int(allv.size)
        results[f"Kur_{om_kind}"] = comb
        print(f"  [Kur {om_kind}, {comb['n_seeds']}种子] "
              f"gapF1={comb['gap_F1'][0]:.3f}±{comb['gap_F1'][1]:.3f} "
              f"hit={comb['hit'][0]:.1f}/10 merr={comb['merr'][0]:.4f} "
              f"r={comb['r_op'][0]:.2f} AUC={comb['auc'][0]:.3f}", flush=True)
        save("results_c2c_kur.json", results)


def main():
    part = sys.argv[1] if len(sys.argv) > 1 else "all"
    t0 = time.time()
    if part in ("kur", "all"):
        kur_part(t0)
    if part in ("sl", "all"):
        sl_part(t0)
    print(f"总耗时 {time.time()-t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
