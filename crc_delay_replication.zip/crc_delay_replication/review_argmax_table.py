"""
review_argmax_table.py — tab:argmax 六候选增益表（可复现重制）
================================================================
配置与 tab:tune 基线行一致（T=20000）：
eps=0.3, tau[0.2,0.8], Ns=300, Nc=30, seed=0；振子 i=0（1 号）。
输出全部 6 个候选邻居的 gain_max[j]、k*[j]、真实边标记、均值阈值判定。
JSON: results_argmax_table.json
"""
import os
for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
           "NUMEXPR_NUM_THREADS"):
    os.environ[_v] = "1"
import json
import time
import numpy as np

from pre2025_crc import W7, Reservoir
from lorenz_tune import simulate
import review_common as RC

DT_S = 0.05
T = 20000
EPS = 0.3
TRANGE = (0.2, 0.8)
SEED = 0


def main():
    t0 = time.time()
    N = W7.shape[0]
    tau = RC.make_tau(W7, TRANGE, SEED)
    X = simulate(W7, tau, T * DT_S + 20.0, dt=0.005, eps=EPS,
                 seed=SEED, sample=10)[:T]
    res = [Reservoir(300, 3, 0.1, 0.3, 0.9, seed=i).run(X[:, i, :])
           for i in range(N)]
    K_max = int(np.ceil(tau[W7 == 1].max() / DT_S)) + 2
    gm, kb = RC.argmax_eval(X, 0, res, 30, K_max, 1e-6)
    mean_thr = float(np.mean(list(gm.values())))
    out = {"seed": SEED, "eps": EPS, "tau_range": list(TRANGE), "T": T,
           "K_max": K_max, "mean_thr": mean_thr, "candidates": {}}
    for j in range(N):
        if j == 0:
            continue
        out["candidates"][j + 1] = {
            "gain": float(gm[j]),
            "kbest": int(kb[j]),
            "true_edge": bool(W7[0, j] == 1),
            "decision": bool(gm[j] > mean_thr),
            "tau_true": float(tau[0, j]) if W7[0, j] == 1 else None,
        }
    print(json.dumps(out, indent=1), flush=True)
    with open("results_argmax_table.json", "w") as fh:
        json.dump(out, fh, indent=1)
    print(f"total {time.time()-t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
