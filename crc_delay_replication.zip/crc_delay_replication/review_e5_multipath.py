"""
review_e5_multipath.py — E5: 多径/分布式时延下 argmax 单时延先验的行为 (软肋三)
==============================================================================
场景: W7 拓扑, eps=1.5, dt_s=0.05, tau1~U(0.3,1.2) (主路径, 幅度1).
  每条真边额外加第二条耦合路径, 幅度 alpha=0.5:
    S0  control   : 无第二路径 (对照)
    S1  far-long  : tau2 = tau1 + 0.45 (次路径更晚)
    S2  far-short : tau2 = tau1 - 0.30 (次路径更早, clip>=0.15)
    S3  near      : tau2 = tau1 + 0.15 (次路径仅差3步, 最严苛)
观测: (a) 结构 P/R (mean阈值); (b) k_best 是否锁定主路径 k1;
      (c) gain(k) 曲线在 k2 处是否出现可辨次峰 (双峰=分布式时延指纹).
T=6000, 种子0-1. 缓存 gains_e5_{sc}_s{seed}.pkl.
"""
import json
import pickle
import time
import numpy as np
from pre2025_crc import W7, Reservoir
from sindy_delay import err_terms

DT_INT, SAMPLE, T_USE, EPS = 0.005, 10, 6000, 1.5
DT_S = SAMPLE * DT_INT
NS, NC, LAM = 300, 30, 1e-6


def simulate_multi(W, paths, t_end, dt=DT_INT, eps=EPS, seed=0, sample=SAMPLE):
    """paths: list of (p,q,tau,amp). 耦合: ydot_i += eps*sum_paths amp*w*[x_j(t-tau)-x_i]."""
    N = W.shape[0]
    rng = np.random.default_rng(seed)
    X0 = rng.uniform(1.0, 5.0, (N, 3))
    n = int(round(t_end / dt))
    max_lag = int(max(round(tau / dt) for (_, _, tau, _) in paths)) + 1
    ar = np.arange(N)
    X = np.tile(X0, (n + 1 + max_lag, 1, 1))
    idx = max_lag
    a, b, c = 10.0, 28.0, 8.0 / 3.0
    dX = np.empty_like(X[0])
    for _ in range(n):
        x = X[idx]
        dX[:, 0] = a * (x[:, 1] - x[:, 0])
        dX[:, 1] = b * x[:, 0] - x[:, 1] - x[:, 0] * x[:, 2]
        dX[:, 2] = x[:, 0] * x[:, 1] - c * x[:, 2]
        coup = np.zeros(N)
        for (p, q, tau, amp) in paths:
            lag = max(1, int(round(tau / dt)))
            coup[p] += amp * W[p, q] * (X[idx - lag, q, 0] - x[p, 0])
        dX[:, 1] += eps * coup
        X[idx + 1] = x + dt * dX
        idx += 1
    return X[max_lag + 1:max_lag + 1 + n:sample]


def make_paths(W, tau1, sc, alpha=0.5):
    paths = []
    for p in range(W.shape[0]):
        for q in range(W.shape[1]):
            if W[p, q] != 1:
                continue
            t1 = tau1[p, q]
            paths.append((p, q, t1, 1.0))
            if sc == 'S0':
                continue
            if sc == 'S1':
                t2 = t1 + 0.45
            elif sc == 'S2':
                t2 = max(0.15, t1 - 0.30)
            else:
                t2 = t1 + 0.15
            paths.append((p, q, t2, alpha))
    return paths


def one(sc, seed):
    t0 = time.time()
    N = W7.shape[0]
    rng = np.random.default_rng(seed + 1000)
    tau1 = rng.uniform(0.3, 1.2, (N, N)); np.fill_diagonal(tau1, 0.0)
    tau1 = tau1 * W7
    paths = make_paths(W7, tau1, sc)
    t_end = T_USE * DT_S + 20.0
    X = simulate_multi(W7, paths, t_end, seed=seed)[:T_USE]
    xs = X[:, :, 0]
    ref = np.sqrt(np.mean(xs ** 2))
    pair = [np.sqrt(np.mean((xs[:, i] - xs[:, j]) ** 2))
            for i in range(N) for j in range(i + 1, N)]
    sync = 1.0 - np.mean(pair) / (ref + 1e-12)
    reservoirs = [Reservoir(NS, 3, 0.1, 0.3, 0.9, seed=i).run(X[:, i, :])
                  for i in range(N)]
    tau_max = max(tau for (_, _, tau, _) in paths)
    K_max = int(np.ceil(tau_max / DT_S)) + 2
    gains = {}; kb = {}
    for i in range(N):
        base = err_terms(X, i, [], reservoirs, NC, LAM)
        gains[i] = {}; kb[i] = {}
        for j in range(N):
            if j == i:
                continue
            curve = [base - err_terms(X, i, [(j, k)], reservoirs, NC, LAM)
                     for k in range(K_max + 1)]
            gains[i][j] = curve
            kb[i][j] = int(np.argmax(curve))
    with open(f'gains_e5_{sc}_s{seed}.pkl', 'wb') as f:
        pickle.dump({'W': W7, 'tau1': tau1, 'paths': paths, 'gains': gains,
                     'kb': kb, 'K_max': K_max, 'dt_s': DT_S, 'N': N,
                     'T': T_USE, 'seed': seed}, f)
    # 结构: mean 阈值
    true = set((p, q) for p in range(N) for q in range(N) if W7[p, q] == 1)
    hat = set()
    for i in range(N):
        gm = {j: max(c) for j, c in gains[i].items()}
        thr = np.mean(list(gm.values()))
        for j, v in gm.items():
            if v > thr:
                hat.add((i, j))
    TP = len(hat & true); FP = len(hat - true); FN = len(true - hat)
    P = TP / (TP + FP) if TP + FP else 0.0
    R = TP / (TP + FN) if TP + FN else 0.0
    # 时延: k_best vs 主路径 k1; 次峰检测
    n_true = 0; hit1 = 0; hit2 = 0; merr = []
    peak2 = 0; n_true_edges = 0
    for i in range(N):
        for j in range(N):
            if W7[i, j] != 1:
                continue
            n_true_edges += 1
            k = kb[i][j]; k1 = int(round(tau1[i, j] / DT_S))
            n_true += 1
            hit1 += abs(k - k1) <= 1
            hit2 += abs(k - k1) <= 2
            merr.append(abs(k - k1) * DT_S)
            if sc != 'S0':
                t2 = [tau for (p, q, tau, a) in paths if p == i and q == j and a == 0.5][0]
                k2 = int(round(t2 / DT_S))
                c = gains[i][j]
                lo = max(0, k2 - 2); hi = min(len(c) - 1, k2 + 2)
                local = max(c[lo:hi + 1])
                # 次峰: k2 邻域局部极大 且 高于该曲线最大增益的 20%
                is_local_max = (local >= c[max(0, k2 - 3)] and
                                local >= c[min(len(c) - 1, k2 + 3)])
                peak2 += (is_local_max and local > 0.2 * max(c))
    r = dict(sc=sc, seed=seed, sync=round(float(sync), 3),
             P=round(P, 3), R=round(R, 3), FP=FP,
             hit1=hit1, hit2=hit2, n=n_true,
             merr=round(float(np.mean(merr)), 4),
             peak2=peak2, n_edges=n_true_edges,
             secs=round(time.time() - t0, 1))
    print(json.dumps(r), flush=True)
    return r


def main():
    res = []
    for sc in ['S0', 'S1', 'S2', 'S3']:
        for seed in [0, 1]:
            res.append(one(sc, seed))
    with open('results_e5_multipath.json', 'w') as f:
        json.dump(res, f, indent=1)
    print('\n=== 汇总 ===')
    for sc in ['S0', 'S1', 'S2', 'S3']:
        rs = [r for r in res if r['sc'] == sc]
        print(f"{sc}: P={np.mean([r['P'] for r in rs]):.2f} "
              f"R={np.mean([r['R'] for r in rs]):.2f} "
              f"hit1={sum(r['hit1'] for r in rs)}/{sum(r['n'] for r in rs)} "
              f"merr={np.mean([r['merr'] for r in rs]):.4f} "
              f"peak2={sum(r['peak2'] for r in rs)}/{sum(r['n_edges'] for r in rs)}")


if __name__ == "__main__":
    main()
