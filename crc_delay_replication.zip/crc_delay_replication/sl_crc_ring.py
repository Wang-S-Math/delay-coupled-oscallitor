"""
sl_crc_ring.py — 旧 N=5 SL 时滞环系统 + 本文 C-RC 方法（储备池+argmax增益）
=============================================================================
目的：检验 C-RC 能否在 SL 上重构。旧 sl_ring_reconstruct.py 用 SINDy-DDE
在 "近 Hopf 临界 + 保留瞬态" 的数据上成功（struct_ok=True, tau err 0.0015）。
本脚本换成本文的 C-RC 判据，做 A/B 对照：
  A) 保留瞬态的数据（多行波模混合 -> 非周期）  -> 预期可辨识
  B) 丢弃瞬态、只留稳态行波（准周期）          -> 预期退化（基线MSE~0, AUC~0.5）
系统（复用 sl_ring_reconstruct 的 RK4 DDE 积分器，异构入边时延）：
  dz_j/dt = (lam+i*om)z_j - (1+ic)|z_j|^2 z_j + kappa e^{i beta} z_{(j-1)%N}(t-taus[j])
参数沿用旧工作点：om=2.0, c=0.5, kappa=0.8, beta=0, lam=-0.7（近双Hopf, 瞬态长）
时延：异构 taus ~ U(2.5,4.0)（旧单值 3.5 的异构化）
"""
import os, sys, time
import numpy as np
from pre2025_crc import Reservoir
import sl_ring_reconstruct as R

Ns, Nc, lam_r = 300, 30, 1e-6


def make_traj(N, lam, taus, t_end=60.0, dt=0.00125, Msub=16, seed=0):
    """RK4 DDE 积分 + 下采样。返回 (Z2, dt_s)：Z2 形状 (T, N, 2)。"""
    R.N = N
    R.ID.update(omega=2.0, c=0.5, kappa=0.8, beta=0.0)
    t, Z = R.simulate_sl_ring_het(lam, taus, t_end=t_end, dt=dt, seed=seed)
    sl = slice(3, -3)
    Z2 = Z[sl][::Msub]
    dt_s = dt * Msub
    return Z2.reshape(Z2.shape[0], N, 2), dt_s


def sync_diag(Z, N):
    """状态距离同步指标（与 sl_l50 同口径）。"""
    d, s = 0.0, 0.0
    for i in range(N):
        for j in range(i + 1, N):
            d += np.mean(np.sum((Z[:, i, :] - Z[:, j, :]) ** 2, axis=1))
    m = np.mean(np.sum((Z - Z.mean(axis=1, keepdims=True)) ** 2, axis=2))
    return float(np.sqrt(d / (N * (N - 1) / 2) / (2 * m)))


def crc_gains(Z2, N, dt_s, tau_max):
    """C-RC：逐节点储备池 + 逐候选邻居 argmax 增益（Gram 技巧，同 sl_l50）。"""
    reservoirs = [Reservoir(Ns, 2, 0.1, 0.3, 0.9, seed=i).run(Z2[:, i, :]) for i in range(N)]
    K_max = int(np.ceil(tau_max / dt_s)) + 2
    pad = K_max + 1
    T = Z2.shape[0]
    gains, kbests, bases = {}, {}, []
    for i in range(N):
        U = Z2[pad + 2:T, i, :]                    # 目标 z_i(t+1)
        Ts = U.shape[0]
        Ri = reservoirs[i][pad:pad + Ts, :]
        Gii = Ri.T @ Ri
        bii = Ri.T @ U
        u2 = float(np.sum(U * U))
        D0 = Ri.shape[1]
        Ab = Gii + lam_r * np.eye(D0)
        wb = np.linalg.solve(Ab, bii)
        base = (u2 - 2 * np.sum(bii * wb) + np.sum(wb * (Ab @ wb))
                - lam_r * np.sum(wb * wb)) / (2 * Ts)
        bases.append(base)
        gm, kb = {}, {}
        for j in range(N):
            if j == i:
                continue
            bg, bk = -np.inf, 0
            for k in range(K_max + 1):
                Rj = reservoirs[j][pad - k:pad - k + Ts, :Nc]
                Gij = Ri.T @ Rj
                D = D0 + Nc
                M = np.zeros((D, D))
                M[:D0, :D0] = Gii
                M[:D0, D0:] = Gij
                M[D0:, :D0] = Gij.T
                M[D0:, D0:] = Rj.T @ Rj
                M[np.diag_indices(D)] += lam_r
                b = np.vstack([bii, Rj.T @ U])
                w = np.linalg.solve(M, b)
                sse = u2 - 2 * float(np.sum(b * w)) + float(np.sum(w * (M @ w))) \
                    - lam_r * float(np.sum(w * w))
                g = base - sse / (2 * Ts)
                if g > bg:
                    bg, bk = g, k
            gm[j], kb[j] = bg, bk
        gains[i], kbests[i] = gm, kb
    return gains, kbests, float(np.mean(bases)), K_max, dt_s


def auc_and_crit(gains, kbests, Wtrue, taus, dt_s, N):
    """AUC（真/假边最大增益可分性）+ mean/gap 判据 + 时延命中。"""
    gt, gf, sel = [], [], {}
    for i in range(N):
        g = gains[i]
        vals = sorted(g.values(), reverse=True)
        # gap 判据：最大相邻比切点（带无间隙回退）
        ratios = [vals[m] / (vals[m + 1] + 1e-18) for m in range(len(vals) - 1)]
        mstar = int(np.argmax(ratios))
        mgap = mstar + 1 if ratios[mstar] >= 1.5 else len(vals)
        mean_g = float(np.mean(vals))
        rec_mean = {j for j, v in g.items() if v > mean_g}
        rec_gap = set()
        svals = sorted(g.items(), key=lambda kv: -kv[1])
        for m in range(mgap):
            rec_gap.add(svals[m][0])
        sel[i] = (rec_mean, rec_gap)
        for j, v in g.items():
            (gt if Wtrue[i, j] else gf).append(v)
    # AUC (Mann-Whitney)
    if gt and gf:
        u = sum(1.0 for a in gt for b in gf if a > b) + 0.5 * sum(1.0 for a in gt for b in gf if a == b)
        auc = u / (len(gt) * len(gf))
    else:
        auc = float("nan")
    n_true = int(Wtrue.sum())
    out = {}
    for name in ("mean", "gap"):
        tp = sum(1 for i in range(N) for j in sel[i][0 if name == "mean" else 1] if Wtrue[i, j])
        fp = sum(1 for i in range(N) for j in sel[i][0 if name == "mean" else 1] if not Wtrue[i, j])
        P = tp / max(tp + fp, 1)
        Rc = tp / n_true
        out[name] = dict(P=P, R=Rc, F1=2 * P * Rc / max(P + Rc, 1e-9), tp=tp, fp=fp)
    hit, errs = 0, []
    for i in range(N):
        for j in range(N):
            if Wtrue[i, j]:
                kb = kbests[i][j]
                tau_hat = kb * dt_s
                if abs(tau_hat - taus[i, j]) <= 1.5 * dt_s:
                    hit += 1
                    errs.append(abs(tau_hat - taus[i, j]))
    return auc, out, hit, n_true, float(np.mean(errs)) if errs else float("nan")


def run_case(tag, N, lam, taus_vec, taus, Wtrue, keep_frac=0.0, t_end=60.0, seed=0):
    """keep_frac=0 保留全部（含瞬态）；keep_frac=0.6 丢弃前60%（稳态对照）。"""
    Z2, dt_s = make_traj(N, lam, taus_vec, t_end=t_end, seed=seed)
    n0 = int(Z2.shape[0] * keep_frac)
    Z2 = Z2[n0:]
    s = sync_diag(Z2, N)
    tau_max = taus[Wtrue > 0].max()
    gains, kbests, base, K_max, dt_s = crc_gains(Z2, N, dt_s, tau_max)
    auc, crit, hit, n_true, merr = auc_and_crit(gains, kbests, Wtrue, taus, dt_s, N)
    m, g = crit["mean"], crit["gap"]
    print(f"[{tag}] N={N} T={Z2.shape[0]} s_sync={s:.2f} baseMSE={base:.2e} AUC={auc:.3f} | "
          f"mean P={m['P']:.2f} R={m['R']:.2f} F1={m['F1']:.3f} | gap F1={g['F1']:.3f} | "
          f"hit={hit}/{n_true} merr={merr:.3f}", flush=True)
    return dict(auc=auc, mean=m, gap=g, hit=hit, n_true=n_true, merr=merr, base=base, s=s)


if __name__ == "__main__":
    t0 = time.time()
    N = 5
    lam = -0.7
    rng = np.random.default_rng(1000)
    Wtrue = np.zeros((N, N), int)
    for j in range(N):
        Wtrue[j, (j - 1) % N] = 1
    taus_vec = rng.uniform(2.5, 4.0, N)          # 节点 j 的入边时延
    taus = taus_vec[:, None] * Wtrue             # (N,N) 矩阵形式供评估
    print("SL ring N=5, lam=-0.7 (near double-Hopf), taus~U(2.5,4) on ring edges")
    print("A) 保留瞬态（旧成功配方）+ C-RC 方法")
    run_case("A-transient", N, lam, taus_vec, taus, Wtrue, keep_frac=0.0)
    print("B) 丢弃前60%瞬态、只留稳态行波 + C-RC 方法")
    run_case("B-steady", N, lam, taus_vec, taus, Wtrue, keep_frac=0.6)
    print("%.1fs" % (time.time() - t0))
