"""
review_c2a_generalize.py — 审稿 1.5: 泛化矩阵补种子 (tab:gen 六拓扑)
=================================================================
配置与论文表一致: ε=1.5, Δt=0.05, τ∈[0.3,1.2], Ns=300, Nc=30, λ=1e-6.
种子: N=7 三个拓扑 4种子(0-3); ER N=15/20/30 各 3种子(0-2)。
输出 mean±std: P/R/F1(mean判据与gap判据)、时延命中≤0.1s、exact0/exact1、merr。
JSON: results_c2a.json
"""
import os
for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
           "NUMEXPR_NUM_THREADS"):
    os.environ[_v] = "1"
import json
import time
import numpy as np

from pre2025_crc import W7, Reservoir
from lorenz_tune import simulate
from lorenz_generalize import er, ring
import review_common as RC

EPS = 1.5
TAU_RANGE = (0.3, 1.2)
DT_S = 0.05


def run(W, seed, T_use):
    N = W.shape[0]
    tau = RC.make_tau(W, TAU_RANGE, seed)
    t_end = T_use * DT_S + 20.0
    X = simulate(W, tau, t_end, dt=0.005, eps=EPS, seed=seed, sample=10)[:T_use]
    s_sync, rho = RC.sync_metrics(X)
    res = [Reservoir(300, 3, 0.1, 0.3, 0.9, seed=i).run(X[:, i, :]) for i in range(N)]
    d = RC.full_pipeline(X, W, tau, DT_S, res)
    d["s_sync"] = s_sync
    d["rho"] = rho
    return d


def summarize(rows, nt):
    g = lambda k, sub: np.mean([r[sub][k] for r in rows])
    s = lambda k, sub: np.std([r[sub][k] for r in rows])
    out = {}
    for sub in ["mean", "gap"]:
        for k in ["P", "R", "F1", "FP"]:
            out[f"{sub}_{k}"] = (float(g(k, sub)), float(s(k, sub)))
    for k in ["hit10", "exact0", "exact1", "merr"]:
        out[k] = (float(np.mean([r[k] for r in rows])),
                  float(np.std([r[k] for r in rows])))
    out["nt"] = nt
    return out


def show(tag, rows, nt):
    u = summarize(rows, nt)
    print(f"{tag:<22} n={len(rows)} P={u['mean_P'][0]:.0%}±{u['mean_P'][1]:.0%} "
          f"R={u['mean_R'][0]:.0%} F1={u['mean_F1'][0]:.3f} | "
          f"gapF1={u['gap_F1'][0]:.3f} | hit={u['hit10'][0]:.1f}/{nt} "
          f"exact0={u['exact0'][0]:.1f} exact<=1={u['exact1'][0]:.1f} "
          f"merr={u['merr'][0]:.3f}s s_sync={np.mean([r['s_sync'] for r in rows]):.2f}",
          flush=True)
    return u


def main():
    t0 = time.time()
    try:
        with open("results_c2a_rows.json") as fh:
            raw = json.load(fh)
    except Exception:
        raw = {}
    cases = [
        ("W7", W7, 4, 20000),
        ("ring7", ring(7), 4, 20000),
        ("ER7", er(7, 3, 1), 4, 20000),
        ("ER15", er(15, 3, 3), 3, 12000),
        ("ER20", er(20, 3, 4), 3, 12000),
        ("ER30", er(30, 3, 5), 3, 12000),
    ]
    results = {}
    for name, W, nseed, T in cases:
        rows = []
        for s in range(nseed):
            key = f"{name}_s{s}"
            if key in raw:
                rows.append(raw[key])
                continue
            d = run(W, s, T)
            rows.append(d)
            raw[key] = d
            with open("results_c2a_rows.json", "w") as fh:
                json.dump(raw, fh, indent=1, default=float)
            print(f"  {name} seed{s}: P={d['mean']['P']:.0%} R={d['mean']['R']:.0%} "
                  f"hit={d['hit10']}/{d['nt']} exact0={d['exact0']} "
                  f"merr={d['merr']:.3f}s [{time.time()-t0:.0f}s]", flush=True)
        results[name] = show(f"[{name}]", rows, rows[0]["nt"])
        with open("results_c2a.json", "w") as fh:
            json.dump(results, fh, indent=1)
    print(f"总耗时 {time.time()-t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
