"""
sindy_delay.py — SINDy式稀疏识别: 从{r_j(t-k)}字典选最合适的(j,k_j) (τ未知)
=================================================================
用户洞察: τ未知时像SINDy一样, 构造候选字典{r_j(t-k) | j∈候选, k=0..Kmax},
稀疏识别(前向选择)自动选出最合适的(j,k_j)组合 → 结构(j)+时延(k_j).
对比真实W+τ, 验证储备池隐式记忆是否让稀疏识别选不出正确k.
"""
import time
import numpy as np
from pre2025_crc import W7, Reservoir
from delayed_pre2025 import simulate_delayed
from granger_structure import fit_out


def err_terms(X, i, terms, reservoirs, Nc, lam):
    """terms=[(j,k),...], 输入=[r_i(t); r_j(t-k) for (j,k) in terms]."""
    T = X.shape[0]
    K_max = max([k for (_, k) in terms] + [0])
    Ts = T - K_max - 1
    parts = [reservoirs[i][K_max + 1:T - 1, :]]
    for (j, k) in terms:
        parts.append(reservoirs[j][K_max + 1 - k:T - 1 - k, :Nc])
    R = np.hstack(parts).T
    U = X[K_max + 2:K_max + 2 + Ts, i, :].T
    w = fit_out(U, R, lam)
    return float(np.mean((U - w @ R) ** 2))


def sindy_forward(X, i, reservoirs, Nc, K_max, lam, max_terms, min_gain_frac):
    """前向选择: 贪心选ΔE最大的(j,k), 每邻居最多1个k, 直到增益<阈值."""
    N = X.shape[1]
    base = err_terms(X, i, [], reservoirs, Nc, lam)
    selected = []
    for _ in range(max_terms):
        best_gain = min_gain_frac * base
        best_term = None
        for j in range(N):
            if j == i:
                continue
            if any(t[0] == j for t in selected):
                continue
            for k in range(0, K_max + 1):
                e = err_terms(X, i, selected + [(j, k)], reservoirs, Nc, lam)
                gain = base - e
                if gain > best_gain:
                    best_gain = gain
                    best_term = (j, k)
        if best_term is None:
            break
        selected.append(best_term)
    return selected


def main():
    t0 = time.time()
    rng = np.random.default_rng(42)
    tau = rng.uniform(0.2, 0.8, (7, 7)); np.fill_diagonal(tau, 0.0)
    X = simulate_delayed(W7, tau, t_end=1010.0, dt=0.01, eps=0.3, seed=0)[:20000]
    N = 7
    Ns, Nc, lam = 300, 30, 1e-6
    dt_s = 0.05
    K_max = 20
    reservoirs = [Reservoir(Ns, 3, 0.1, 0.3, 0.9, seed=i).run(X[:, i, :]) for i in range(N)]
    print("=" * 68)
    print("SINDy式稀疏识别: 从{r_j(t-k)}选最合适的(j,k_j)  [τ未知]")
    print(f"异构时延τ真实范围: [{tau[W7==1].min():.2f},{tau[W7==1].max():.2f}]s, K_max={K_max}步")
    print("=" * 68)

    # 前向选择, 收集选中的(j,k_j)
    sel_all = {}
    for i in range(N):
        sel_all[i] = sindy_forward(X, i, reservoirs, Nc, K_max, lam, max_terms=3, min_gain_frac=0.01)

    # 结构辨识: 选中的j (j是i的邻居)
    W_hat = np.zeros((N, N), int); k_hat = np.zeros((N, N), int)
    for i in range(N):
        for (j, k) in sel_all[i]:
            W_hat[i, j] = 1
            k_hat[i, j] = k
    TP, FP, FN, P, R = (lambda h: (
        len(h&set((i,j) for i in range(N) for j in range(N) if W7[i,j]==1)),
        len(h-set((i,j) for i in range(N) for j in range(N) if W7[i,j]==1)),
        len(set((i,j) for i in range(N) for j in range(N) if W7[i,j]==1)-h),
        0,0))(set((i,j) for i in range(N) for j in range(N) if W_hat[i,j]==1))
    P = TP/(TP+FP) if TP+FP else 0; R = TP/(TP+FN) if TP+FN else 0
    print(f"\n[结构辨识] 重构{TP+FP}边  TP={TP} FP={FP} FN={FN}  P={P:.0%} R={R:.0%}")

    # 时延估计: 选中k_j vs 真实τ
    print(f"\n[时延估计] 选中(j,k_j) vs 真实: k_j·Δt vs τ真实")
    for i in range(N):
        for (j, k) in sel_all[i]:
            is_true = "真边" if W7[i, j] == 1 else "假边"
            k_true = int(round(tau[i, j] / dt_s)) if W7[i, j] == 1 else "-"
            hit = "✓" if (W7[i, j] == 1 and abs(k - k_true) <= 2) else " "
            print(f"  振子{i}←{j} {is_true}{hit}  选中k={k:2d}({k*dt_s:.2f}s)  "
                  f"真实k≈{k_true}({'—' if k_true=='-' else f'{k_true*dt_s:.2f}s'})")

    # 诊断: 是否大量选k=0(隐式记忆掩盖时延)
    k0_count = sum(1 for i in range(N) for (j, k) in sel_all[i] if k == 0)
    total = sum(len(sel_all[i]) for i in range(N))
    print(f"\n[诊断] 选中的{total}项中, k=0(即r_j(t))占{k0_count}项 "
          f"({k0_count/total:.0%})  ← 若高说明隐式记忆让k=0显得最优")
    print(f"({time.time()-t0:.1f}s)")


if __name__ == "__main__":
    main()
