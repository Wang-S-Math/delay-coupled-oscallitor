# -*- coding: utf-8 -*-
"""图"自由运行预测轨迹 vs 真实轨迹"(fig:two / 中文图3) 的高质量矢量图.

数据源: _fig2_cn.json (由 b4/keff 管线缓存导出, 与正文/原 tikz 完全同源).
输出:
  figs/fig_traj.pdf  -> 英文稿 \\includegraphics
  figs/fig_traj.png   -> 中文 HTML <img> (dpi=200)
"""
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

base = os.path.dirname(os.path.abspath(__file__))
figdir = os.path.join(base, "figs")
os.makedirs(figdir, exist_ok=True)

with open(os.path.join(base, "_fig2_cn.json"), encoding="utf-8") as f:
    panels = json.load(f)

# 排版: 页面宽 16.2cm, 三面板 + 共享图例
plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Times New Roman", "STIXGeneral", "DejaVu Serif"],
    "mathtext.fontset": "stix",
    "axes.linewidth": 0.7,
    "axes.labelsize": 9.5,
    "axes.titlesize": 10.5,
    "xtick.labelsize": 8,
    "ytick.labelsize": 8,
    "legend.fontsize": 8.5,
    "lines.linewidth": 1.4,
})

COLOR_TRUE = "#1a5fb4"   # 蓝
COLOR_PRED = "#cf222e"   # 红
COLOR_KEFF = "#8a8a8a"   # 灰

# 面板: (1-based 振子号, k_eff, 窗口步数)
meta = [(2, 37, 43), (3, 36, 42), (4, 33, 39)]

fig, axes = plt.subplots(1, 3, figsize=(6.38, 2.55))  # 16.2cm x 6.5cm

for ax, (key, (osc, keff, win)) in zip(axes, zip(panels, meta)):
    _, _, k_json, _, _, win_json, steps_s, truth_s, pred_s = key
    steps = [int(v) for v in steps_s.split(",")]
    truth = [float(v) for v in truth_s.split(",")]
    pred = [float(v) for v in pred_s.split(",")]
    assert len(steps) == win

    ax.plot(steps, truth, color=COLOR_TRUE, lw=1.5, solid_capstyle="round",
            zorder=3)
    ax.plot(steps, pred, color=COLOR_PRED, lw=1.4, ls="--", zorder=3)
    ax.axvline(keff, color=COLOR_KEFF, lw=0.9, ls=(0, (4, 3)), zorder=2)

    ax.set_title(f"oscillator {osc}", pad=5)
    ax.set_xlabel(r"free-run step $s$")
    if osc == 2:
        ax.set_ylabel(r"$x_i(s)$")
    ax.set_xlim(1, win)
    ax.set_xticks([1, 10, 20, 30, 40])
    ax.grid(True, lw=0.4, color="#d5d5d5", zorder=1)
    for spine in ("top", "right"):
        ax.spines[spine].set_visible(False)
    # k_eff 标注
    ymin, ymax = ax.get_ylim()
    ax.annotate(rf"$k_{{\rm eff}}={keff}$", xy=(keff, ymax),
                xytext=(keff - 1.0, ymax - 0.06 * (ymax - ymin)),
                ha="right", va="top", fontsize=7.5, color="#555555")

handles = [
    Line2D([], [], color=COLOR_TRUE, lw=1.5, label="truth"),
    Line2D([], [], color=COLOR_PRED, lw=1.4, ls="--", label="prediction"),
    Line2D([], [], color=COLOR_KEFF, lw=0.9, ls=(0, (4, 3)),
           label=r"$k_{\rm eff}$"),
]
fig.legend(handles=handles, loc="lower center", ncol=3, frameon=False,
           bbox_to_anchor=(0.5, -0.015), handlelength=2.4)

fig.tight_layout(rect=(0, 0.055, 1, 1))
fig.savefig(os.path.join(figdir, "fig_traj.pdf"), bbox_inches="tight",
            pad_inches=0.03)
fig.savefig(os.path.join(figdir, "fig_traj.png"), dpi=200,
            bbox_inches="tight", pad_inches=0.05)
print("saved figs/fig_traj.pdf and figs/fig_traj.png")
