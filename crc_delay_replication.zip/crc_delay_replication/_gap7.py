# -*- coding: utf-8 -*-
"""删去 BA N=7、环 N=10、环 N=20、随机 ER N=10 后，重算 6 拓扑的判据平均值。"""
import os, glob, pickle, numpy as np

EXCL = {"无标度BA_N7_N7_T20000", "环_N10_N10_T20000", "环_N20_N20_T12000",
        "随机ER_N10_N10_T20000"}

def eval_hat(hat, true):
    TP=len(hat&true); FP=len(hat-true); FN=len(true-hat)
    P=TP/(TP+FP) if TP+FP else 0.0
    R=TP/(TP+FN) if TP+FN else 0.0
    F1=2*P*R/(P+R) if P+R else 0.0
    return P,R,F1,FP

def gap_rule(gains,N):
    hat=set()
    for i in range(N):
        items=sorted(gains[i].items(),key=lambda x:-x[1])
        g=np.array([v for _,v in items])
        if len(g)<2: hat.add((i,items[0][0])); continue
        ratio=g[:-1]/(g[1:]+1e-30); m=int(np.argmax(ratio))
        for j,_ in items[:m+1]: hat.add((i,j))
    return hat

def rule_alpha(gains,N,alpha):
    hat=set()
    for i in range(N):
        v=np.array(list(gains[i].values())); thr=v.mean()+alpha*v.std()
        for j,gv in gains[i].items():
            if gv>thr: hat.add((i,j))
    return hat

tot={k:[] for k in ("a0","a5","a75","gap")}
totfp={k:[] for k in ("a0","a5","a75","gap")}
rows=[]
for f in sorted(glob.glob("gains_*_N*_T*.pkl")):
    name=os.path.basename(f).replace("gains_","").replace(".pkl","")
    if name in EXCL: continue
    D=pickle.load(open(f,"rb")); W,gains,N=D["W"],D["gains"],D["N"]
    true=set((i,j) for i in range(N) for j in range(N) if W[i,j]==1)
    r={}
    for key,hat in (("a0",rule_alpha(gains,N,0.0)),("a5",rule_alpha(gains,N,0.5)),
                    ("a75",rule_alpha(gains,N,0.75)),("gap",gap_rule(gains,N))):
        P,R,F1,FP=eval_hat(hat,true); r[key]=(P,R,F1,FP)
        tot[key].append(F1); totfp[key].append(FP)
    rows.append((name,N,int(W.sum()),r))
for nm,N,E,r in rows:
    print(f"{nm:<28}{N:>3}{E:>5} | a0 P={r['a0'][0]:.0%} FP={r['a0'][3]:>3} F1={r['a0'][2]:.3f} | a.5 P={r['a5'][0]:.0%} FP={r['a5'][3]:>2} F1={r['a5'][2]:.3f} | a.75 P={r['a75'][0]:.0%} FP={r['a75'][3]:>2} F1={r['a75'][2]:.3f} | gap P={r['gap'][0]:.0%} R={r['gap'][1]:.0%} FP={r['gap'][3]:>2} F1={r['gap'][2]:.3f}")
print()
print("n topologies =", len(rows))
for k in ("a0","a5","a75","gap"):
    print(f"  {k:>4}: mean F1={np.mean(tot[k]):.3f}  mean FP={np.mean(totfp[k]):.1f}")
