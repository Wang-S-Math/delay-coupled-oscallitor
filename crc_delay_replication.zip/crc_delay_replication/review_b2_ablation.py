"""
review_b2_ablation.py — 审稿 1.4(1): 字典×判据 2×2 消融的定量表
=================================================================
论文 §3.4(1) 目前只有文字结论。本脚本按该节声明的口径补数据:
Lorenz W7, 调参基线 ε=0.3, τ∈[0.2,0.8], Δt=0.05, T=12000, 种子 0-1。
2×2 = {储备池字典 r_j(t-k) / 原始信号字典 x_j(t-k)} ×
      {逐邻居 argmax + 均值阈值 / 全局 (j,k) 均值阈值}。
JSON: results_b2_ablation.json
"""
import json
import time

import numpy as np

from pre2025_crc import W7, Reservoir
from lorenz_tune import simulate
import review_common as RC

EPS = 0.3
TAU_RANGE = (0.2, 0.8)
DT_S = 0.05
T = 12000
SEEDS = (0, 1)


def run(seed):
    N = W7.shape[0]
    tau = RC.make_tau(W7, TAU_RANGE, seed)
    X = simulate(W7, tau, T * DT_S + 20.0, dt=0.005, eps=EPS,
                 seed=seed, sample=10)[:T]
    K_max = int(np.ceil(tau[W7 == 1].max() / DT_S)) + 2
    res = [Reservoir(300, 3, 0.1, 0.3, 0.9, seed=i).run(X[:, i, :])
           for i in range(N)]
    out = {}
    for kind in ("r", "x"):
        Gs = {i: RC.gains_full(X, i, res, 30, K_max, 1e-6, dict_kind=kind)
              for i in range(N)}
        out[kind] = RC.metrics(W7, tau, Gs, DT_S)
    return out


def main():
    t0 = time.time()
    rows = [run(s) for s in SEEDS]
    res = {}
    for kind in ("r", "x"):
        for rule in ("argmax_mean", "global_thresh"):
            g = lambda k: float(np.mean([r[kind][rule][k] for r in rows]))
            rec = dict(P=g("P"), R=g("R"), F1=g("F1"), FP=g("FP"),
                       hit10=g("hit10"), exact0=g("exact0"),
                       exact1=g("exact1"), merr=g("merr"),
                       nt=rows[0][kind][rule]["nt"])
            res[f"{kind}_{rule}"] = rec
            print(f"  dict={kind} rule={rule:<13} P={rec['P']:.0%} "
                  f"R={rec['R']:.0%} F1={rec['F1']:.3f} FP={rec['FP']:.1f} "
                  f"hit={rec['hit10']:.1f}/{rec['nt']} "
                  f"merr={rec['merr']:.3f}s [{time.time()-t0:.0f}s]",
                  flush=True)
            with open("results_b2_ablation.json", "w") as fh:
                json.dump(res, fh, indent=1)
    print(f"总耗时 {time.time()-t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
