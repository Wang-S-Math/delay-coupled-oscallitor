"""诊断: 欧拉 vs RK4-DDE 的 maxLE 随步长收敛性 + 耦合轨迹是否周期"""
import numpy as np
from pre2025_crc import W7
from maxle_dde_rk4 import max_le_dde
from maxle_coupled import max_le_benettin  # 欧拉版

rng = np.random.default_rng(1000)
tau = rng.uniform(0.3, 1.2, (7, 7)); np.fill_diagonal(tau, 0.0)
tau = tau * W7

print("— 欧拉 Benettin 步长收敛 (孤立) —", flush=True)
W1 = np.zeros((1, 1)); t1 = np.zeros((1, 1))
for dt in (0.005, 0.002, 0.001):
    le = max_le_benettin(W1, t1, 0.0, dt, seed=0)
    print(f"  dt={dt:<6g} LE={le:.4f}", flush=True)

print("— 欧拉 Benettin 步长收敛 (耦合 ε=1.5) —", flush=True)
for dt in (0.005, 0.002, 0.001):
    le = max_le_benettin(W7, tau, 1.5, dt, seed=0)
    print(f"  dt={dt:<6g} LE={le:.4f}", flush=True)

print("— RK4-DDE 重正化间隔收敛 (耦合 ε=1.5) —", flush=True)
for tr in (1.0, 5.0):
    le = max_le_dde(W7, tau, 1.5, dt=0.005, t_ren=tr, n_ren=40, seed=0)
    print(f"  t_ren={tr:<4g} LE={le:.4f}", flush=True)

print("— RK4-DDE 弱耦合对照 ε=0.3 —", flush=True)
le = max_le_dde(W7, tau, 0.3, dt=0.005, seed=0)
print(f"  ε=0.3 LE={le:.4f}", flush=True)

# 轨迹检查: RK4-DDE ε=1.5 是否周期
from maxle_dde_rk4 import A, B, C
def sim_dde(W, tau, eps, dt, T, seed):
    import maxle_dde_rk4 as M
    Nn = W.shape[0]
    p_idx, q_idx = np.nonzero(W)
    d_e = np.asarray(tau, float)[p_idx, q_idx] / dt
    d_e = np.maximum(d_e, 1e-9)
    Mx = int(np.ceil(d_e.max())) + 4
    rng2 = np.random.default_rng(seed)
    X0 = rng2.uniform(1.0, 5.0, (Nn, 3))
    Wm = W.astype(float)
    Buf = np.tile(X0, (Mx, 1, 1)); ptr = Mx - 1
    def delayed(a):
        idx = ptr - d_e + a
        i0 = np.floor(idx).astype(np.int64); w = idx - i0
        lm1 = w*(w-1.0)*(w-2.0)/(-6.0); l0 = (w+1.0)*(w-1.0)*(w-2.0)/2.0
        l1 = (w+1.0)*w*(w-2.0)/(-2.0); l2 = (w+1.0)*w*(w-1.0)/6.0
        rows = (ptr + i0[None,:] + np.array([-1,0,1,2])[:,None]) % Mx
        vals = Buf[rows, q_idx[None,:]]
        lw = np.stack([lm1,l0,l1,l2])
        return np.einsum("ae,aec->ec", lw, vals)
    def rhs(x, xD):
        dX = np.empty_like(x)
        dX[:,0] = A*(x[:,1]-x[:,0]); dX[:,1] = B*x[:,0]-x[:,1]-x[:,0]*x[:,2]
        dX[:,2] = x[:,0]*x[:,1]-C*x[:,2]
        diff = xD - x[p_idx]
        dX[:,1] += eps*np.bincount(p_idx, weights=Wm[p_idx,q_idx]*diff[:,0], minlength=Nn)
        return dX
    n = int(round(T/dt)); out = np.empty((n+1, Nn, 3)); out[0] = X0
    for i in range(n):
        x = Buf[ptr]
        k1 = rhs(x, delayed(0.0)); k2 = rhs(x+0.5*dt*k1, delayed(0.5))
        k3 = rhs(x+0.5*dt*k2, delayed(0.5)); k4 = rhs(x+dt*k3, delayed(1.0))
        xn = x + (dt/6.0)*(k1+2*k2+2*k3+k4)
        ptr = (ptr+1) % Mx; Buf[ptr] = xn; out[i+1] = xn
    return out

Xr = sim_dde(W7, tau, 1.5, 0.005, 300.0, 0)
xs = Xr[40000:, 0, 0]  # 振子0 x 分量, 去掉前200s
print(f"振子0 x 均值={xs.mean():.3f} 标准差={xs.std():.3f}")
# 峰值间隔规则性
pk = np.where((xs[1:-1] > xs[:-2]) & (xs[1:-1] > xs[2:]))[0]
if len(pk) > 5:
    iv = np.diff(pk) * 0.005
    print(f"峰值间隔: 均值={iv.mean():.3f}s 标准差={iv.std():.4f}s n={len(pk)}")
# 成对距离(去同步度)
d = np.sqrt(((Xr[40000:,:,0][:, :, None] - Xr[40000:,:,0][:, None, :])**2).mean(axis=(1,2)))
print(f"成对RMS距离 均值={d.mean():.3f}")
