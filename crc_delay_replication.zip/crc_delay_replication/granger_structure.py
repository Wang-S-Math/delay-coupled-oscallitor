"""
granger_structure.py — PRE2025 结构辨识(Granger因果, Step1-5)
=================================================================
对每个振子i, 把候选邻居j的储备池拼接进来算预测误差ΔE_i,j;
ΔE_i,j显著低于基线/平均 → j是i的邻居(Granger因果: 加入j能提升i的预测).
用Method1(阈值=平均ΔE)和选最低k个, 重构W, 对比真实W7(式12).
"""
import time
import numpy as np
from pre2025_crc import W7, simulate, Reservoir


def fit_out(U, R, lam):
    """U (D,T), R (Ns,T) → w (D,Ns) = U R'(R R'+λI)^-1."""
    Ns = R.shape[0]
    b = U @ R.T  # (D, Ns)
    return np.linalg.solve(R@R.T + lam*np.eye(Ns), b.T).T  # (D, Ns)


def granger_structure(X, Ns=200, Nc=20, lam=1e-6, seed=0):
    N = X.shape[1]; T = X.shape[0]
    reservoirs = [Reservoir(Ns, 3, 0.1, 0.3, 0.9, seed=seed+i).run(X[:, i, :]) for i in range(N)]
    dE = np.full((N, N), np.nan)
    for i in range(N):
        U = X[1:, i, :].T  # (3, T-1)
        R_i = reservoirs[i]
        Rm = R_i[:-1, :].T  # (Ns, T-1) 基线(无邻居)
        w0 = fit_out(U, Rm, lam)
        dE[i, i] = float(np.mean((U - w0@Rm)**2))  # 基线误差放对角
        for j in range(N):
            if j == i:
                continue
            Rf = np.hstack([R_i, reservoirs[j][:, :Nc]])[:-1, :].T  # (Ns+Nc, T-1)
            w = fit_out(U, Rf, lam)
            dE[i, j] = float(np.mean((U - w@Rf)**2))
    return dE, reservoirs


def main():
    t0 = time.time()
    print("=" * 62)
    print("PRE2025 Granger因果结构辨识 (N=7, 耦合Lorenz, 无时滞)")
    print("=" * 62)
    X = simulate(W7, t_end=1010.0, dt=0.01, eps=0.3, seed=0)[::5][:20000]
    N = 7
    print(f"数据: {X.shape[0]} 点, 每振子独立储备池Ns=200, 邻居取Nc=20节点")
    dE, _ = granger_structure(X, Ns=200, Nc=20, lam=1e-6, seed=0)
    base = np.diag(dE)
    print(f"\n各振子基线误差(无邻居): " + " ".join(f"i{i}={base[i]:.4f}" for i in range(N)))

    # Method1: ΔE_i,j < 平均(所有j) → j是邻居
    W_hat = np.zeros((N, N), dtype=int)
    for i in range(N):
        others = [dE[i, j] for j in range(N) if j != i]
        thr = np.mean(others)
        for j in range(N):
            if j != i and dE[i, j] < thr:
                W_hat[i, j] = 1

    print(f"\nMethod1重构 (ΔE<平均) vs 真实W7:")
    true_edges = [(i, j) for i in range(N) for j in range(N) if W7[i, j] == 1]
    hat_edges = [(i, j) for i in range(N) for j in range(N) if W_hat[i, j] == 1]
    TP = len(set(hat_edges) & set(true_edges))
    FP = len(set(hat_edges) - set(true_edges))
    FN = len(set(true_edges) - set(hat_edges))
    print(f"  真实边: {len(true_edges)}  重构边: {len(hat_edges)}")
    print(f"  TP={TP}  FP={FP}  FN={FN}")
    if TP + FP > 0:
        print(f"  精确率P={TP/(TP+FP):.2%}  召回率R={TP/(TP+FN):.2%}")
    print(f"\n  真实W7非零: {W7.astype(int).sum()}")
    print(f"  重构W_hat: {W_hat}")
    print(f"({time.time()-t0:.1f}s)")


if __name__ == "__main__":
    main()
