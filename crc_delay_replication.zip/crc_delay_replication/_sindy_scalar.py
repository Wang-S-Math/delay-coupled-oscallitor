# -*- coding: utf-8 -*-
"""
_sindy_scalar.py — SINDy 时延字典在标量观测 (仅 x_i) 下的对照
==============================================================
耦合注入 ẏ_i 通道; 标量观测下 SINDy 只能回归 ẋ_i = a(y_i - x_i),
耦合项不直接出现在目标方程中, 只能经 y_i 间接反映。
基线 [1, x_i], 候选 = 延迟 x_j(t-τ), 同一 τ 网格 (k=0..26), 同一 gap 判据。
4 种子, clean, 其余同 review_baseline_compare。
"""
import os
for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
           "NUMEXPR_NUM_THREADS"):
    os.environ[_v] = "1"
import numpy as np
from pre2025_crc import W7
from lorenz_tune import simulate
import review_common as RC
from het_delay_structure import deriv5, delayed
import review_baseline_compare as B

DT_S, EPS, TAU_RANGE, T_USE = B.DT_S, B.EPS, B.TAU_RANGE, B.T_USE
K_MAX = B.K_MAX

def run(seed):
    N = W7.shape[0]
    tau = RC.make_tau(W7, TAU_RANGE, seed)
    t_end = T_USE * DT_S + 20.0
    X = simulate(W7, tau, t_end, dt=0.005, eps=EPS, seed=seed, sample=10)[:T_USE]
    dX = deriv5(X, DT_S)
    tau_grid = np.arange(0, K_MAX + 1) * DT_S
    gm, th = {}, {}
    for i in range(N):
        target = dX[:, i, 0]          # ẋ_i
        xi = X[:, i, 0]
        base_cols = [np.ones_like(xi), xi]
        blib = np.column_stack(base_cols)
        ob, *_ = np.linalg.lstsq(blib, target, rcond=None)
        base_rss = float(np.linalg.norm(target - blib @ ob) ** 2)
        gm[i] = {}; th[i] = {}
        for j in range(N):
            if j == i:
                continue
            col = X[:, j, 0]
            best_rss2, best_tau = np.inf, 0.0
            for tt in tau_grid:
                lib = np.column_stack(base_cols + [delayed(col, DT_S, tt)])
                om, *_ = np.linalg.lstsq(lib, target, rcond=None)
                rss2 = float(np.linalg.norm(target - lib @ om) ** 2)
                if rss2 < best_rss2:
                    best_rss2, best_tau = rss2, float(tt)
            gm[i][j] = max((base_rss - best_rss2) / (base_rss + 1e-30), 0.0)
            th[i][j] = best_tau
    d = B.eval_method(gm, th, W7, tau)
    return d

rows = [run(s) for s in (0, 1, 2, 3)]
for s, d in zip((0, 1, 2, 3), rows):
    print(f"seed{s}: P={d['P']:.3f} R={d['R']:.3f} F1={d['F1']:.3f} "
          f"hit={d['hit']}/{d['nt']} merr={d['merr']:.3f} AUC={d['auc']:.3f}")
for k in ("P", "R", "F1", "hit", "merr", "auc"):
    v = np.array([d[k] for d in rows], float)
    print(f"{k:>5}: {v.mean():.3f} ± {v.std():.3f}")
