# -*- coding: utf-8 -*-
"""
review_e4_sl10.py — E4: Stuart-Landau 跨规模验证 N=10(论文现仅 N=5)
=====================================================================
审稿风险: SL 跨动力学验证只有 N=5。本实验推到 N=10, 沿用论文 N=5 设定:
  ring(单向环) λ=-0.7 ω=2.0 c=0.5 β=0 κ=0.8 τ~U(2.5,4.0) dt=0.005
  dt_s=0.02(sample=4) 与 0.05(sample=10), T_use=3000, 种子 0-2
同步诊断 s_sync/ρ/振幅同时输出。SL 近临界 λ=-0.7 在 N=50 曾出现振幅死亡,
N=10 是安全的中间规模(远离 N=50 的两头堵)。
"""
import json
import time

import numpy as np

import sl_crc_rk4 as SL

CACHE = "results_e4_sl10.json"


def one(N, dt_s, seed):
    W, tau = SL.ring_W_tau(N, (2.5, 4.0), seed=1000)
    return SL.run(W, tau, lam=-0.7, kappa=0.8, beta=0.0, c=0.5,
                  omega=2.0, dt=0.005, dt_s=dt_s, T_use=3000, seed=seed,
                  cache=f"gains_e4_sl{N}_dts{dt_s}_s{seed}.pkl")


def show(tag, r):
    if r.get("diverged"):
        print(f"{tag:<26} DIVERGED", flush=True)
        return
    m, g = r["crit"]["mean"], r["crit"]["gap"]
    print(f"{tag:<26} s={r['s_sync']:.2f} ρ={r['rho']:+.2f} |z|={r['amp']:.2f} | "
          f"mean P={m['P']:.2f} R={m['R']:.2f} F1={m['F1']:.3f} | "
          f"gap P={g['P']:.2f} R={g['R']:.2f} F1={g['F1']:.3f} | "
          f"hit={r['hit']}/{r['n_true']} merr={r['merr']:.4f}", flush=True)


def main():
    t0 = time.time()
    res = {}
    try:
        res = json.load(open(CACHE, encoding="utf-8"))
    except FileNotFoundError:
        pass
    print("=" * 108, flush=True)
    print("E4: SL ring N=10, lam=-0.7 om=2.0 c=0.5 beta=0 kappa=0.8 tau~U(2.5,4.0) T_use=3000", flush=True)
    print("=" * 108, flush=True)
    for dt_s in [0.02, 0.05]:
        rows = []
        for s in range(3):
            tag = f"N10_dts{dt_s}_s{s}"
            if tag in res:
                r = res[tag]
            else:
                r = one(10, dt_s, s)
                res[tag] = r
                json.dump(res, open(CACHE, "w", encoding="utf-8"), default=float)
            rows.append(r)
            show(f"  {tag}", r)
        ok = [r for r in rows if not r.get("diverged")]
        if ok:
            print(f"  ==> N10 dt_s={dt_s}: gapF1={np.mean([r['crit']['gap']['F1'] for r in ok]):.3f} "
                  f"hit={np.mean([r['hit'] for r in ok]):.1f}/{ok[0]['n_true']} "
                  f"merr={np.mean([r['merr'] for r in ok]):.4f}", flush=True)
    print(f"\ntotal {time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
