"""
lorenz_dense_bigtau.py — 补测 §4.4(ii) 稠密拓扑 与 §4.4(iii) 大时延范围
=================================================================
旧数据(ε=0.3, τ∈[0.2,0.8], generalize_argmax.py): 星形 R=67%、完全图 R=55%;
旧大时延(ε=0.3, τ∈[3,7]): precision≤0.36.
本脚本在最优配置框架(Δt=0.05, Ns=300, Nc=30, λ=1e-6)下重测:

[A] 稠密拓扑(星N=7 / 完全N=7 / 稠密ER N=10,d̄=6): 扫 ε 找同步边界与最优性能
    → 假设: 稠密失效主因是"有效耦合 ε·d̄ 跨越同步边界", 降 ε 可恢复
[B] 大时延 τ∈[3,7]s (W7): 扫 ε∈{0.3,1.0,1.5} → 强耦合能否恢复真/假边可分性
    K_max=ceil(7/0.05)+2=142, T_use=12000(控算力)

判据(全部基于缓存 gain, 判据后置零算力):
  α=0(原判据 g>mean) | 最大间隙 | 最大间隙+无间隙回退(最大ratio<r_min→接受全部)
  → 回退规则专治"候选几乎全为真边"的稠密节点(星中心/完全图)
"""
import os
import time
import pickle
import numpy as np
from pre2025_crc import W7, Reservoir
from lorenz_tune import simulate
from sindy_argmax import sindy_argmax
from lorenz_generalize import er


def star(N):
    W = np.zeros((N, N), int)
    for i in range(1, N):
        W[0, i] = 1
        W[i, 0] = 1
    return W


def complete(N):
    return np.ones((N, N), int) - np.eye(N, dtype=int)


# ---------------- 判据 ----------------
def eval_hat(hat, true):
    TP = len(hat & true); FP = len(hat - true); FN = len(true - hat)
    P = TP / (TP + FP) if TP + FP else 0.0
    R = TP / (TP + FN) if TP + FN else 0.0
    F1 = 2 * P * R / (P + R) if P + R else 0.0
    return P, R, F1, TP, FP, FN


def rule_alpha(gains, N, alpha=0.0):
    hat = set()
    for i in range(N):
        v = np.array(list(gains[i].values()))
        thr = v.mean() + alpha * v.std()
        for j, gv in gains[i].items():
            if gv > thr:
                hat.add((i, j))
    return hat


def gap_rule(gains, N, r_min=None):
    """最大相对间隙切分; r_min=None 为原判据; r_min给定则最大ratio<r_min时接受全部."""
    hat = set()
    for i in range(N):
        items = sorted(gains[i].items(), key=lambda x: -x[1])
        g = np.array([v for _, v in items])
        if len(g) < 2:
            hat.add((i, items[0][0]))
            continue
        ratio = g[:-1] / (g[1:] + 1e-30)
        m = int(np.argmax(ratio))
        if r_min is not None and ratio[m] < r_min:
            for j, _ in items:
                hat.add((i, j))
        else:
            for j, _ in items[:m + 1]:
                hat.add((i, j))
    return hat


def auc_mw(gains, W, N):
    """Mann-Whitney AUC(真/假边增益可分性); 无假边(完全图)返回None."""
    pos = []; neg = []
    for i in range(N):
        for j, v in gains[i].items():
            (pos if W[i, j] == 1 else neg).append(v)
    if not pos or not neg:
        return None
    pos = np.array(pos); neg = np.array(neg)
    wins = 0.0
    for p in pos:
        wins += np.sum(p > neg) + 0.5 * np.sum(p == neg)
    return wins / (len(pos) * len(neg))


# ---------------- 单次实验 ----------------
def run2(W, eps, tau_range=(0.3, 1.2), Ns=300, Nc=30, lam=1e-6, seed=0,
         T_use=12000, dt_int=0.005, sample=10, save=None):
    N = W.shape[0]
    dt_s = sample * dt_int
    rng = np.random.default_rng(seed + 1000)
    tau = rng.uniform(*tau_range, (N, N)); np.fill_diagonal(tau, 0.0)
    tau = tau * W
    t_end = T_use * dt_s + 20.0
    X = simulate(W, tau, t_end, dt=dt_int, eps=eps, seed=seed, sample=sample)[:T_use]
    xs = X[:, :, 0]
    d = np.array([np.sqrt(np.mean((xs[:, i] - xs[:, j]) ** 2))
                  for i in range(N) for j in range(i + 1, N)])
    spread = np.sqrt(np.mean((xs - xs.mean(axis=1, keepdims=True)) ** 2))
    s_sync = float(np.mean(d) / (spread + 1e-12))
    C = np.corrcoef(xs.T)
    rho = float((C.sum() - N) / (N * (N - 1)))
    reservoirs = [Reservoir(Ns, 3, 0.1, 0.3, 0.9, seed=i).run(X[:, i, :]) for i in range(N)]
    K_max = int(np.ceil(tau[W == 1].max() / dt_s)) + 2
    gains = {}; kbest = {}
    for i in range(N):
        gm, kb = sindy_argmax(X, i, reservoirs, Nc, K_max, lam)
        gains[i] = gm; kbest[i] = kb
    if save:
        with open(save, "wb") as fh:
            pickle.dump(dict(W=W, gains=gains, N=N, tau=tau, kbest=kbest,
                             dt_s=dt_s, eps=eps), fh)
    hit10 = hit25 = nt = 0; errs = []
    for i in range(N):
        for j in range(N):
            if W[i, j] == 1:
                nt += 1
                k = kbest[i].get(j, -1)
                e = abs(k * dt_s - tau[i, j])
                errs.append(e)
                hit10 += int(e <= 0.1); hit25 += int(e <= 0.25)
    return dict(N=N, edges=int(W.sum()), s_sync=s_sync, rho=rho, K_max=K_max,
                gains=gains, kbest=kbest, tau=tau, dt_s=dt_s, eps=eps, W=W,
                hit10=hit10, hit25=hit25, nt=nt, merr=float(np.mean(errs)))


def report(tag, r):
    N = r["N"]; W = r["W"]; gains = r["gains"]
    true = set((i, j) for i in range(N) for j in range(N) if W[i, j] == 1)
    P0, R0, F0, _, FP0, _ = eval_hat(rule_alpha(gains, N, 0.0), true)
    Pg, Rg, Fg, _, FPg, _ = eval_hat(gap_rule(gains, N), true)
    Pf, Rf, Ff, _, FPf, _ = eval_hat(gap_rule(gains, N, r_min=1.5), true)
    A = auc_mw(gains, W, N)
    astr = "  n/a " if A is None else f"{A:6.3f}"
    print(f"{tag:<30} s_sync={r['s_sync']:5.2f} ρ={r['rho']:+.2f} │ "
          f"α=0: P={P0:4.0%} R={R0:4.0%} F1={F0:.3f} FP={FP0:<3} │ "
          f"gap: P={Pg:4.0%} R={Rg:4.0%} F1={Fg:.3f} FP={FPg:<3} │ "
          f"gap+回退: P={Pf:4.0%} R={Rf:4.0%} F1={Ff:.3f} FP={FPf:<3} │ "
          f"AUC={astr} │ 时延≤0.1:{r['hit10']}/{r['nt']} ≤0.25:{r['hit25']}/{r['nt']} "
          f"m|Δτ|={r['merr']:.3f}s", flush=True)
    return dict(P0=P0, R0=R0, F0=F0, Pg=Pg, Rg=Rg, Fg=Fg,
                Pf=Pf, Rf=Rf, Ff=Ff, auc=A)


def main():
    t0 = time.time()
    print("=" * 130, flush=True)
    print("[A] 稠密拓扑 ε扫描 (Δt=0.05, τ∈[0.3,1.2], T=12000, 1种子) — 旧数据ε=0.3: 星R=67% 完全R=55%", flush=True)
    print("=" * 130, flush=True)
    casesA = [
        ("星 N=7", star(7), [0.3, 0.6, 1.0, 1.5], "gains_star7_eps"),
        ("完全 N=7", complete(7), [0.15, 0.3, 0.6, 1.0, 1.5], "gains_comp7_eps"),
        ("稠密ER N=10 d̄=6", er(10, 6, 6), [0.3, 0.6, 1.0, 1.5], "gains_er10d6_eps"),
    ]
    for name, W, eps_list, pkl in casesA:
        for eps in eps_list:
            r = run2(W, eps=eps, seed=0, save=f"{pkl}{eps}.pkl")
            report(f"  {name} ε={eps:.2f}", r)
        print(flush=True)

    print("=" * 130, flush=True)
    print("[B] 大时延 τ∈[3,7]s (W7, Δt=0.05, K_max=142, T=12000, 1种子) — 旧数据ε=0.3: precision≤0.36", flush=True)
    print("=" * 130, flush=True)
    for eps in [0.3, 1.0, 1.5]:
        r = run2(W7, eps=eps, tau_range=(3.0, 7.0), seed=0,
                 save=f"gains_W7_tau37_eps{eps}.pkl")
        report(f"  W7 τ[3,7] ε={eps:.2f}", r)

    print(f"\n总耗时: {time.time() - t0:.1f}s", flush=True)


if __name__ == "__main__":
    main()
