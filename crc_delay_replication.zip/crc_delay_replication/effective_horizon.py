"""effective_horizon.py — N=7 时延耦合 Lorenz 的有效预测步数 k_eff 与预测/真实轨迹
=================================================================================
与论文 §4.1 基准配置完全一致: W7, ε=1.5, Δt=0.05s, τ∈[0.3,1.2]s, T=20000,
Ns=300/Nc=30/α=0.3/ρ=0.9。

流程:
 1. 逐邻居 argmax（时延字典, 仅在训练段）→ k̂_ij; 相对阈值判边 → Ŵ
    (复现论文的结构与时延重构结果)
 2. 用【重构出的边与时延】在【训练段】拟合读出 w_i, 目标 x_i(t+1) (三维)
 3. 【测试段】C-RC 自由运行: 全部储备池同时自治递推, 输入改取自身预测,
    邻居项取自由运行状态的时延位置 r_j(t-k̂_ij), 不再用真实数据锚定
 4. NRMSE(s) → 有效预测步数 k_eff = 使 NRMSE(s) ≤ θ 的最大步数

对照三种特征集:
   crc    = 重构的边 + 重构时延   (本文方法)
   oracle = 真边 + 真时延         (上界参照)
   rc     = 仅自身储备池 (无邻居) (普通 RC 基线)
岭参数: 结构推断用 λ=1e-6 (§3.3); 自治递推对读出条件数敏感, 预测读出
        单独用 λ_pred (扫描 1e-6 … 1e-1)。
"""
import json
import os
import pickle
import time

import numpy as np

from pre2025_crc import W7, Reservoir
from lorenz_tune import simulate

N = 7
NS, NC = 300, 30
LAM_INFER = 1e-6
DT_INT, SAMPLE = 0.005, 10
DT_S = DT_INT * SAMPLE
EPS = 1.5
TAU_RANGE = (0.3, 1.2)
T_USE, N_TR = 20000, 15000
SEED = 0
K_MAX = 26
S_MAX = 200
N_START, START0, STRIDE = 20, N_TR + 500, 100
LAM_PREDS = [1e-6, 1e-3, 1e-2, 1e-1]
LAM_MAIN = 1e-2
CACHE = "cache_keff_recon.pkl"   # 缓存重构结果(逐邻居 argmax), 避免重复算力


def fit_out(U, R, lam):
    A = R @ R.T + lam * np.eye(R.shape[0])
    return np.linalg.solve(A, R @ U.T).T


def features(i, terms, R_all, t_idx):
    parts = [R_all[i][t_idx, :]]
    for (j, k) in terms:
        parts.append(R_all[j][t_idx - k, :NC])
    return np.hstack(parts).T


def err_terms(X, i, terms, R_all, t_idx, lam=LAM_INFER):
    R = features(i, terms, R_all, t_idx)
    U = X[t_idx + 1, i, :].T
    return float(np.mean((U - fit_out(U, R, lam) @ R) ** 2))


def argmax_terms(X, i, R_all, t_idx):
    base = err_terms(X, i, [], R_all, t_idx)
    gain, kbest = {}, {}
    for j in range(N):
        if j == i:
            continue
        bg, bk = -np.inf, 0
        for k in range(0, K_MAX + 1):
            g = base - err_terms(X, i, [(j, k)], R_all, t_idx)
            if g > bg:
                bg, bk = g, k
        gain[j], kbest[j] = bg, bk
    return gain, kbest


def free_run(X, terms, w_list, reservoirs, R_all, starts, S, sigma):
    """返回 per_osc (N, n_start, S): 每步按分量归一的 NRMSE。"""
    per = np.zeros((N, len(starts), S))
    a = reservoirs[0].alpha
    for m, t0 in enumerate(starts):
        buf = [R_all[i][t0 - K_MAX: t0 + S + 1].copy() for i in range(N)]
        for s in range(1, S + 1):
            t = t0 + s
            mcur = (t - 1) - t0 + K_MAX
            pred = np.zeros((N, 3))
            for i in range(N):
                f = [buf[i][mcur]]
                for (j, k) in terms[i]:
                    f.append(buf[j][(t - 1 - k) - t0 + K_MAX][:NC])
                pred[i] = w_list[i] @ np.concatenate(f)
            for i in range(N):
                per[i, m, s - 1] = np.sqrt(
                    np.mean(((pred[i] - X[t, i, :]) / sigma[i]) ** 2))
            for i in range(N):
                res = reservoirs[i]
                buf[i][t - t0 + K_MAX] = (1 - a) * buf[i][mcur] + a * np.tanh(
                    res.Win @ pred[i] + res.Wres @ buf[i][mcur] + res.bk)
    return per


def traj_run(X, terms, w_list, reservoirs, R_all, t0, S):
    """单点起跑, 返回 (true, pred), 各 (N, S) 的 x 分量。"""
    a = reservoirs[0].alpha
    buf = [R_all[i][t0 - K_MAX: t0 + S + 1].copy() for i in range(N)]
    true = np.zeros((N, S))
    pred = np.zeros((N, S))
    for s in range(1, S + 1):
        t = t0 + s
        mcur = (t - 1) - t0 + K_MAX
        ph = np.zeros((N, 3))
        for i in range(N):
            f = [buf[i][mcur]]
            for (j, k) in terms[i]:
                f.append(buf[j][(t - 1 - k) - t0 + K_MAX][:NC])
            ph[i] = w_list[i] @ np.concatenate(f)
        for i in range(N):
            true[i, s - 1] = X[t, i, 0]
            pred[i, s - 1] = ph[i, 0]
        for i in range(N):
            res = reservoirs[i]
            buf[i][t - t0 + K_MAX] = (1 - a) * buf[i][mcur] + a * np.tanh(
                res.Win @ ph[i] + res.Wres @ buf[i][mcur] + res.bk)
    return true, pred


def keff_of(curve, theta, S):
    idx = np.where(curve > theta)[0]
    return int(idx[0]) if len(idx) else S


def main():
    t0 = time.time()
    rng = np.random.default_rng(SEED + 1000)
    tau = rng.uniform(*TAU_RANGE, (N, N))
    np.fill_diagonal(tau, 0.0)
    tau = tau * W7
    X = simulate(W7, tau, T_USE * DT_S + 20.0, dt=DT_INT, eps=EPS,
                 seed=SEED, sample=SAMPLE)[:T_USE]
    reservoirs = [Reservoir(NS, 3, 0.1, 0.3, 0.9, seed=i) for i in range(N)]
    R_all = [reservoirs[i].run(X[:, i, :]) for i in range(N)]
    print(f"[data] X{X.shape} τ∈[{tau[W7==1].min():.3f},{tau[W7==1].max():.3f}] "
          f"({time.time()-t0:.0f}s)", flush=True)

    # ---- 重构 ----
    t_idx = np.arange(K_MAX, N_TR - 1)
    if os.path.exists(CACHE):
        c = pickle.load(open(CACHE, "rb"))
        kbest_all, W_hat = c["kbest"], c["What"]
        print(f"[cache] 复用 {CACHE} 中的重构结果 ({time.time()-t0:.0f}s)",
              flush=True)
    else:
        gain_all, kbest_all, W_hat = {}, {}, np.zeros((N, N), int)
        for i in range(N):
            g, k = argmax_terms(X, i, R_all, t_idx)
            gain_all[i], kbest_all[i] = g, k
            thr = np.mean(list(g.values()))
            for j, v in g.items():
                W_hat[i, j] = int(v > thr)
        pickle.dump(dict(kbest=kbest_all, What=W_hat), open(CACHE, "wb"))
        print(f"[cache] 重构结果已写入 {CACHE} ({time.time()-t0:.0f}s)",
              flush=True)
    true = set((p, q) for p in range(N) for q in range(N) if W7[p, q] == 1)
    hat = set((p, q) for p in range(N) for q in range(N) if W_hat[p, q] == 1)
    TP, FP, FN = len(hat & true), len(hat - true), len(true - hat)
    P = TP / (TP + FP) if TP + FP else 0.0
    R = TP / (TP + FN) if TP + FN else 0.0
    hit = sum(int(abs(kbest_all[i][j] * DT_S - tau[i, j]) <= 0.1)
              for i in range(N) for j in range(N) if W7[i, j] == 1)
    merr = float(np.mean([abs(kbest_all[i][j] * DT_S - tau[i, j])
                          for i in range(N) for j in range(N) if W7[i, j] == 1]))
    print(f"[recon] P={P:.0%} R={R:.0%} FP={FP} 时延={hit}/{len(true)} "
          f"mean|Δτ|={merr:.3f}s ({time.time()-t0:.0f}s)", flush=True)

    def terms_of(which):
        out = {}
        for i in range(N):
            if which == "crc":
                out[i] = [(j, kbest_all[i][j]) for j in range(N) if W_hat[i, j] == 1]
            elif which == "oracle":
                out[i] = [(j, int(round(tau[i, j] / DT_S)))
                          for j in range(N) if W7[i, j] == 1]
            else:
                out[i] = []
        return out

    starts = [START0 + m * STRIDE for m in range(N_START)]
    sigma = np.array([X[N_TR:, i, :].std(axis=0) for i in range(N)])

    res = {"config": dict(eps=EPS, dt_s=DT_S, tau_range=list(TAU_RANGE), Ns=NS,
                          Nc=NC, lam_infer=LAM_INFER, T=T_USE, n_train=N_TR,
                          K_max=K_MAX, seed=SEED, n_start=N_START, S_max=S_MAX),
           "recon": dict(P=P, R=R, FP=FP, hit=hit, n_true=len(true), merr=merr),
           "lam_sweep": {}, "variants": {}}

    # ---- 岭参数扫描 (仅 crc) ----
    tc = terms_of("crc")
    print("\n[λ 扫描]  C-RC(重构) 自由运行", flush=True)
    for lam in LAM_PREDS:
        wl = [fit_out(X[t_idx + 1, i, :].T,
                      features(i, tc[i], R_all, t_idx), lam) for i in range(N)]
        per = free_run(X, tc, wl, reservoirs, R_all, starts, S_MAX, sigma)
        curve = per.mean(axis=(0, 1))
        wnorm = float(np.mean([np.linalg.norm(w) for w in wl]))
        res["lam_sweep"][str(lam)] = dict(
            wnorm=wnorm, nrmse1=round(float(curve[0]), 4),
            keff_05=keff_of(curve, 0.5, S_MAX), keff_10=keff_of(curve, 1.0, S_MAX),
            sat=round(float(curve[-10:].mean()), 3),
            curve=[round(float(v), 4) for v in curve[:60]])
        print(f"  λ={lam:<7g} ||w||={wnorm:9.1f} 一步={curve[0]:.4f} "
              f"k_eff(0.5)={keff_of(curve,0.5,S_MAX):>3} "
              f"k_eff(1.0)={keff_of(curve,1.0,S_MAX):>3} 饱和={curve[-10:].mean():6.2f}",
              flush=True)

    # ---- 三种特征集 (λ_pred = LAM_MAIN) ----
    print(f"\n[对照] λ_pred={LAM_MAIN:g}", flush=True)
    per_by, wl_by = {}, {}
    for which in ["crc", "oracle", "rc"]:
        terms = terms_of(which)
        wl = [fit_out(X[t_idx + 1, i, :].T,
                      features(i, terms[i], R_all, t_idx), LAM_MAIN) for i in range(N)]
        per = free_run(X, terms, wl, reservoirs, R_all, starts, S_MAX, sigma)
        per_by[which], wl_by[which] = per, wl
        curve = per.mean(axis=(0, 1))
        per_i = {i: keff_of(per[i].mean(axis=0), 0.5, S_MAX) for i in range(N)}
        per_i10 = {i: keff_of(per[i].mean(axis=0), 1.0, S_MAX) for i in range(N)}
        res["variants"][which] = dict(
            nrmse1=round(float(curve[0]), 4),
            keff_05=keff_of(curve, 0.5, S_MAX), keff_10=keff_of(curve, 1.0, S_MAX),
            keff_05_per_osc=per_i, keff_10_per_osc=per_i10,
            sat=round(float(curve[-10:].mean()), 3),
            curve=[round(float(v), 4) for v in curve[:80]])
        print(f"  {which:<7} 一步={curve[0]:.4f} k_eff(0.5)={keff_of(curve,0.5,S_MAX):>3} "
              f"k_eff(1.0)={keff_of(curve,1.0,S_MAX):>3} 饱和={curve[-10:].mean():6.2f} "
              f"逐振子(0.5)={list(per_i.values())}", flush=True)

    # ---- 轨迹数据 ----
    terms = terms_of("crc")
    wl = wl_by["crc"]
    per = per_by["crc"]
    keff10 = res["variants"]["crc"]["keff_10"]
    k10 = {int(a): int(b) for a, b in res["variants"]["crc"]["keff_10_per_osc"].items()}
    k05 = {int(a): int(b) for a, b in res["variants"]["crc"]["keff_05_per_osc"].items()}
    best3 = sorted(range(N), key=lambda i: -k10[i])[:3]

    steps = int(min(k10[best3[0]] + 6, S_MAX))   # 略大于最优振子的 k_eff
    # 每个面板各取该振子 20 条误差曲线中与【自身平均曲线】最接近的那一次自由
    # 运行 (代表性实现, 非择优): 保证图中分离位置与其标注的 k_eff 一致
    ks = [keff_of(per[best3[0]][m], 1.0, S_MAX) for m in range(N_START)]
    panels = {}
    for i in best3:
        w = int(min(k10[i] + 6, steps))
        # 代表性实现: 该振子 20 次自由运行中, 自身 k_eff 与全体平均值最接近的那次
        v10 = np.array([keff_of(per[i][m], 1.0, S_MAX) for m in range(N_START)])
        v05 = np.array([keff_of(per[i][m], 0.5, S_MAX) for m in range(N_START)])
        score = np.abs(v10 - k10[i]) + 0.001 * np.abs(v05 - k05[i])
        m_i = int(np.argmin(score))
        tr, pr = traj_run(X, terms, wl, reservoirs, R_all, starts[m_i], w)
        panels[i] = dict(start=int(starts[m_i]), start_idx=m_i, win=w,
                         keff05=k05[i], keff10=k10[i],
                         rep_keff05=keff_of(per[i][m_i], 0.5, S_MAX),
                         rep_keff10=keff_of(per[i][m_i], 1.0, S_MAX),
                         true=[round(float(v), 3) for v in tr[i]],
                         pred=[round(float(v), 3) for v in pr[i]])
        print(f"  panel 振子{i}: 起点={starts[m_i]}(第{m_i}个) 窗口={w} "
              f"k_eff={k05[i]}/{k10[i]} (该实现 {panels[i]['rep_keff05']}/"
              f"{panels[i]['rep_keff10']})", flush=True)
    res["traj"] = dict(steps=steps, best=best3, panels=panels,
                       keff05=k05, keff10=k10,
                       keff05_agg=res["variants"]["crc"]["keff_05"],
                       keff10_agg=keff10, dt_s=DT_S, starts_keff10=ks)
    print(f"[traj] best3={best3} k_eff(1.0)={[k10[i] for i in best3]} "
          f"steps={steps}", flush=True)
    print(f"[traj] 最优振子 20 起点的 k_eff(1.0)={ks}", flush=True)

    json.dump(res, open("results_effective_horizon.json", "w"), indent=1)
    print(f"[done] {time.time()-t0:.0f}s → results_effective_horizon.json", flush=True)


if __name__ == "__main__":
    main()
