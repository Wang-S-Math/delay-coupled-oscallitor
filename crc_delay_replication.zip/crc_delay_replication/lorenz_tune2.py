"""
lorenz_tune2.py — Lorenz 精调第二轮: ε上探 + 储备池配比 + 4种子终验
=================================================================
第一轮(lorenz_tune.py)结论:
  结构全程 P=R=100% FP=0 (Lorenz对配置完全鲁棒, 与Rössler截然不同)
  时延: ε 0.15→0.3→0.6 单调升 7.5→9.5→10.0 (sync=-0.4无同步代价, 强耦合是免费午餐!)
        τ[0.3,1.2] > τ[0.2,0.8] (避开k≈0模糊区)
        大池 Ns=500,Nc=60 > 基线池 300/30 (10.5 vs 9.2); 但 Nc=60配小池Ns=300崩(5.5)
本轮: 固定Δt=0.05(与0.025打平,算力减半), τ∈[0.3,1.2]
  Stage A: ε∈{0.6,1.0,1.5}上探 @ 大池(500,60), 2种子
  Stage B: 最优ε下 储备池配比 (300,30)/(500,60)/(800,80), 2种子
  Stage C: 最终配置 4种子 + 逐边明细(detail=True, 修复v1未打印的bug)
"""
import time
import numpy as np
from pre2025_crc import W7, Reservoir
from lorenz_tune import evaluate


def show(tag, rows, extra=""):
    P = np.mean([r["P"] for r in rows]); R = np.mean([r["R"] for r in rows])
    hit = np.mean([r["hit"] for r in rows]); nt = rows[0]["n_true"]
    FP = np.mean([r["FP"] for r in rows]); merr = np.mean([r["merr"] for r in rows])
    sync = np.mean([r["sync"] for r in rows])
    print(f"{tag:<36} P={P:>5.0%} R={R:>5.0%} FP={FP:>4.1f} 时延={hit:>4.1f}/{nt}"
          f" mean|Δτ|={merr:6.3f}s sync={sync:.2f} {extra}", flush=True)
    return P + R + hit / nt


def main():
    t0 = time.time()
    N = 7
    sample, trng = 10, (0.3, 1.2)   # Δt=0.05, τ∈[0.3,1.2]
    print("=" * 92, flush=True)
    print("Lorenz 精调第二轮: Δt=0.05, τ∈[0.3,1.2] (第一轮最优=10.5/13)", flush=True)
    print("=" * 92, flush=True)

    # Stage A: ε 上探 @ 大池
    print("\n[Stage A] ε上探 @(Ns=500,Nc=60), 2种子", flush=True)
    sA = {}
    for eps in [0.6, 1.0, 1.5]:
        rows = [evaluate(W7, N, sample=sample, eps=eps, tau_range=trng,
                         Ns=500, Nc=60, seed=s) for s in range(2)]
        sA[eps] = show(f"  ε={eps:.1f}", rows)
    best_eps = max(sA, key=sA.get)
    print(f"  ★ 最优 ε={best_eps}", flush=True)

    # Stage B: 储备池配比 @ 最优ε
    print(f"\n[Stage B] 储备池配比 @ε={best_eps}, 2种子", flush=True)
    sB = {}
    for Ns, Nc in [(300, 30), (500, 60), (800, 80)]:
        rows = [evaluate(W7, N, sample=sample, eps=best_eps, tau_range=trng,
                         Ns=Ns, Nc=Nc, seed=s) for s in range(2)]
        sB[(Ns, Nc)] = show(f"  Ns={Ns},Nc={Nc}", rows)
    best_pool = max(sB, key=sB.get)
    print(f"  ★ 最优池 Ns={best_pool[0]},Nc={best_pool[1]}", flush=True)

    # Stage C: 最终配置 4种子 + 逐边明细
    print(f"\n[Stage C] 最终配置 ε={best_eps}, Ns={best_pool[0]},Nc={best_pool[1]}, 4种子", flush=True)
    finals = [evaluate(W7, N, sample=sample, eps=best_eps, tau_range=trng,
                      Ns=best_pool[0], Nc=best_pool[1], seed=s, detail=True)
              for s in range(4)]
    show("  最终(4种子)", finals)
    print(f"\n{'=' * 92}", flush=True)
    print(f"★ Lorenz 最终最优配置: ε={best_eps}, Δt=0.05, τ∈[0.3,1.2], "
          f"Ns={best_pool[0]},Nc={best_pool[1]}", flush=True)
    for s, r in enumerate(finals):
        print(f"   seed{s}: P={r['P']:.0%} R={r['R']:.0%} FP={r['FP']} "
              f"时延={r['hit']}/{r['n_true']} mean|Δτ|={r['merr']:.3f}s max|Δτ|={r['maxerr']:.3f}s", flush=True)
    r = max(finals, key=lambda r: r["hit"])
    print(f"\n   最佳种子逐边明细 (命中判据|Δτ|≤0.1s):", flush=True)
    for (i, j, k, kt, te, tt, err) in sorted(r["edges"]):
        ok = "✓" if err <= 0.1 else "✗"
        print(f"   ({i},{j}) {ok} k*={k:3d}(τ̂={te:.3f}s) vs 真实k={kt:3d}(τ={tt:.3f}s) |Δτ|={err:.3f}s", flush=True)
    print(f"\n第一轮最优: 10.5/13 (ε=0.6,大池) | 调参前基线: 单种子11/13, 多种子~9.5/13", flush=True)
    print(f"总耗时: {time.time() - t0:.1f}s", flush=True)


if __name__ == "__main__":
    main()
