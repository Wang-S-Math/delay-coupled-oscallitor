"""
maxle_dde_rk4.py — 耦合异构时延 Lorenz 网络的最大 Lyapunov 指数（RK4 + 四点 Lagrange DDE）
=============================================================================================
动机: 欧拉 dt=0.005 的 Benettin 给出孤立 Lorenz maxLE≈1.46, 与公认 0.906 不符 —
      前向欧拉离散化系统性放大 Lyapunov 指数。本文件用与 SL/Kuramoto 管线同一方案
      (RK4 + 环形缓冲 + 四点 Lagrange 延迟插值) 积分连续 DDE, 再用 Benettin 单切向量
      重正化法求 maxLE, 先用 ε=0 (孤立) 校准到 0.906, 再算 ε=1.5 耦合网络。

模型: ẋ_p = f_Lorenz(x_p) + ε Σ_q w_pq [x_q(t−τ_pq) − x_p(t)] ·e_y
"""
import time

import numpy as np

from pre2025_crc import W7

A, B, C = 10.0, 28.0, 8.0 / 3.0


def max_le_dde(W, tau, eps, dt=0.005, t_warm=30.0, t_ren=2.0, n_ren=80,
               seed=0, delta=1e-9):
    """RK4+Lagrange DDE, Benettin 单切向量. 返回 maxLE (1/s)."""
    Nn = W.shape[0]
    rng = np.random.default_rng(seed)
    p_idx, q_idx = np.nonzero(W)
    if len(p_idx):
        d_e = np.asarray(tau, float)[p_idx, q_idx] / dt
        d_e = np.maximum(d_e, 1e-9)
        M = int(np.ceil(d_e.max())) + 4
    else:
        d_e = np.zeros(0)
        M = 4

    X0 = rng.uniform(1.0, 5.0, (Nn, 3))
    Wm = W.astype(float)
    E = len(p_idx)

    # 两条轨迹各自的环形历史缓冲 (含当前态)
    Buf = [np.tile(X0, (M, 1, 1)) for _ in range(2)]
    ptr = [M - 1, M - 1]

    def delayed(bf, pt, a):
        """返回 (E,3): 边 q→p 的延迟状态 x_q(t − τ + a·dt)."""
        rel = -d_e + a                    # 相对当前指针的偏移
        i0 = np.floor(rel).astype(np.int64)
        w = rel - i0
        lm1 = w * (w - 1.0) * (w - 2.0) / (-6.0)
        l0 = (w + 1.0) * (w - 1.0) * (w - 2.0) / 2.0
        l1 = (w + 1.0) * w * (w - 2.0) / (-2.0)
        l2 = (w + 1.0) * w * (w - 1.0) / 6.0
        rows = (pt + i0[None, :] + np.array([-1, 0, 1, 2])[:, None]) % M  # (4,E)
        vals = bf[rows, q_idx[None, :]]                 # (4,E,3)
        lw = np.stack([lm1, l0, l1, l2])                # (4,E)
        return np.einsum("ae,aec->ec", lw, vals)

    def rhs(x, xD):
        dX = np.empty_like(x)
        dX[:, 0] = A * (x[:, 1] - x[:, 0])
        dX[:, 1] = B * x[:, 0] - x[:, 1] - x[:, 0] * x[:, 2]
        dX[:, 2] = x[:, 0] * x[:, 1] - C * x[:, 2]
        if E:
            diff = xD - x[p_idx]                      # (E,3)
            # 与 lorenz_tune.simulate 一致: 差取 x 分量(0), 耦合加在 ẏ 分量
            dX[:, 1] += eps * np.bincount(
                p_idx, weights=Wm[p_idx, q_idx] * diff[:, 0], minlength=Nn)
        return dX

    def step_pair():
        """RK4 推进参考与扰动两条轨迹一步(共享同一延迟插值结构)."""
        for s in range(2):
            bf, pt = Buf[s], ptr[s]
            x = bf[pt]
            k1 = rhs(x, delayed(bf, pt, 0.0))
            k2 = rhs(x + 0.5 * dt * k1, delayed(bf, pt, 0.5))
            k3 = rhs(x + 0.5 * dt * k2, delayed(bf, pt, 0.5))
            k4 = rhs(x + dt * k3, delayed(bf, pt, 1.0))
            xn = x + (dt / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4)
            nptr = (pt + 1) % M
            bf[nptr] = xn
            ptr[s] = nptr

    n_warm = int(round(t_warm / dt))
    n_seg = int(round(t_ren / dt))
    for _ in range(n_warm):
        step_pair()

    # 注入切向量(归一化到 delta)
    d0v = rng.standard_normal((Nn, 3))
    d0v /= np.linalg.norm(d0v)
    Buf[1][ptr[1]] = Buf[0][ptr[0]] + delta * d0v

    total = 0.0
    for _ in range(n_ren):
        for _ in range(n_seg):
            step_pair()
        d = float(np.linalg.norm(Buf[1][ptr[1]] - Buf[0][ptr[0]]))
        total += np.log(d / delta)
        Buf[1][ptr[1]] = Buf[0][ptr[0]] + delta * (Buf[1][ptr[1]] - Buf[0][ptr[0]]) / d
    return total / (n_ren * t_ren)


if __name__ == "__main__":
    import sys
    from lorenz_tune import simulate  # noqa: F401  (仅确认同模型)

    rng = np.random.default_rng(0 + 1000)
    tau = rng.uniform(0.3, 1.2, (7, 7))
    np.fill_diagonal(tau, 0.0)
    tau = tau * W7

    t0 = time.time()
    print("— 校准: 孤立 Lorenz (ε=0, 单振子) —", flush=True)
    W1 = np.zeros((1, 1))
    t1 = np.zeros((1, 1))
    for dt in (0.005, 0.002):
        le = max_le_dde(W1, t1, 0.0, dt=dt)
        print(f"  dt={dt:<6g} maxLE={le:.4f}  (公认 0.906)", flush=True)

    print("— 耦合网络 ε=1.5, 异构时延 —", flush=True)
    LEs = []
    for s in (0, 1, 2):
        le = max_le_dde(W7, tau, 1.5, dt=0.005, seed=s)
        LEs.append(le)
        print(f"  seed={s} maxLE={le:.4f}  T_LE={1/le:.4f}s", flush=True)
    LE = float(np.mean(LEs))
    print(f"  mean maxLE={LE:.4f} (σ={np.std(LEs):.3f}) → T_LE={1/LE:.4f}s "
          f"= {1/LE/0.05:.1f} 采样步", flush=True)
    print(f"({time.time()-t0:.0f}s)")
