"""
review_c3_scalar_noise.py — 审稿 1.6: 部分可观测 + 抗噪性
=================================================================
配置: W7, ε=1.5, Δt=0.05, τ∈[0.3,1.2], T=12000, Ns=300, Nc=30, λ=1e-6, 种子0-2.
[A] 观测维度: d_obs=3 (全状态, 主表口径) vs d_obs=1 (仅 x_i(t) 标量)
[B] 加噪: 对状态加高斯白噪 σ = rms/10^(SNR/20), SNR = ∞(clean)/30/20 dB
    (噪声加在全部三个分量上, 观测取前 d_obs 分量; 储备池输入维仍为3)
输出: P/R/F1(mean与gap)、时延命中≤0.1s、exact0/≤1、merr。JSON: results_c3.json
"""
import os
for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
           "NUMEXPR_NUM_THREADS"):
    os.environ[_v] = "1"
import json
import time

import numpy as np

from pre2025_crc import W7, Reservoir
from lorenz_tune import simulate
import review_common as RC

EPS = 1.5
TAU_RANGE = (0.3, 1.2)
DT_S = 0.05
T_USE = 12000


def run(W, seed, d_obs=3, snr_db=None):
    N = W.shape[0]
    tau = RC.make_tau(W, TAU_RANGE, seed)
    t_end = T_USE * DT_S + 20.0
    X = simulate(W, tau, t_end, dt=0.005, eps=EPS, seed=seed, sample=10)[:T_USE]
    if snr_db is not None:
        rms = float(np.sqrt(np.mean(X ** 2)))
        sigma = rms / (10.0 ** (snr_db / 20.0))
        rng = np.random.default_rng(seed + 50000)
        X = X + sigma * rng.standard_normal(X.shape)
    s_sync, rho = RC.sync_metrics(X)
    # 储备池输入维保持3(未观测分量为0输入), 读出目标用前 d_obs 分量
    res = [Reservoir(300, 3, 0.1, 0.3, 0.9, seed=i).run(X[:, i, :])
           for i in range(N)]
    d = RC.full_pipeline(X, W, tau, DT_S, res, d_obs=d_obs)
    d["s_sync"] = s_sync
    d["rho"] = rho
    return d


def show(tag, rows):
    nt = rows[0]["nt"]
    g = lambda k, sub: np.mean([r[sub][k] for r in rows])
    print(f"{tag:<26} n={len(rows)} P={g('P','mean'):.0%} R={g('R','mean'):.0%} "
          f"F1={g('F1','mean'):.3f} | gapF1={g('F1','gap'):.3f} | "
          f"hit={np.mean([r['hit10'] for r in rows]):.1f}/{nt} "
          f"exact0={np.mean([r['exact0'] for r in rows]):.1f} "
          f"exact<=1={np.mean([r['exact1'] for r in rows]):.1f} "
          f"merr={np.mean([r['merr'] for r in rows]):.3f}s", flush=True)
    return dict(
        mean_P=(float(g("P", "mean")), float(np.std([r["mean"]["P"] for r in rows]))),
        mean_R=(float(g("R", "mean")), float(np.std([r["mean"]["R"] for r in rows]))),
        mean_F1=(float(g("F1", "mean")), float(np.std([r["mean"]["F1"] for r in rows]))),
        gap_F1=(float(g("F1", "gap")), float(np.std([r["gap"]["F1"] for r in rows]))),
        hit10=(float(np.mean([r["hit10"] for r in rows])),
               float(np.std([r["hit10"] for r in rows]))),
        exact0=(float(np.mean([r["exact0"] for r in rows])),
                float(np.std([r["exact0"] for r in rows]))),
        exact1=(float(np.mean([r["exact1"] for r in rows])),
                float(np.std([r["exact1"] for r in rows]))),
        merr=(float(np.mean([r["merr"] for r in rows])),
              float(np.std([r["merr"] for r in rows]))),
        nt=nt)


def main():
    t0 = time.time()
    try:
        with open("results_c3_rows.json") as fh:
            raw = json.load(fh)
    except Exception:
        raw = {}
    try:
        with open("results_c3.json") as fh:
            results = json.load(fh)
    except Exception:
        results = {}
    cases = [
        ("d3_clean", dict(d_obs=3, snr_db=None)),
        ("d1_clean", dict(d_obs=1, snr_db=None)),
        ("d3_snr30", dict(d_obs=3, snr_db=30.0)),
        ("d3_snr20", dict(d_obs=3, snr_db=20.0)),
        ("d1_snr30", dict(d_obs=1, snr_db=30.0)),
        ("d1_snr20", dict(d_obs=1, snr_db=20.0)),
    ]
    for name, kw in cases:
        rows = []
        for s in range(3):
            key = f"{name}_s{s}"
            if key in raw:
                rows.append(raw[key])
                continue
            d = run(W7, s, **kw)
            rows.append(d)
            raw[key] = d
            with open("results_c3_rows.json", "w") as fh:
                json.dump(raw, fh, indent=1, default=float)
            print(f"  {name} seed{s}: P={d['mean']['P']:.0%} R={d['mean']['R']:.0%} "
                  f"hit={d['hit10']}/{d['nt']} exact0={d['exact0']} "
                  f"merr={d['merr']:.3f}s [{time.time()-t0:.0f}s]", flush=True)
        results[name] = show(f"[{name}]", rows)
        with open("results_c3.json", "w") as fh:
            json.dump(results, fh, indent=1, default=float)
    print(f"总耗时 {time.time()-t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
