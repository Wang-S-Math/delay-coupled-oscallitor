"""
lorenz_tune.py — Lorenz 异构时延: 系统性调参到最优 (Rössler方法论的Lorenz版)
=================================================================
当前基线 (sindy_argmax.py, 单种子): ε=0.3, Δt=0.05, τ∈[0.2,0.8]s
  → P=R=100%, 时延 11/13 (|Δτ|≤0.1s)
目标: 把可调旋钮全部扫一遍, 找结构100%保持 + 时延命中最大化的配置:
  Stage 1: 耦合强度 ε ∈ {0.15, 0.3, 0.6} (2种子) — 强耦合信号 vs 同步风险
  Stage 2: 采样 Δt ∈ {0.025,0.05,0.10} × 时延范围 τ ∈ {[0.2,0.8],[0.3,1.2]} (2种子)
           — 细采样→k分辨率高; 大τ→远离k≈0模糊区
  Stage 3: 最优配置 4种子稳健性 + 储备池变体 (Nc=60, Ns=500)
命中判据(物理一致): |k*·Δt − τ_true| ≤ 0.1s (等价基线|Δk|≤2@Δt=0.05)
Lorenz: a=10,b=28,c=8/3, 耦合在ẏ(diffusive x), dt_int=0.005 欧拉, T_use=20000
"""
import time
import numpy as np
from pre2025_crc import W7, Reservoir
from sindy_argmax import sindy_argmax


def simulate(W, tau, t_end, dt=0.005, eps=0.3, seed=0, sample=10):
    """向量化解合Lorenz+异构时延. 耦合: ẏ_i += ε·Σ_j w_ij[x_j(t-τ_ij)-x_i]."""
    N = W.shape[0]
    rng = np.random.default_rng(seed)
    X0 = rng.uniform(1.0, 5.0, (N, 3))
    n = int(round(t_end / dt))
    lags = np.zeros((N, N), int)
    for p in range(N):
        for q in range(N):
            if W[p, q] != 0:
                lags[p, q] = max(1, int(round(tau[p, q] / dt)))
    max_lag = int(lags.max()) + 1
    Wm = W.astype(float)
    ar = np.arange(N)
    X = np.tile(X0, (n + 1 + max_lag, 1, 1))
    idx = max_lag
    a, b, c = 10.0, 28.0, 8.0 / 3.0
    dX = np.empty_like(X[0])
    for _ in range(n):
        x = X[idx]
        dX[:, 0] = a * (x[:, 1] - x[:, 0])
        dX[:, 1] = b * x[:, 0] - x[:, 1] - x[:, 0] * x[:, 2]
        dX[:, 2] = x[:, 0] * x[:, 1] - c * x[:, 2]
        lagX = X[idx - lags, ar, 0]
        coup = (Wm * (lagX - x[:, 0][:, None])).sum(axis=1)
        dX[:, 1] += eps * coup
        X[idx + 1] = x + dt * dX
        idx += 1
    return X[max_lag + 1:max_lag + 1 + n:sample]


def evaluate(W, N, sample, eps, tau_range, Ns=300, Nc=30, lam=1e-6,
             seed=0, T_use=20000, dt_int=0.005, detail=False):
    """完整CRC argmax评估. 返回P/R/FP/时延命中(|Δτ|≤0.1s)/mean|Δτ|/sync."""
    dt_s = sample * dt_int
    rng = np.random.default_rng(seed + 1000)
    tau = rng.uniform(*tau_range, (N, N)); np.fill_diagonal(tau, 0.0)
    tau = tau * W
    t_end = T_use * dt_s + 20.0
    X = simulate(W, tau, t_end, dt=dt_int, eps=eps, seed=seed, sample=sample)[:T_use]
    # 同步度: 1 - 平均成对RMS距离/总体RMS (≈0不同步, →1同步)
    xs = X[:, :, 0]
    ref = np.sqrt(np.mean(xs ** 2))
    pair = [np.sqrt(np.mean((xs[:, i] - xs[:, j]) ** 2))
            for i in range(N) for j in range(i + 1, N)]
    sync = 1.0 - np.mean(pair) / (ref + 1e-12)
    reservoirs = [Reservoir(Ns, 3, 0.1, 0.3, 0.9, seed=i).run(X[:, i, :]) for i in range(N)]
    K_max = int(np.ceil(tau[W == 1].max() / dt_s)) + 2
    true = set((p, q) for p in range(N) for q in range(N) if W[p, q] == 1)
    hat = set(); hit = 0; n_true = 0; errs = []; edges = []
    for i in range(N):
        gain_max, k_best = sindy_argmax(X, i, reservoirs, Nc, K_max, lam)
        thr = np.mean(list(gain_max.values()))
        for j, v in gain_max.items():
            if v > thr:
                hat.add((i, j))
        for j in range(N):
            if W[i, j] == 1:
                n_true += 1
                k = k_best.get(j, -1)
                te = tau[i, j]
                err = abs(k * dt_s - te)
                errs.append(err)
                hit += int(err <= 0.1)
                if detail:
                    edges.append((i, j, k, int(round(te / dt_s)), k * dt_s, te, err))
    TP = len(hat & true); FP = len(hat - true); FN = len(true - hat)
    P = TP / (TP + FP) if TP + FP else 0; R = TP / (TP + FN) if TP + FN else 0
    return dict(P=P, R=R, TP=TP, FP=FP, FN=FN, hit=hit, n_true=n_true,
                merr=float(np.mean(errs)), maxerr=float(np.max(errs)),
                sync=float(sync), K_max=K_max, dt_s=dt_s,
                tau_rng=(float(tau[W == 1].min()), float(tau[W == 1].max())),
                edges=edges)


def agg(rows):
    return (np.mean([r["P"] for r in rows]), np.mean([r["R"] for r in rows]),
            np.mean([r["hit"] for r in rows]), rows[0]["n_true"],
            np.mean([r["FP"] for r in rows]), np.mean([r["merr"] for r in rows]),
            np.mean([r["sync"] for r in rows]))


def show(tag, rows, extra=""):
    P, R, hit, nt, FP, merr, sync = agg(rows)
    print(f"{tag:<34} P={P:>5.0%} R={R:>5.0%} FP={FP:>4.1f} 时延={hit:>4.1f}/{nt}"
          f" mean|Δτ|={merr:6.3f}s sync={sync:.2f} {extra}", flush=True)
    return P + R + hit / nt


def main():
    t0 = time.time()
    N = 7
    print("=" * 92, flush=True)
    print("Lorenz 异构时延系统性调参: ε → Δt×τ范围 → 稳健性/储备池 (命中判据|Δτ|≤0.1s)", flush=True)
    print(f"基线: ε=0.3, Δt=0.05, τ∈[0.2,0.8] → P=R=100%, 时延11/13 (单种子)", flush=True)
    print("=" * 92, flush=True)

    # ---------- Stage 1: 耦合强度 ε (Δt=0.05, τ∈[0.2,0.8]) ----------
    print("\n[Stage 1] 耦合强度 ε扫描 (Δt=0.05, τ∈[0.2,0.8], 2种子)", flush=True)
    s1 = {}
    for eps in [0.15, 0.3, 0.6]:
        rows = [evaluate(W7, N, sample=10, eps=eps, tau_range=(0.2, 0.8), seed=s)
                for s in range(2)]
        s1[eps] = show(f"  ε={eps:.2f}", rows)
    best_eps = max(s1, key=s1.get)
    print(f"  ★ 最优 ε={best_eps}", flush=True)

    # ---------- Stage 2: Δt × τ范围 ----------
    print(f"\n[Stage 2] 采样Δt × 时延范围 (ε={best_eps}, 2种子)", flush=True)
    s2 = {}
    for sample, dt_lab in [(5, "0.025"), (10, "0.05"), (20, "0.10")]:
        for trng, tlab in [((0.2, 0.8), "[0.2,0.8]"), ((0.3, 1.2), "[0.3,1.2]")]:
            rows = [evaluate(W7, N, sample=sample, eps=best_eps,
                             tau_range=trng, seed=s) for s in range(2)]
            s2[(sample, trng)] = show(f"  Δt={dt_lab} τ{tlab}", rows,
                                      extra=f"K_max={rows[0]['K_max']}")
    best_cfg, best_score = max(s2.items(), key=lambda kv: kv[1])
    best_sample, best_trng = best_cfg
    print(f"  ★ 最优: Δt={best_sample * 0.005:.3f}s, τ∈{best_trng}", flush=True)

    # ---------- Stage 3: 稳健性 + 储备池变体 ----------
    print(f"\n[Stage 3] 最优配置 4种子稳健性 + 储备池变体 (2种子)", flush=True)
    base = [evaluate(W7, N, sample=best_sample, eps=best_eps,
                     tau_range=best_trng, seed=s) for s in range(4)]
    score = show(f"  最优配置(基线池 Ns=300,Nc=30)", base)
    varA = [evaluate(W7, N, sample=best_sample, eps=best_eps, tau_range=best_trng,
                     Nc=60, seed=s) for s in range(2)]
    scoreA = show(f"  变体A: Nc=60(邻居记忆特征加倍)", varA)
    varB = [evaluate(W7, N, sample=best_sample, eps=best_eps, tau_range=best_trng,
                     Ns=500, Nc=60, seed=s) for s in range(2)]
    scoreB = show(f"  变体B: Ns=500,Nc=60(大储备池)", varB)

    # ---------- 最优细节 ----------
    best_rows = {"base": (base, score), "Nc60": (varA, scoreA), "big": (varB, scoreB)}
    bname = max(best_rows, key=lambda k: best_rows[k][1])
    brows = best_rows[bname][0]
    print(f"\n{'=' * 92}", flush=True)
    print(f"★ 最终最优: ε={best_eps}, Δt={best_sample * 0.005:.3f}s, τ∈{best_trng}, 配置={bname}", flush=True)
    for s, r in enumerate(brows):
        print(f"   seed{s}: P={r['P']:.0%} R={r['R']:.0%} FP={r['FP']} "
              f"时延={r['hit']}/{r['n_true']} mean|Δτ|={r['merr']:.3f}s max|Δτ|={r['maxerr']:.3f}s", flush=True)
    r = max(brows, key=lambda r: r["hit"])
    print(f"\n   最优种子逐边明细 (命中判据|Δτ|≤0.1s):", flush=True)
    for (i, j, k, kt, te, tt, err) in sorted(r["edges"]):
        ok = "✓" if err <= 0.1 else "✗"
        print(f"   ({i},{j}) {ok} k*={k:3d}(τ̂={te:.3f}s) vs 真实k={kt:3d}(τ={tt:.3f}s) |Δτ|={err:.3f}s", flush=True)
    print(f"\n对照基线(调参前): P=R=100%, 时延 11/13 (85%) 单种子", flush=True)
    print(f"总耗时: {time.time() - t0:.1f}s", flush=True)


if __name__ == "__main__":
    main()
