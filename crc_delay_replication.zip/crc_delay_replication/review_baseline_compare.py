# -*- coding: utf-8 -*-
"""
review_baseline_compare.py — 四方法同台对照 (W7, ε=1.5, τ∈[0.3,1.2], 4 种子)
=================================================================
方法:
  (a) crc        本文 C-RC: 储备池字典, 逐邻居 argmax_k 增益 (k=0..K_max)
  (b) sindy      SINDy 时延字典: ẏ_i 回归 [1,x_i,y_i,x_i z_i, x_j(t-τ)], τ 网格=同一字典,
                 得分 = 方差解释率 improvement (复用 het_delay_structure.fit_node_het;
                 基线即真方程的 y 分量, 对 SINDy 最有利的给法)
  (c) sindy_poly 方程无关 SINDy: 基线=局部状态三次多项式基(10 项), 三目标 (ẋ,ẏ,ż)
                 各扫 (j,τ) 加一条延迟 x_j 列, 得分取三目标最大值
  (d) gc         Granger 因果: 双变量 VAR(p) on x 分量, p∈{5,13,26} 取优,
                 得分 = F 统计量, τ̂ = |b_l| 最大滞后
  (e) pre        PRE2025 原方 C-RC: 全网共享单时延先验 τ_try∈{0.3,...,1.2},
                 候选项只含 r_j(t-k_try); 超参 (Ns,Nc)∈{(150,20),(300,30)}; 按 F1 取最优给法

公平性: 同一数据 (lorenz_tune.simulate, dt=0.005, sample=10→Δt=0.05, T=20000,
        初值 seed=s, 时延 seed=s+1000); 同一时延字典范围 k=0..K_max(=26);
        同一判决规则 = 最大间隙判据 (W7 稀疏, 不加回退; 回退版一并存 JSON);
        每方法允许一次小网格调优取优。
条件: clean 与 snr20 (σ=rms/10^(20/20), 三分量加噪, rng seed+50000, 同 §4.7 口径)
指标: P/R/F1 (gap) | 时延命中 |Δτ|≤0.1s (真边 argmax/τ̂) | mean|Δτ| | AUC (真/假边得分) | 墙钟秒
判据后置: 得分字典存 gains_bl_<method>_W7_eps1.5_T20000_s<seed>[_snr20].pkl
JSON: results_baseline_compare.json
"""
import os
for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
           "NUMEXPR_NUM_THREADS"):
    os.environ[_v] = "1"
import json
import time
import pickle
import numpy as np

from pre2025_crc import W7, Reservoir
from lorenz_tune import simulate
import review_common as RC
from het_delay_structure import fit_node_het

DT_S = 0.05
EPS = 1.5
TAU_RANGE = (0.3, 1.2)
T_USE = 20000
SEEDS = (0, 1, 2, 3)
K_MAX = int(np.ceil(TAU_RANGE[1] / DT_S)) + 2   # 26
R_MIN = 1.5
HIT = 0.1
LAM = 1e-6
NS_MAIN, NC_MAIN = 300, 30


# ---------------------------------------------------------------- 判据与指标
def gap_hat(gm, N):
    """最大间隙判据 (无回退): gm={i:{j:score}} → hat 边集."""
    hat = set()
    for i in range(N):
        items = sorted(gm[i].items(), key=lambda x: -x[1])
        g = np.array([v for _, v in items])
        if len(g) < 2:
            hat.add((i, items[0][0]))
            continue
        ratio = g[:-1] / (g[1:] + 1e-30)
        m = int(np.argmax(ratio))
        for j, _ in items[:m + 1]:
            hat.add((i, j))
    return hat


def gap_fb_hat(gm, N, r_min=R_MIN):
    hat = set()
    for i in range(N):
        items = sorted(gm[i].items(), key=lambda x: -x[1])
        g = np.array([v for _, v in items])
        if len(g) < 2:
            hat.add((i, items[0][0]))
            continue
        ratio = g[:-1] / (g[1:] + 1e-30)
        m = int(np.argmax(ratio))
        if ratio[m] < r_min:
            for j, _ in items:
                hat.add((i, j))
        else:
            for j, _ in items[:m + 1]:
                hat.add((i, j))
    return hat


def auc_mw(gm, W, N):
    pos, neg = [], []
    for i in range(N):
        for j, v in gm[i].items():
            (pos if W[i, j] == 1 else neg).append(v)
    if not pos or not neg:
        return float("nan")
    pos = np.array(pos, float); neg = np.array(neg, float)
    wins = sum(np.sum(p > neg) + 0.5 * np.sum(p == neg) for p in pos)
    return float(wins / (len(pos) * len(neg)))


def eval_method(gm, th, W, tau):
    """统一评估: gap 判据 P/R/F1 + gap_fb + 时延命中(真边) + AUC."""
    N = W.shape[0]
    true = {(i, j) for i in range(N) for j in range(N) if W[i, j] == 1}
    d = RC._prf(gap_hat(gm, N), true)
    d_fb = RC._prf(gap_fb_hat(gm, N), true)
    hits = 0; errs = []
    for (i, j) in true:
        e = abs(th[i][j] - tau[i, j])
        errs.append(e)
        hits += int(e <= HIT)
    d.update(gap_fb_F1=d_fb["F1"], gap_fb_P=d_fb["P"], gap_fb_R=d_fb["R"],
             hit=hits, nt=len(true), merr=float(np.mean(errs)),
             auc=auc_mw(gm, W, N))
    return d


# ---------------------------------------------------------------- 方法
def method_crc(X, W, reservoirs):
    N = W.shape[0]
    t0 = time.perf_counter()
    gm, th = {}, {}
    for i in range(N):
        G = RC.gains_full(X, i, reservoirs, NC_MAIN, K_MAX, LAM)
        gm[i] = {j: float(arr.max()) for j, arr in G.items()}
        th[i] = {j: int(np.argmax(arr)) * DT_S for j, arr in G.items()}
    return gm, th, time.perf_counter() - t0


def method_pre(X, W, tau, res_main):
    """单时延先验: 候选项只含 r_j(t-k_try). 网格 τ_try × (Ns,Nc), 按 (F1,AUC) 取优."""
    N = W.shape[0]
    taus_try = [0.3, 0.5, 0.7, 0.9, 1.2]
    hyper_try = [(150, 20, None), (300, 30, res_main)]
    t0 = time.perf_counter()
    best = None
    for (Ns, Nc, res) in hyper_try:
        if res is None:
            res = [Reservoir(Ns, 3, 0.1, 0.3, 0.9, seed=i).run(X[:, i, :])
                   for i in range(N)]
        for tt in taus_try:
            k = int(round(tt / DT_S))
            gm = {}
            for i in range(N):
                base = RC.err_terms(X, i, [], res, Nc, LAM)
                gm[i] = {j: base - RC.err_terms(X, i, [(j, k)], res, Nc, LAM)
                         for j in range(N) if j != i}
            th = {i: {j: tt for j in gm[i]} for i in range(N)}
            d = eval_method(gm, th, W, tau)
            key = (d["F1"], d["auc"])
            if best is None or key > best[0]:
                best = (key, gm, th, tt, (Ns, Nc), d)
    return best[1], best[2], time.perf_counter() - t0, \
        dict(tau_try=best[3], hyper=list(best[4]), metrics=best[5])


def method_sindy(X, W, tau):
    N = W.shape[0]; T = X.shape[0]
    Xf = X.reshape(T, -1)
    tau_grid = np.arange(0, K_MAX + 1) * DT_S
    t0 = time.perf_counter()
    gm, th = {}, {}
    for i in range(N):
        out, _ = fit_node_het(Xf, i, DT_S, tau_grid)
        gm[i] = {j: max(out[j]["improvement"], 0.0) for j in out}
        th[i] = {j: float(out[j]["tau"]) for j in out}
    return gm, th, time.perf_counter() - t0


def method_sindy_poly(X, W, tau):
    """方程无关 SINDy: 基线=局部状态三次多项式基 [1,x,y,z,x²,y²,z²,xy,xz,yz],
    三个分量目标 (ẋ,ẏ,ż) 各扫 (j,τ) 加一条延迟 x_j 列, 得分取三目标最大值."""
    from het_delay_structure import delayed, deriv5
    N = W.shape[0]; T = X.shape[0]
    Xf = X.reshape(T, -1)
    dXf = deriv5(X, DT_S).reshape(T, -1)
    tau_grid = np.arange(0, K_MAX + 1) * DT_S
    t0 = time.perf_counter()
    gm, th = {}, {}
    for i in range(N):
        x, y, z = Xf[:, 3*i], Xf[:, 3*i+1], Xf[:, 3*i+2]
        base_cols = [np.ones_like(x), x, y, z, x*x, y*y, z*z,
                     x*y, x*z, y*z]
        gm[i] = {}; th[i] = {}
        for j in range(N):
            if j == i:
                continue
            best_imp, best_tau = 0.0, 0.0
            for c in range(3):
                target = dXf[:, 3*i+c]
                blib = np.column_stack(base_cols)
                ob, *_ = np.linalg.lstsq(blib, target, rcond=None)
                base_rss = float(np.linalg.norm(target - blib @ ob) ** 2)
                col = Xf[:, 3*j]
                for tt in tau_grid:
                    lib = np.column_stack(base_cols + [delayed(col, DT_S, tt)])
                    om, *_ = np.linalg.lstsq(lib, target, rcond=None)
                    rss = float(np.linalg.norm(target - lib @ om) ** 2)
                    imp = (base_rss - rss) / (base_rss + 1e-30)
                    if imp > best_imp:
                        best_imp, best_tau = imp, float(tt)
            gm[i][j] = max(best_imp, 0.0)
            th[i][j] = best_tau
    return gm, th, time.perf_counter() - t0


def _var_f(yi, yj, p):
    """双变量 VAR(p): x_i(t) ~ [1, x_i 滞后 p, x_j 滞后 p]. 返回 (F, τ̂)."""
    T = len(yi)

    def lags(col):
        return np.column_stack([col[p - 1 - l:T - 1 - l] for l in range(p)])

    Li = lags(yi); Lj = lags(yj)
    t = yi[p:]
    one = np.ones((len(t), 1))
    Xr = np.hstack([one, Li])
    Xu = np.hstack([one, Li, Lj])
    br, *_ = np.linalg.lstsq(Xr, t, rcond=None)
    bu, *_ = np.linalg.lstsq(Xu, t, rcond=None)
    rss_r = float(np.sum((t - Xr @ br) ** 2))
    rss_u = float(np.sum((t - Xu @ bu) ** 2))
    df = max(T - p - 1 - (1 + 2 * p), 1)
    F = ((rss_r - rss_u) / p) / (rss_u / df)
    B = bu[1 + p:]                        # x_j 滞后系数, 滞后 l+1
    lstar = int(np.argmax(np.abs(B)))
    return float(F), (lstar + 1) * DT_S


def method_gc(X, W, tau):
    N = W.shape[0]
    xs = X[:, :, 0]
    t0 = time.perf_counter()
    best = None
    for p in (5, 13, 26):
        gm, th = {}, {}
        for i in range(N):
            gm[i] = {}; th[i] = {}
            for j in range(N):
                if j == i:
                    continue
                F, tauhat = _var_f(xs[:, i], xs[:, j], p)
                gm[i][j] = F
                th[i][j] = tauhat
        d = eval_method(gm, th, W, tau)
        key = (d["F1"], d["auc"])
        if best is None or key > best[0]:
            best = (key, gm, th, p, d)
    return best[1], best[2], time.perf_counter() - t0, \
        dict(p=best[3], metrics=best[4])


# ---------------------------------------------------------------- 主流程
METHODS = ("crc", "sindy", "sindy_poly", "gc", "pre")


def run_condition(X, W, tau, seed, tag):
    N = W.shape[0]
    res = [Reservoir(NS_MAIN, 3, 0.1, 0.3, 0.9, seed=i).run(X[:, i, :])
           for i in range(N)]
    methods = {}
    gm, th, wt = method_crc(X, W, res)
    methods["crc"] = (gm, th, wt, {})
    gm, th, wt, info = method_pre(X, W, tau, res)
    methods["pre"] = (gm, th, wt, info)
    gm, th, wt = method_sindy(X, W, tau)
    methods["sindy"] = (gm, th, wt, {})
    gm, th, wt = method_sindy_poly(X, W, tau)
    methods["sindy_poly"] = (gm, th, wt, {})
    gm, th, wt, info = method_gc(X, W, tau)
    methods["gc"] = (gm, th, wt, info)

    out = {}
    for m, (gm, th, wt, info) in methods.items():
        d = eval_method(gm, th, W, tau)
        d["wall_s"] = wt
        d.update(info)
        out[m] = d
        suffix = "" if tag == "clean" else f"_{tag}"
        with open(f"gains_bl_{m}_W7_eps1.5_T20000_s{seed}{suffix}.pkl",
                  "wb") as f:
            pickle.dump(dict(W=W, tau=tau, gains=gm, tauhat=th,
                             K_max=K_MAX, dt_s=DT_S, N=N, T=T_USE,
                             seed=seed, eps=EPS, cond=tag), f)
    return out


def run_seed(seed):
    N = W7.shape[0]
    tau = RC.make_tau(W7, TAU_RANGE, seed)
    t_end = T_USE * DT_S + 20.0
    X = simulate(W7, tau, t_end, dt=0.005, eps=EPS, seed=seed, sample=10)[:T_USE]
    s_sync, rho = RC.sync_metrics(X)
    out = {"seed": seed, "s_sync": s_sync, "rho": rho}
    out["clean"] = run_condition(X, W7, tau, seed, "clean")
    # 与 §4.7 同口径: σ = rms/10^(SNR/20), 加在全部三个分量, rng seed+50000
    rms = float(np.sqrt(np.mean(X ** 2)))
    sigma = rms / (10.0 ** (20.0 / 20.0))
    rng = np.random.default_rng(seed + 50000)
    Xn = X + sigma * rng.standard_normal(X.shape)
    out["snr20"] = run_condition(Xn, W7, tau, seed, "snr20")
    return out


def main():
    t0 = time.perf_counter()
    print(f"W7 eps={EPS} tau∈{TAU_RANGE} T={T_USE} K_max={K_MAX} seeds={SEEDS}",
          flush=True)
    rows = []
    for s in SEEDS:
        r = run_seed(s)
        rows.append(r)
        line = f"[seed {s}] s_sync={r['s_sync']:.2f}"
        for cond in ("clean", "snr20"):
            for m in METHODS:
                d = r[cond][m]
                line += (f" | {cond}/{m}: F1={d['F1']:.3f}"
                         f" hit={d['hit']}/{d['nt']} AUC={d['auc']:.3f}")
        print(line, flush=True)

    keys = ["P", "R", "F1", "gap_fb_F1", "hit", "merr", "auc", "wall_s"]
    agg = {}
    for cond in ("clean", "snr20"):
        print(f"\n== 4-seed mean±std [{cond}] (gap 判据; "
              f"hit=|Δτ|≤0.1s /13) ==", flush=True)
        hdr = f"{'method':<11}" + "".join(f"{k:>14}" for k in keys)
        print(hdr, flush=True)
        agg[cond] = {}
        for m in METHODS:
            vals = []
            for k in keys:
                v = np.array([r[cond][m][k] for r in rows], float)
                vals.append(f"{v.mean():>8.3f}±{v.std():.3f}")
            agg[cond][m] = {k: [r[cond][m][k] for r in rows] for k in keys}
            print(f"{m:<11}" + "".join(f"{s:>14}" for s in vals), flush=True)
    # PRE 选中配置
    print("\nPRE selected:", [f"seed{s}: clean τ={r['clean']['pre']['tau_try']}, "
                              f"Ns,Nc={tuple(r['clean']['pre']['hyper'])}; "
                              f"snr20 τ={r['snr20']['pre']['tau_try']}"
                              for s, r in zip(SEEDS, rows)], flush=True)
    print("GC selected p:", [f"clean={r['clean']['gc']['p']}, "
                              f"snr20={r['snr20']['gc']['p']}" for r in rows],
          flush=True)

    json.dump(dict(config=dict(eps=EPS, tau_range=list(TAU_RANGE), T=T_USE,
                               K_max=K_MAX, seeds=list(SEEDS), dt_s=DT_S),
                   per_seed=rows, agg=agg),
              open("results_baseline_compare.json", "w"),
              ensure_ascii=False, indent=1, default=float)
    print(f"\ntotal {time.perf_counter()-t0:.0f}s -> results_baseline_compare.json",
          flush=True)


if __name__ == "__main__":
    main()
