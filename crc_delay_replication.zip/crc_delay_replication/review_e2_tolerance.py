# -*- coding: utf-8 -*-
"""
review_e2_tolerance.py — E2: 时延命中判据 P0/P1/P2 重算(纯缓存, 零模拟)
=========================================================================
论文现用 ±2 步(±0.1)作命中判据, 但 §4.1 又报 mean|Δτ|=0.018 < 半个采样步,
判据比实测精度松 5 倍, 字面自相矛盾; 且 ±2 步窗口在 K_max=26 字典里盲猜
命中率就有 ~19%。本脚本对全部缓存拓扑重算 P0(精确)/P1(±1步)/P2(±2步),
并给出盲猜基线, 供正文把主判据改为 P1。

数据源:
  (a) results_c1.json — W7 基准 4 种子(exact0/exact1/hit2 已有, 直接读出核对)
  (b) gains_*_N*_T*.pkl — 6 泛化拓扑各 1 种子, 由 kb*dt_s vs tau 重算
"""
import glob
import json
import os
import pickle

import numpy as np

EXCL = {"无标度BA_N7_N7_T20000", "环_N10_N10_T20000", "环_N20_N20_T12000",
        "随机ER_N10_N10_T20000"}


def counts(kb, tau, W, N, dt_s):
    n = 0
    p0 = p1 = p2 = 0
    errs = []
    for i in range(N):
        for j in range(N):
            if W[i, j] == 1:
                n += 1
                err = abs(kb[i][j] * dt_s - tau[i, j])
                errs.append(err)
                dk = abs(kb[i][j] - int(round(tau[i, j] / dt_s)))
                p0 += int(err <= 1e-9 or dk == 0)
                p1 += int(dk <= 1)
                p2 += int(dk <= 2)
    return p0, p1, p2, n, float(np.mean(errs))


print("=" * 100)
print("(a) W7 基准 4 种子 (results_c1.json)")
print("=" * 100)
d = json.load(open("results_c1.json", encoding="utf-8"))
tp0 = tp1 = tp2 = tn = 0
for k in sorted(d):
    if not k.startswith("Euler"):
        continue
    r = d[k]
    print(f"  {k:<12} exact0={r['exact0']:>2} exact1={r['exact1']:>2} "
          f"hit(±2)={r['hit10']:>2} /{r['nt']}  merr={r['merr']:.4f}")
    tp0 += r["exact0"]; tp1 += r["exact1"]; tp2 += r["hit10"]; tn += r["nt"]
print(f"  pooled: P0={tp0}/{tn}={tp0/tn:.0%}  P1={tp1}/{tn}={tp1/tn:.0%}  "
      f"P2={tp2}/{tn}={tp2/tn:.0%}")

print()
print("=" * 100)
print("(b) 6 泛化拓扑 (gains_*_N*_T*.pkl, 各 1 种子)")
print("=" * 100)
rows = []
for f in sorted(glob.glob("gains_*_N*_T*.pkl")):
    name = os.path.basename(f).replace("gains_", "").replace(".pkl", "")
    if name in EXCL:
        continue
    if not (name.startswith("随机ER") or name.startswith("环_N7")
            or name.startswith("W7_基准")):
        continue
    D = pickle.load(open(f, "rb"))
    W, tau, kb, N, dt_s = D["W"], D["tau"], D["kb"], D["N"], D["dt_s"]
    K_max = D["K_max"]
    p0, p1, p2, n, merr = counts(kb, tau, W, N, dt_s)
    guess1 = min(3, K_max + 1) / (K_max + 1)
    guess2 = min(5, K_max + 1) / (K_max + 1)
    rows.append((name, N, n, p0, p1, p2, merr, K_max))
    print(f"  {name:<26} N={N:>2} E={n:>3} | P0={p0:>3}/{n}={p0/n:>4.0%} "
          f"P1={p1:>3}/{n}={p1/n:>4.0%} P2={p2:>3}/{n}={p2/n:>4.0%} "
          f"merr={merr:.4f} K_max={K_max} 盲猜P1={guess1:.0%} P2={guess2:.0%}")

if rows:
    n = sum(r[2] for r in rows)
    print(f"\n  pooled over {len(rows)} cached topologies: "
          f"P0={sum(r[3] for r in rows)}/{n}={sum(r[3] for r in rows)/n:.0%}  "
          f"P1={sum(r[4] for r in rows)}/{n}={sum(r[4] for r in rows)/n:.0%}  "
          f"P2={sum(r[5] for r in rows)}/{n}={sum(r[5] for r in rows)/n:.0%}")
