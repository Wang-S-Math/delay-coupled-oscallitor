"""effective_horizon_opt.py — 结构与时延【已知】前提下的有效预测步数超参数优化
================================================================================
与论文 §4.1 基准网络一致: W7, ε=1.5, Δt=0.05s, τ∈[0.3,1.2]s, 种子 0。

与旧版 effective_horizon.py 的区别 (按用户要求):
 1. 不再用重构的 Ŵ/τ̂ — 直接假设<b>网络结构与异构时延已知</b>(真边 + 真时延),
    把"重构误差"与"推演能力"解耦, 单独评估 C-RC 管线的向前推演上限。
 2. 对预测管线做<b>超参数优化</b>: 扫描 α(泄漏率)、ρ_res(谱半径)、N_s、N_c、
    稀疏度、λ_pred(预测读出岭参数), 以 k_eff(θ=1.0) 为主目标、
    k_eff(θ=0.5) 与一步 NRMSE 为次目标, 分阶段坐标搜索。
 3. 结果同时折算为<b>李雅普诺夫时间</b>: 在与数据完全相同的生成映射
    (Euler dt=0.005, 时延取整到步) 上、数据所在吸引子 (seed=0) 上测
    耦合网络 maxLE — Benettin 段长必须 > τ_max=1.2s (取 t_ren=10s),
    短段会被延迟线噪声污染; 连续 DDE 多稳态故不用 RK4 分支值。
    T_LE = 1/maxLE; k_eff 的 Lyapunov 时间数 = k_eff·Δt / T_LE。
    实测 λ≈1.16-1.23 /s → T_LE≈0.86s≈17 步 (孤立对照≈1.14-1.19)。

流程:
 Stage 0  数据 + 耦合网络 maxLE
 Stage A  (α, ρ_res) 网格 @ Ns=300,Nc=30,sp=0.1,λ=1e-2   (搜索段 T=8000)
 Stage B  (Ns, Nc) 网格 @ 最优 (α,ρ)
 Stage C  λ_pred 扫描 @ 最优储备池 (复用储备池状态, 只重拟合读出)
 Stage D  稀疏度扫描 @ 最优
 Final    最优配置全量评估 (T=20000, 20 起点, S=300) + 默认配置对照
          + 普通 RC(无邻居) 对照 + 图 2 轨迹面板
"""
import json
import time

import numpy as np

from pre2025_crc import W7, Reservoir
from lorenz_tune import simulate

N = 7
DT_INT, SAMPLE = 0.005, 10
DT_S = DT_INT * SAMPLE
EPS = 1.5
TAU_RANGE = (0.3, 1.2)
SEED = 0
K_MAX = 26
THETA_STRICT, THETA_MAIN = 0.5, 1.0

# 搜索段 / 全量段
S_T, S_TR, S_NS, S_S = 8000, 6000, 8, 150
F_T, F_TR, F_NS, F_S = 20000, 15000, 20, 300
START0, STRIDE = F_TR + 500, 100


def max_le_benettin(W, tau, eps, dt, t_warm=20.0, t_ren=2.0, n_ren=60,
                    seed=0, delta=1e-9):
    """耦合网络(异构时延)的最大 Lyapunov 指数 — Benettin 单切向量法.
    与 lorenz_tune.simulate 同一积分(欧拉 dt, 时延取整到步); 每段 t_ren 后
    把扰动距离缩回 delta 并累加 log 增长."""
    Nn = W.shape[0]
    rng = np.random.default_rng(seed)
    X0 = rng.uniform(1.0, 5.0, (Nn, 3))
    lags = np.zeros((Nn, Nn), int)
    for p in range(Nn):
        for q in range(Nn):
            if W[p, q] != 0:
                lags[p, q] = max(1, int(round(tau[p, q] / dt)))
    max_lag = int(lags.max()) + 1
    Wm = W.astype(float)
    ar = np.arange(Nn)
    a, b, c = 10.0, 28.0, 8.0 / 3.0

    def step(X, idx):
        x = X[idx]
        dX = np.empty_like(x)
        dX[:, 0] = a * (x[:, 1] - x[:, 0])
        dX[:, 1] = b * x[:, 0] - x[:, 1] - x[:, 0] * x[:, 2]
        dX[:, 2] = x[:, 0] * x[:, 1] - c * x[:, 2]
        lagX = X[idx - lags, ar, 0]
        coup = (Wm * (lagX - x[:, 0][:, None])).sum(axis=1)
        dX[:, 1] += eps * coup
        X[idx + 1] = x + dt * dX

    n_warm = int(round(t_warm / dt))
    n_seg = int(round(t_ren / dt))
    n_tot = max_lag + 1 + n_warm + n_ren * n_seg + 1
    X = np.tile(X0, (n_tot, 1, 1))
    idx = max_lag
    for _ in range(n_warm):
        step(X, idx)
        idx += 1
    total = 0.0
    tsum = 0.0
    for _ in range(n_ren):
        Xp = X[idx - max_lag: idx + n_seg + 1].copy()
        d0v = rng.standard_normal((Nn, 3))
        d0v /= np.linalg.norm(d0v)
        Xp[max_lag] = Xp[max_lag] + delta * d0v
        ip = max_lag
        for _ in range(n_seg):
            step(Xp, ip)
            step(X, idx)
            ip += 1
            idx += 1
        d = np.linalg.norm(Xp[ip] - X[idx])
        total += np.log(d / delta)
        tsum += t_ren
    return total / tsum


def make_data(T):
    rng = np.random.default_rng(SEED + 1000)
    tau = rng.uniform(*TAU_RANGE, (N, N))
    np.fill_diagonal(tau, 0.0)
    tau = tau * W7
    X = simulate(W7, tau, T * DT_S + 20.0, dt=DT_INT, eps=EPS,
                 seed=SEED, sample=SAMPLE)[:T]
    return X, tau


def fit_out(U, R, lam):
    A = R @ R.T + lam * np.eye(R.shape[0])
    return np.linalg.solve(A, R @ U.T).T


def features(i, terms, R_all, t_idx, NC):
    parts = [R_all[i][t_idx, :]]
    for (j, k) in terms:
        parts.append(R_all[j][t_idx - k, :NC])
    return np.hstack(parts).T


def free_run(X, terms, w_list, reservoirs, R_all, starts, S, sigma, NC):
    """返回 per (N, n_start, S): 每步按分量归一的 NRMSE。
    跨起点批量: buf[i] (M, K_MAX+S+1, Ns), 每步只做 N 次矩阵乘。"""
    M = len(starts)
    per = np.zeros((N, M, S))
    a = reservoirs[0].alpha
    # buf[i]: (M, K_MAX+S+1, Ns) — 每个起点一个窗口, 列索引 = (t - t0m) + K_MAX
    buf = [np.stack([R_all[i][t0 - K_MAX: t0 + S + 1].copy()
                     for t0 in starts]) for i in range(N)]
    for s in range(1, S + 1):
        ph = np.zeros((M, N, 3))
        for i in range(N):
            cols = [buf[i][:, s - 1 + K_MAX, :]]
            for (j, k) in terms[i]:
                cols.append(buf[j][:, s - 1 - k + K_MAX, :NC])
            F = np.concatenate(cols, axis=1)          # (M, Ns+d·NC)
            ph[:, i, :] = F @ w_list[i].T             # w_i: (3, feat) → (M,3)
        for i in range(N):
            tgt = np.stack([X[starts[m] + s, i, :] for m in range(M)])
            per[i, :, s - 1] = np.sqrt(np.mean(
                ((ph[:, i, :] - tgt) / sigma[i]) ** 2, axis=1))
        for i in range(N):
            res = reservoirs[i]
            cur = buf[i][:, s - 1 + K_MAX, :]
            buf[i][:, s + K_MAX, :] = (1 - a) * cur + a * np.tanh(
                cur @ res.Wres.T + ph[:, i, :] @ res.Win.T + res.bk)
    return per


def keff_of(curve, theta, S):
    idx = np.where(curve > theta)[0]
    return int(idx[0]) if len(idx) else S


def build_reservoirs(cfg):
    return [Reservoir(cfg["Ns"], 3, cfg["sparsity"], cfg["alpha"],
                      cfg["rho"], seed=i) for i in range(N)]


def oracle_terms(tau):
    return {i: [(j, int(round(tau[i, j] / DT_S)))
                for j in range(N) if W7[i, j] == 1] for i in range(N)}


def eval_with_states(R_all, reservoirs, X, terms, t_idx, starts, S, sigma,
                     lam, NC):
    wl = [fit_out(X[t_idx + 1, i, :].T,
                  features(i, terms[i], R_all, t_idx, NC), lam)
          for i in range(N)]
    per = free_run(X, terms, wl, reservoirs, R_all, starts, S, sigma, NC)
    curve = per.mean(axis=(0, 1))
    return dict(
        keff05=keff_of(curve, THETA_STRICT, S),
        keff10=keff_of(curve, THETA_MAIN, S),
        nrmse1=round(float(curve[0]), 4),
        sat=round(float(curve[-10:].mean()), 3),
        curve=[round(float(v), 4) for v in curve[:min(120, S)]],
    ), per, wl


def eval_cfg(cfg, X, tau, t_idx, starts, S, sigma, NC=None):
    NC = NC or cfg["Nc"]
    reservoirs = build_reservoirs(cfg)
    R_all = [r.run(X[:, i, :]) for i, r in enumerate(reservoirs)]
    terms = oracle_terms(tau)
    out, _, _ = eval_with_states(R_all, reservoirs, X, terms, t_idx, starts,
                                 S, sigma, cfg["lam_pred"], NC)
    return out


def score(out):
    """主目标 k_eff(1.0); 次目标 k_eff(0.5); 再一步误差(越小越好)。"""
    return (out["keff10"], out["keff05"], -out["nrmse1"])


def main():
    t0 = time.time()
    X, tau = make_data(F_T)
    # 段长 t_ren=10s > τ_max=1.2s: 短段(t_ren≤2s)会混入延迟线离散化噪声,
    # 把 λ 虚高到 8-11/s; 长段收敛到 1.16-1.23/s (见 _le_final.log)
    LEs = [max_le_benettin(W7, tau, EPS, DT_INT, t_warm=30.0, t_ren=10.0,
                           n_ren=20, seed=s) for s in (0, 1, 2)]
    LE = float(np.mean(LEs))
    T_LE = 1.0 / LE
    print(f"[maxLE] 耦合网络 maxLE={LE:.4f} (seeds={np.round(LEs,3).tolist()}, "
          f"σ={np.std(LEs):.3f}) → T_LE={T_LE:.4f}s = {T_LE/DT_S:.1f} 步 "
          f"({time.time()-t0:.0f}s)", flush=True)

    def lyap_units(k):
        return round(k * DT_S / T_LE, 2)

    log = {"maxLE": LE, "T_LE_s": T_LE, "T_LE_steps": T_LE / DT_S,
           "search": [], "final": {}}

    # ---------------- 搜索段数据 ----------------
    Xs, taus = make_data(S_T)
    t_idx_s = np.arange(K_MAX, S_TR - 1)
    sigma_s = np.array([Xs[S_TR:, i, :].std(axis=0) for i in range(N)])
    starts_s = [S_TR + 300 + m * 100 for m in range(S_NS)]

    def run_search(cfg, tag):
        out = eval_cfg(cfg, Xs, taus, t_idx_s, starts_s, S_S, sigma_s)
        log["search"].append(dict(tag=tag, **{k: v for k, v in cfg.items()},
                                  **{k: out[k] for k in
                                     ("keff05", "keff10", "nrmse1", "sat")}))
        print(f"  [{tag}] α={cfg['alpha']:<4g} ρ={cfg['rho']:<5g} "
              f"Ns={cfg['Ns']:<4d} Nc={cfg['Nc']:<4d} sp={cfg['sparsity']:<5g} "
              f"λ={cfg['lam_pred']:<7g} → k_eff={out['keff05']}/{out['keff10']} "
              f"一步={out['nrmse1']:.4f} 饱和={out['sat']} "
              f"({time.time()-t0:.0f}s)", flush=True)
        return out

    base = dict(Ns=300, Nc=30, sparsity=0.1, alpha=0.3, rho=0.9,
                lam_pred=1e-2)

    # ---- Stage A: (α, ρ) ----
    print("\n[Stage A] α × ρ_res @ Ns=300,Nc=30", flush=True)
    bestA, bestA_out = None, None
    for a in (0.1, 0.2, 0.3, 0.5):
        for rho in (0.8, 0.9, 0.95):
            cfg = dict(base, alpha=a, rho=rho)
            out = run_search(cfg, "A")
            if bestA_out is None or score(out) > score(bestA_out):
                bestA, bestA_out = cfg, out

    # ---- Stage B: (Ns, Nc) ----
    print("\n[Stage B] Ns × Nc @ 最优(α,ρ)", flush=True)
    bestB, bestB_out = bestA, bestA_out
    for Ns in (300, 500):
        for Nc in (30, 60, 100):
            cfg = dict(bestA, Ns=Ns, Nc=Nc)
            out = run_search(cfg, "B")
            if score(out) > score(bestB_out):
                bestB, bestB_out = cfg, out

    # ---- Stage C: λ_pred (复用最优储备池) ----
    print("\n[Stage C] λ_pred @ 最优储备池 (复用状态)", flush=True)
    reservoirs = build_reservoirs(bestB)
    R_all = [r.run(Xs[:, i, :]) for i, r in enumerate(reservoirs)]
    terms = oracle_terms(taus)
    bestC, bestC_out = dict(bestB), bestB_out
    for lam in (1e-5, 1e-4, 1e-3, 1e-2, 3e-2, 1e-1):
        cfg = dict(bestB, lam_pred=lam)
        out, _, _ = eval_with_states(R_all, reservoirs, Xs, terms, t_idx_s,
                                     starts_s, S_S, sigma_s, lam, cfg["Nc"])
        log["search"].append(dict(tag="C", **{k: v for k, v in cfg.items()},
                                  **{k: out[k] for k in
                                     ("keff05", "keff10", "nrmse1", "sat")}))
        print(f"  [C] λ={lam:<7g} → k_eff={out['keff05']}/{out['keff10']} "
              f"一步={out['nrmse1']:.4f} 饱和={out['sat']} "
              f"({time.time()-t0:.0f}s)", flush=True)
        if score(out) > score(bestC_out):
            bestC, bestC_out = cfg, out
    del R_all, reservoirs

    # ---- Stage D: 稀疏度 ----
    print("\n[Stage D] sparsity @ 最优", flush=True)
    bestD, bestD_out = dict(bestC), bestC_out
    for sp in (0.05, 0.2):
        cfg = dict(bestC, sparsity=sp)
        out = run_search(cfg, "D")
        if score(out) > score(bestD_out):
            bestD, bestD_out = cfg, out

    best = bestD
    print(f"\n[best] {best}  搜索段 k_eff={bestD_out['keff05']}/"
          f"{bestD_out['keff10']}", flush=True)
    log["best_cfg"] = best

    # ---------------- 全量评估 ----------------
    print("\n[Final] 全量评估 (T=20000, 20 起点, S=300)", flush=True)
    t_idx_f = np.arange(K_MAX, F_TR - 1)
    sigma_f = np.array([X[F_TR:, i, :].std(axis=0) for i in range(N)])
    starts_f = [START0 + m * STRIDE for m in range(F_NS)]

    def full_eval(cfg, tag, terms=None):
        reservoirs = build_reservoirs(cfg)
        R_all = [r.run(X[:, i, :]) for i, r in enumerate(reservoirs)]
        terms = terms or oracle_terms(tau)
        out, per, wl = eval_with_states(R_all, reservoirs, X, terms, t_idx_f,
                                        starts_f, F_S, sigma_f,
                                        cfg["lam_pred"], cfg["Nc"])
        k05 = {i: keff_of(per[i].mean(axis=0), THETA_STRICT, F_S)
               for i in range(N)}
        k10 = {i: keff_of(per[i].mean(axis=0), THETA_MAIN, F_S)
               for i in range(N)}
        out["keff05_per_osc"] = k05
        out["keff10_per_osc"] = k10
        out["cfg"] = cfg
        log["final"][tag] = out
        print(f"  [{tag}] k_eff(agg)={out['keff05']}/{out['keff10']} "
              f"一步={out['nrmse1']:.4f} 饱和={out['sat']} "
              f"k_eff(1.0)逐振子={list(k10.values())} ({time.time()-t0:.0f}s)",
              flush=True)
        return out, per, wl, R_all, reservoirs, terms

    out_best, per_b, wl_b, R_b, res_b, terms_b = full_eval(best, "optimized")
    out_def, _, _, _, _, _ = full_eval(base, "default")
    out_rc, _, _, _, _, _ = full_eval(best, "plain_rc",
                                      terms={i: [] for i in range(N)})

    for tag, out in (("optimized", out_best), ("default", out_def),
                     ("plain_rc", out_rc)):
        out["keff10_lyap"] = lyap_units(out["keff10"])
        out["keff05_lyap"] = lyap_units(out["keff05"])
        out["keff10_per_osc_lyap"] = {i: lyap_units(v)
                                      for i, v in out["keff10_per_osc"].items()}
        print(f"  [{tag}] k_eff(1.0)={out['keff10']}步={out['keff10_lyap']} "
              f"个 Lyapunov 时间; k_eff(0.5)={out['keff05']}步="
              f"{out['keff05_lyap']}", flush=True)

    # ---- 图 2 面板: 最优配置下 k_eff 最大的 3 个振子 ----
    k10 = out_best["keff10_per_osc"]
    k05 = out_best["keff05_per_osc"]
    best3 = sorted(range(N), key=lambda i: -k10[i])[:3]
    panels = {}
    for i in best3:
        w = int(min(k10[i] + 6, F_S))
        v10 = np.array([keff_of(per_b[i][m], THETA_MAIN, F_S)
                        for m in range(F_NS)])
        v05 = np.array([keff_of(per_b[i][m], THETA_STRICT, F_S)
                        for m in range(F_NS)])
        m_i = int(np.argmin(np.abs(v10 - k10[i]) + 0.001 * np.abs(v05 - k05[i])))
        # 单起点自由运行, 记录 x 分量轨迹
        NC = best["Nc"]
        a = res_b[0].alpha
        t0s = starts_f[m_i]
        buf = [R_b[j][t0s - K_MAX: t0s + w + 1].copy() for j in range(N)]
        true = np.zeros((N, w))
        pred = np.zeros((N, w))
        for s in range(1, w + 1):
            t = t0s + s
            mcur = (t - 1) - t0s + K_MAX
            ph = np.zeros((N, 3))
            for j in range(N):
                f = [buf[j][mcur]]
                for (q, k) in terms_b[j]:
                    f.append(buf[q][(t - 1 - k) - t0s + K_MAX][:NC])
                ph[j] = wl_b[j] @ np.concatenate(f)
            for j in range(N):
                true[j, s - 1] = X[t, j, 0]
                pred[j, s - 1] = ph[j, 0]
            for j in range(N):
                rj = res_b[j]
                buf[j][t - t0s + K_MAX] = (1 - a) * buf[j][mcur] + a * np.tanh(
                    rj.Win @ ph[j] + rj.Wres @ buf[j][mcur] + rj.bk)
        panels[i] = dict(start=int(t0s), start_idx=m_i, win=w,
                         keff05=k05[i], keff10=k10[i],
                         keff10_lyap=lyap_units(k10[i]),
                         rep_keff10=keff_of(per_b[i][m_i], THETA_MAIN, F_S),
                         true=[round(float(v), 3) for v in true[i]],
                         pred=[round(float(v), 3) for v in pred[i]])
        print(f"  [panel] 振子{i}: k_eff={k05[i]}/{k10[i]} "
              f"({lyap_units(k10[i])} T_LE) 窗口={w} 起点={t0s}", flush=True)
    log["traj"] = dict(best=best3, panels=panels, keff05=k05, keff10=k10,
                       keff10_lyap={i: lyap_units(v) for i, v in k10.items()},
                       dt_s=DT_S)

    json.dump(log, open("results_effective_horizon_opt.json", "w"), indent=1)
    print(f"\n[done] {time.time()-t0:.0f}s → results_effective_horizon_opt.json",
          flush=True)


if __name__ == "__main__":
    main()
