"""
review_b4_fig1data.py — 审稿 二: 新 Fig.1 所需数据
=================================================================
(a) 增益曲线 ΔE_ij(k) vs k: 真邻居尖峰 vs 非邻居平坦
(b) 降序增益 g_(m) 与 ḡ_i, ḡ_i+ασ_i, largest-gap 分割点
配置 = 主表基准: W7, ε=1.5, Δt=0.05, τ∈[0.3,1.2], seed=0, T=20000,
Ns=300, Nc=30, λ=1e-6. 完整曲线存 JSON（tikz 内嵌用）。
JSON: results_b4_fig1.json
"""
import os
for _v in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
           "NUMEXPR_NUM_THREADS"):
    os.environ[_v] = "1"
import json
import time

import numpy as np

from pre2025_crc import W7, Reservoir
from lorenz_tune import simulate
import review_common as RC

EPS = 1.5
TAU_RANGE = (0.3, 1.2)
DT_S = 0.05
T = 20000
SEED = 0


def main():
    t0 = time.time()
    N = W7.shape[0]
    tau = RC.make_tau(W7, TAU_RANGE, SEED)
    X = simulate(W7, tau, T * DT_S + 20.0, dt=0.005, eps=EPS,
                 seed=SEED, sample=10)[:T]
    K_max = int(np.ceil(tau[W7 == 1].max() / DT_S)) + 2
    res = [Reservoir(300, 3, 0.1, 0.3, 0.9, seed=i).run(X[:, i, :])
           for i in range(N)]
    Gs = {i: RC.gains_full(X, i, res, 30, K_max, 1e-6) for i in range(N)}
    print(f"[gains_full] {time.time()-t0:.0f}s", flush=True)

    out = dict(K_max=K_max, dt_s=DT_S, seed=SEED,
               tau=[[round(float(tau[i, j]), 4) for j in range(N)]
                    for i in range(N)],
               W=[[int(v) for v in row] for row in W7],
               curves={}, gap_panel={})
    for i in range(N):
        out["curves"][i] = {str(j): [round(float(v), 6) for v in arr]
                            for j, arr in Gs[i].items()}
        # (b) 面板: 选一个真邻居数适中、间隙清晰的 i
        gm = {j: float(arr.max()) for j, arr in Gs[i].items()}
        items = sorted(gm.items(), key=lambda x: -x[1])
        g = np.array([v for _, v in items])
        ratio = g[:-1] / (g[1:] + 1e-30)
        m = int(np.argmax(ratio))
        out["gap_panel"][i] = dict(
            order=[int(j) for j, _ in items],
            gains=[round(float(v), 6) for v in g],
            ratios=[round(float(v), 3) for v in ratio],
            m=m, gbar=round(float(g.mean()), 6),
            sigma=round(float(g.std()), 6),
            kbest={str(j): int(np.argmax(arr)) for j, arr in Gs[i].items()},
            true_nb=[int(j) for j in range(N) if W7[i, j] == 1],
        )
    with open("results_b4_fig1.json", "w") as fh:
        json.dump(out, fh, indent=1)
    # 控制台摘要: 每 i 的最大间隙位置与前后增益
    for i in range(N):
        p = out["gap_panel"][i]
        print(f"  i={i} true_nb={[j+1 for j in p['true_nb']]} "
              f"order={[j+1 for j in p['order']]} m={p['m']} "
              f"g[m]/g[m+1]={p['ratios'][p['m']]:.2f} "
              f"ḡ={p['gbar']:.4f} σ={p['sigma']:.4f}", flush=True)
    print(f"总耗时 {time.time()-t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
