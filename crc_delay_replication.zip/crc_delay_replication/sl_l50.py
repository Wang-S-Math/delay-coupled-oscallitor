"""
sl_l50.py — Stuart-Landau 振子网络: 相位滞后线性时延耦合, N=50, 随机拓扑
=================================================================
模型: ż_j = (λ+iω_j)z_j − (1+ic)|z_j|²z_j + Σ_k w_jk κ e^{iβ} z_k(t−τ_jk)
  - λ=1.0, c=1.0, β=π/4; ω_j ~ U(1.8,2.2) 异质固有频率(避免完全同步)
  - 拓扑: 有向 ER, N=50, 平均出度 m=3 (随机生成)
  - 异构时延 τ_jk ~ U(0.3,1.2)s 逐边独立
  - κ 扫描; 同步诊断 s_sync(复平面RMS距离/spread, 独立基准≈√2) / ρ(Re分量成对相关)
方法: 与 Lorenz 完全一致 — 每振子独立储备池(输入 [Re z, Im z]),
  时延字典 {r_j(t-k)}, 逐邻居 argmax, 判据 mean / 最大间隙(gain字典缓存后置扫描)
积分: 欧拉 dt=0.005, sample=10 → Δt=0.05; T=12000; K_max=ceil(1.2/0.05)+2=26
状态用实数 (time,N,2)=[Re,Im]; 复耦合 κe^{iβ}z 手工展开为实部/虚部。
增益用分块Gram复用(每i的 R_i R_i^T 只算一次), 使 N=50 可行。
"""
import os
import time
import pickle
import numpy as np
from pre2025_crc import Reservoir


def simulate(W, tau, t_end, dt, kappa, beta, lam, c, omega, seed):
    """向量化解 SL + 异构时延. 状态 Z (time,N,2)=[Re,Im] 实数."""
    N = W.shape[0]
    rng = np.random.default_rng(seed)
    Z0 = rng.uniform(-1.0, 1.0, (N, 2))
    n = int(round(t_end / dt))
    lags = np.zeros((N, N), int)
    for p in range(N):
        for q in range(N):
            if W[p, q] != 0:
                lags[p, q] = max(1, int(round(tau[p, q] / dt)))
    max_lag = int(lags.max()) + 1
    Wm = W.astype(float) * kappa
    cb, sb = np.cos(beta), np.sin(beta)
    ar = np.arange(N)
    Z = np.tile(Z0, (n + 1 + max_lag, 1, 1))
    idx = max_lag
    dZ = np.empty_like(Z[0])
    for _ in range(n):
        z = Z[idx]
        a, b = z[:, 0], z[:, 1]
        m2 = a * a + b * b
        dZ[:, 0] = lam * a - omega * b - (m2 * a - c * m2 * b)
        dZ[:, 1] = omega * a + lam * b - (m2 * b + c * m2 * a)
        lagA = Z[idx - lags, ar, 0]
        lagB = Z[idx - lags, ar, 1]
        coupA = (Wm * (cb * lagA - sb * lagB)).sum(axis=1)
        coupB = (Wm * (sb * lagA + cb * lagB)).sum(axis=1)
        dZ[:, 0] += coupA
        dZ[:, 1] += coupB
        Z[idx + 1] = z + dt * dZ
        idx += 1
    return Z[max_lag + 1:max_lag + 1 + n]


def sync_diag(Z, N):
    """Z (T,N,2). s_sync=平均成对复平面RMS距离/spread; ρ=Re分量平均成对相关."""
    a = Z[:, :, 0]; b = Z[:, :, 1]
    spread = np.sqrt(np.mean(a ** 2 + b ** 2))
    pair = [np.sqrt(np.mean((a[:, i] - a[:, j]) ** 2 + (b[:, i] - b[:, j]) ** 2))
            for i in range(N) for j in range(i + 1, min(i + 8, N))]
    s_sync = float(np.mean(pair) / (spread + 1e-12))
    rho = float(np.mean([np.corrcoef(a[:, i], a[:, j])[0, 1]
                         for i in range(N) for j in range(i + 1, min(i + 8, N))]))
    amp = float(np.mean(np.sqrt(a ** 2 + b ** 2)))
    return s_sync, rho, amp


def er_directed(N, m, seed):
    rng = np.random.default_rng(seed)
    W = np.zeros((N, N), int)
    p = m / (N - 1)
    for i in range(N):
        for j in range(N):
            if i != j and rng.random() < p:
                W[i, j] = 1
    return W


def gains_argmax(Z, reservoirs, N, Nc, K_max, lam_r):
    """分块Gram复用的逐邻居argmax. 返回 gains[i][j], kbests[i][j]."""
    T = Z.shape[0]
    pad = K_max + 1
    Ts = T - pad - 1
    gains, kbests = {}, {}
    for i in range(N):
        D0 = reservoirs[i].shape[1]
        Ri = reservoirs[i][pad:T - 1, :]                 # (Ts, Ns)
        U = Z[pad + 1:pad + 1 + Ts, i, :]                # (Ts, 2) 目标 z_i(t+1)
        Gii = Ri.T @ Ri
        bii = Ri.T @ U
        u2 = float(np.sum(U * U))
        Ab = Gii + lam_r * np.eye(D0)
        wb = np.linalg.solve(Ab, bii)
        base = (u2 - 2.0 * float(np.sum(bii * wb))
                + float(np.sum(wb * (Ab @ wb))) - lam_r * float(np.sum(wb * wb))) / (2.0 * Ts)
        gm, kb = {}, {}
        for j in range(N):
            if j == i:
                continue
            bg, bk = -np.inf, 0
            for k in range(K_max + 1):
                Rj = reservoirs[j][pad - k:T - 1 - k, :Nc]   # (Ts, Nc)
                Gij = Ri.T @ Rj
                D = D0 + Nc
                M = np.zeros((D, D))
                M[:D0, :D0] = Gii
                M[:D0, D0:] = Gij
                M[D0:, :D0] = Gij.T
                M[D0:, D0:] = Rj.T @ Rj
                M[np.diag_indices(D)] += lam_r
                b = np.vstack([bii, Rj.T @ U])
                w = np.linalg.solve(M, b)
                sse = u2 - 2.0 * float(np.sum(b * w)) + float(np.sum(w * (M @ w))) \
                    - lam_r * float(np.sum(w * w))
                g = base - sse / (2.0 * Ts)
                if g > bg:
                    bg, bk = g, k
            gm[j], kb[j] = bg, bk
        gains[i], kbests[i] = gm, kb
    return gains, kbests


def crit_edges(gains, N, W, crit):
    hat = set()
    for i in range(N):
        if crit == "mean":
            thr = np.mean(list(gains[i].values()))
            for j, v in gains[i].items():
                if v > thr:
                    hat.add((i, j))
        else:
            items = sorted(gains[i].items(), key=lambda x: -x[1])
            gs = [v for _, v in items]
            ratios = [gs[m] / (gs[m + 1] + 1e-18) for m in range(len(gs) - 1)]
            mstar = int(np.argmax(ratios))
            for j, _ in items[:mstar + 1]:
                hat.add((i, j))
    return hat


def evaluate(W, kappa, beta, lam, c, omega, tau_range, seed,
             Ns=300, Nc=30, lam_r=1e-6, T_use=12000, dt_int=0.005, sample=10,
             cache=None):
    N = W.shape[0]
    dt_s = sample * dt_int
    rng = np.random.default_rng(seed + 1000)
    tau = rng.uniform(*tau_range, (N, N)); np.fill_diagonal(tau, 0.0)
    tau = tau * W
    t_end = T_use * dt_s + 20.0
    Z = simulate(W, tau, t_end, dt_int, kappa, beta, lam, c, omega, seed)[:T_use]
    s_sync, rho, amp = sync_diag(Z, N)
    if not np.all(np.isfinite(Z[-1])) or np.abs(Z).max() > 1e4:
        return dict(kappa=kappa, diverged=True, s_sync=s_sync, rho=rho)

    if cache and os.path.exists(cache):
        with open(cache, "rb") as f:
            blob = pickle.load(f)
        gains, kbests = blob["gains"], blob["kbests"]
    else:
        reservoirs = [Reservoir(Ns, 2, 0.1, 0.3, 0.9, seed=i).run(Z[:, i, :])
                      for i in range(N)]
        K_max = int(np.ceil(tau[W == 1].max() / dt_s)) + 2
        gains, kbests = gains_argmax(Z, reservoirs, N, Nc, K_max, lam_r)
        if cache:
            with open(cache, "wb") as f:
                pickle.dump({"gains": gains, "kbests": kbests}, f)

    true = set((p, q) for p in range(N) for q in range(N) if W[p, q] == 1)
    out = {}
    for crit in ["mean", "gap"]:
        hat = crit_edges(gains, N, W, crit)
        TP = len(hat & true); FP = len(hat - true); FN = len(true - hat)
        P = TP / (TP + FP) if TP + FP else 0; R = TP / (TP + FN) if TP + FN else 0
        out[crit] = dict(P=P, R=R, TP=TP, FP=FP, FN=FN,
                         F1=2 * P * R / (P + R) if P + R else 0)
    hit = 0; errs = []
    for (i, j) in true:
        k = kbests[i].get(j, -1)
        err = abs(k * dt_s - tau[i, j])
        errs.append(err); hit += int(err <= 0.1)
    aucs = []
    for i in range(N):
        tg = [gains[i][j] for j in range(N) if W[i, j] == 1 and j != i]
        fg = [gains[i][j] for j in range(N) if W[i, j] == 0 and j != i]
        if tg and fg:
            wins = sum(1 for x in tg for y in fg if x > y) + 0.5 * sum(1 for x in tg for y in fg if x == y)
            aucs.append(wins / (len(tg) * len(fg)))
    return dict(kappa=kappa, diverged=False, s_sync=s_sync, rho=rho, amp=amp,
                crit=out, hit=hit, n_true=len(true),
                merr=float(np.mean(errs)), maxerr=float(np.max(errs)),
                auc=float(np.mean(aucs)),
                edges=[(i, j, kbests[i].get(j, -1), int(round(tau[i, j] / dt_s)),
                        abs(kbests[i].get(j, -1) * dt_s - tau[i, j]))
                       for (i, j) in sorted(true)])


def main():
    t0 = time.time()
    N = 50
    lam, c, beta = 1.0, 1.0, np.pi / 4
    omega = np.random.default_rng(7).uniform(1.8, 2.2, N)
    W = er_directed(N, 3, seed=11)
    print("=" * 100, flush=True)
    print(f"Stuart-Landau N=50: λ={lam}, c={c}, β=π/4, ω~U(1.8,2.2), "
          f"有向ER m=3 → {int(W.sum())} 边, τ~U(0.3,1.2)s, Δt=0.05s, T=12000", flush=True)
    print("=" * 100, flush=True)

    print("\n[同步扫描] 仅积分, 无储备池 (s_sync: 独立基准≈1.41, →0为同步)", flush=True)
    for kappa in [0.5, 1.0, 1.5, 2.0, 3.0]:
        rng = np.random.default_rng(1000)
        tau = rng.uniform(0.3, 1.2, (N, N)); np.fill_diagonal(tau, 0.0); tau *= W
        Z = simulate(W, tau, 12000 * 0.05 + 20, 0.005, kappa, beta, lam, c, omega, 0)[:12000]
        s, r, a = sync_diag(Z, N)
        tag = "DIVERGED" if (not np.all(np.isfinite(Z[-1])) or np.abs(Z).max() > 1e4) else ""
        print(f"  κ={kappa:<4} s_sync={s:5.2f} ρ={r:+.2f} |z|={a:.2f} {tag}", flush=True)

    print("\n[重构] 储备池+时延字典+逐邻居argmax (判据后置扫描: mean / 最大间隙)", flush=True)
    for kappa in [0.5, 1.0, 1.5]:
        r = evaluate(W, kappa, beta, lam, c, omega, (0.3, 1.2), seed=0,
                     cache=f"gains_sl_N50_k{kappa}.pkl")
        if r.get("diverged"):
            print(f"κ={kappa}: 数值发散", flush=True); continue
        m = r["crit"]["mean"]; g = r["crit"]["gap"]
        print(f"κ={kappa:<4} s_sync={r['s_sync']:.2f} ρ={r['rho']:+.2f} AUC={r['auc']:.3f} | "
              f"mean: P={m['P']:.0%} R={m['R']:.0%} FP={m['FP']} F1={m['F1']:.3f} | "
              f"gap: P={g['P']:.0%} R={g['R']:.0%} FP={g['FP']} F1={g['F1']:.3f} | "
              f"时延={r['hit']}/{r['n_true']} mean|Δτ|={r['merr']:.3f}s max={r['maxerr']:.3f}s",
              flush=True)
    print(f"\n总耗时: {time.time() - t0:.1f}s", flush=True)


if __name__ == "__main__":
    main()
