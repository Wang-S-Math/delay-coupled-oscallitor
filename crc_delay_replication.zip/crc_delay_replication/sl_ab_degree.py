"""判决实验：定位 SL 失效的真正变量——驱动者数量（入度）还是网络规模。

背景：N=5 有向环（入度=1）上 C-RC 成功（F1=1.000、时延 4/5）；
      N=50 ER（入度≈3）上失败（AUC=0.43、命中 14/142）。
      两者之间相差「规模」与「入度」两个变量，此处逐个分离。

设计：N=20，入度 1（随机变换图=若干有向环之并）vs 入度 3（ER）；
      时延 τ~U(0.3,1.2)（短，0.1-0.4 周期）vs τ~U(2.5,4.0)（长，0.8-1.3 周期，复刻 N=5 环配方）。
"""
import numpy as np
import time
import os
import pickle

import sl_l50 as S

LAM_R = 1e-6


def derangement_map(N, seed=11):
    """每个节点恰好 1 条入边的随机图（无自环）= 若干有向环之并（随机环系）。

    返回 W，W[i, j]=1 表示 j -> i（i 由 j 驱动）。
    """
    rng = np.random.default_rng(seed)
    while True:
        perm = rng.permutation(N)
        if np.all(perm != np.arange(N)):
            break
    W = np.zeros((N, N), int)
    for i, j in enumerate(perm):
        W[i, j] = 1
    return W


def sparsify_er(W, d=1, seed=11):
    """把 ER 图稀疏化为每节点恰好 d 条入边（随机保留，不足则补齐）。"""
    N = W.shape[0]
    rng = np.random.default_rng(seed)
    W2 = np.zeros((N, N), int)
    for i in range(N):
        cand = [j for j in range(N) if j != i]
        pick = rng.choice(cand, size=min(d, len(cand)), replace=False)
        W2[i, list(pick)] = 1
    return W2


def full_eval(tag, W, lam, kappa, beta, c, omega, tau_range, seed=0,
              T_use=12000, dt_int=0.005, sample=10, cache=None):
    N = W.shape[0]
    dt_s = dt_int * sample
    rng = np.random.default_rng(seed + 1000)
    tau = rng.uniform(*tau_range, (N, N))
    np.fill_diagonal(tau, 0.0)
    tau = tau * W
    t_end = T_use * dt_s + 20.0
    Z = S.simulate(W, tau, t_end, dt_int, kappa, beta, lam, c, omega, seed)[:T_use]
    if not np.all(np.isfinite(Z[-1])) or np.abs(Z).max() > 1e4:
        print(f"{tag}: DIVERGED", flush=True)
        return None
    s, r, a = S.sync_diag(Z, N)

    from pre2025_crc import Reservoir
    reservoirs = [Reservoir(300, 2, 0.1, 0.3, 0.9, seed=i).run(Z[:, i, :])
                  for i in range(N)]
    K_max = int(np.ceil(tau[W == 1].max() / dt_s)) + 2
    if cache and os.path.exists(cache):
        blob = pickle.load(open(cache, "rb"))
        gains, kbests = blob["gains"], blob["kbests"]
    else:
        gains, kbests = S.gains_argmax(Z, reservoirs, N, 30, K_max, LAM_R)
        if cache:
            pickle.dump({"gains": gains, "kbests": kbests}, open(cache, "wb"))

    true = {(p, q) for p in range(N) for q in range(N) if W[p, q] == 1}
    gt = np.array([gains[i][j] for i in range(N) for j in range(N)
                   if i != j and W[i, j]])
    gf = np.array([gains[i][j] for i in range(N) for j in range(N)
                   if i != j and not W[i, j]])
    # AUC (Mann-Whitney)
    u = sum((folk > t_) + 0.5 * (folk == t_) for t_ in gt for folk in gf)
    auc = u / (len(gt) * len(gf)) if gt.size and gf.size else float("nan")

    # 真边在每节点内的排名（0 = 最佳）
    ranks = []
    for i in range(N):
        js = [j for j in range(N) if j != i]
        vals = np.array([gains[i][j] for j in js])
        for idx, jj in enumerate(js):
            if W[i, jj]:
                ranks.append(int((vals > vals[idx]).sum()))
    ranks = np.array(ranks)

    out = {"mean": {}, "gap": {}}
    for crit in ["mean", "gap"]:
        hat = S.crit_edges(gains, N, W, crit)
        TP = len(hat & true); FP = len(hat - true); FN = len(true - hat)
        P = TP / (TP + FP) if TP + FP else 0.0
        R = TP / (TP + FN) if TP + FN else 0.0
        out[crit] = dict(P=P, R=R, FP=FP, F1=(2 * P * R / (P + R) if P + R else 0.0))
    hit, errs = 0, []
    for i in range(N):
        for j in range(N):
            if W[i, j]:
                th = kbests[i][j] * dt_s
                if abs(th - tau[i, j]) <= 1.5 * dt_s:
                    hit += 1
                    errs.append(abs(th - tau[i, j]))
    merr = float(np.mean(errs)) if errs else float("nan")
    print(f"{tag:<40} n_edge={int(W.sum()):<4} s={s:5.2f} ρ={r:+.2f} |z|={a:5.3f} "
          f"AUC={auc:.3f} | true-rank med={np.median(ranks):4.0f} top-d frac={float((ranks < W.sum(1).mean()).mean()):.2f} | "
          f"mean F1={out['mean']['F1']:.3f} gap F1={out['gap']['F1']:.3f} | "
          f"hit={hit}/{int(W.sum())} merr={merr:.3f}", flush=True)
    return dict(tag=tag, s=s, rho=r, auc=auc, crit=out, hit=hit,
                n=int(W.sum()), merr=merr, ranks=ranks)


if __name__ == "__main__":
    t0 = time.time()
    N = 20
    lam, kappa, beta, c = -0.7, 0.8, 0.0, 0.5
    omega = np.full(N, 2.0)
    cases = [
        ("N20 d=1 τ短", derangement_map(N, 11), (0.3, 1.2)),
        ("N20 d=3 τ短", sparsify_er(None, 3, 11) if False else S.er_directed(N, 3, 11), (0.3, 1.2)),
        ("N20 d=1 τ长", derangement_map(N, 11), (2.5, 4.0)),
        ("N20 d=3 τ长", S.er_directed(N, 3, 11), (2.5, 4.0)),
    ]
    for tag, W, tr in cases:
        full_eval(tag, W, lam, kappa, beta, c, omega, tr, seed=0,
                  cache=f"gains_{tag.replace(' ','_').replace('=','')}.pkl")
    print(f"\n耗时 {time.time()-t0:.1f}s")
