# -*- coding: utf-8 -*-
import numpy as np, time
SIG,R,B=10.0,28.0,8.0/3.0; DT=0.005; EPS=1.5
W7=np.array([[0,1,0,0,0,0,1],[1,0,1,0,0,0,0],[0,1,0,1,0,0,0],[0,0,1,0,1,0,0],
             [0,0,0,1,0,1,0],[0,0,0,0,1,0,1],[1,0,0,0,0,1,0]],float)
N=7
rng=np.random.default_rng(1000); tau=rng.uniform(0.3,1.2,size=(N,N)); tau=(tau+tau.T)/2; np.fill_diagonal(tau,0.0)
max_lag=int(np.ceil(tau.max()/DT))
def step(X,Xbuf,idx):
    Xn=X.copy()
    for i in range(N):
        acc=0.0
        for j in range(N):
            if W7[i,j]>0:
                lag=max(1,int(round(tau[i,j]/DT)))
                acc+=W7[i,j]*(Xbuf[idx-lag,j,0]-X[i,0])
        Xn[i,1]+=DT*(R-X[i,2])*X[i,0]+DT*EPS*acc
        Xn[i,0]+=DT*(SIG*(X[i,1]-X[i,0]))
        Xn[i,2]+=DT*(X[i,0]*X[i,1]-B*X[i,2])
    return Xn
def coupled_pair(seed,delta,n_warm=6000,n_run=1200):
    rng2=np.random.default_rng(seed); X0=rng2.uniform(1,5,size=(N,3))
    n_tot=max_lag+1+n_warm+n_run+1
    Xr=np.zeros((n_tot,N,3)); Xr[:max_lag+1]=X0
    idx=max_lag
    for k in range(n_warm):
        idx+=1; Xr[idx]=step(Xr[idx-1],Xr,idx)
    # 对侧: 相同历史缓冲, 状态加微扰
    rng3=np.random.default_rng(seed+77)
    Xp=np.zeros((n_tot,N,3)); Xp[:max_lag+1]=X0
    Xp[max_lag+1:idx+1]=Xr[max_lag+1:idx+1]   # 共享历史
    Xp[idx]=Xr[idx]+rng3.normal(0,delta,size=(N,3))
    ds=[]
    for k in range(n_run):
        idx+=1
        Xr[idx]=step(Xr[idx-1],Xr,idx)
        Xp[idx]=step(Xp[idx-1],Xp,idx)
        if (k+1)%100==0:
            d=np.sqrt(np.mean((Xr[idx]-Xp[idx])**2))
            ds.append((round((k+1)*DT,2),d))
    return ds
t0=time.time()
print("— 成对散度 (耦合 Euler map, 同步预热+共享历史) —")
for delta in (1e-8,1e-6):
    ds=coupled_pair(0,delta)
    print(f"  delta={delta:.0e}:")
    for t,d in ds[:12]:
        print(f"    t={t:5.2f}s d={d:.3e} 平均λ={np.log(d/delta)/t:7.3f}/s")
    ts=np.array([t for t,_ in ds]); dd=np.log([d for _,d in ds])
    # 早期拟合 (前1.5s)
    m=ts<=1.5
    A=np.polyfit(ts[m],dd[m],1)
    print(f"    早期(<=1.5s)拟合斜率={A[0]:.3f}/s")
print(f"({time.time()-t0:.0f}s)")
