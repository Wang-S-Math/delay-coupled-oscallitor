"""
sl_ring_reconstruct.py — N=5 SL 时滞环: 纯时间序列 -> (网络结构, 时滞 tau, 临界分岔参数)
=========================================================================================
系统 (真模型):
    dz_j/dt = (lam + i*om) z_j - (1 + i c)|z_j|^2 z_j + kappa * e^{i beta} * z_{j-1}(t - tau)
    j = 1..5,  z_0 = z_5  (有向环, 左邻居驱动)
身份参数 (与工作点无关): om, c, kappa, beta, 拓扑 A
工作点参数 (只在这一条/几条轨迹上有效): lam, tau

本脚本只从观测序列 {x_j(t), y_j(t)} 出发 (不告诉算法 tau / 拓扑 / 任何参数), 完成:
  (A) 重构网络结构: 每个节点由谁驱动 -> 邻接矩阵 (真值: 有向环 j <- j-1)
  (B) 辨识时滞 tau
  (C) 预测分支临界参数 (三种形式全出):
        (a) 单Hopf曲线 tau*(lam)   (每个行波模一支)
        (b) 单Hopf曲线 lam*(tau)   (同一条曲线, 反解)
        (c) 双Hopf点 (lam*, tau*)  (两支曲线的交点)

关键可辨识性结论 (本脚本的设计依据):
  在纯极限环行波上, z_j(t) = rho * exp(i(Om t + 2 pi k j / N)) 是**单一旋转相量**,
  此时  z_k(t - tau') 与 z_{j-1}(t - tau) 只差一个常数复因子, 任何 tau' / 任何 k 都能
  完美拟合 -> tau 与拓扑**同时不可辨识**。
  因此必须用**含瞬态(多模混合)的轨迹**: 瞬态里 5 个行波模同时存在、衰减率与频率不同,
  此时候选延迟信号不再成比例, tau 与驱动者才被唯一确定。
  => 数据生成保留完整瞬态, 并用多条不同初值的轨迹。

第三个陷阱 (实测踩到, 见 sl_ring_dt_probe.py): 数据生成器本身必须积分收敛。
  dt=0.005 生成的轨迹对连续 DDE 只有 ~1.5% 的模型一致性, 这个自身误差把 tau 极小值
  拽偏 -0.005; 收敛到 dt=0.00125 后 tau_hat 精确 = 3.5000。所以"辨识误差"里有一部分
  其实是"造数据的误差", 不收敛就分不清是谁的锅。

第二个陷阱 (实测踩到): 不能"先只用自项拟合、再看残差 r_j / z_k(t-tau) 是否恒定"来定 tau。
  在行波极限环上, 耦合项 kappa e^{i beta} z_{j-1}(t-tau) = (复常数) * z_j(t), 与自项
  {x_j, y_j} 共线, 会被自项回归整个吸收 -> 残差不再等于耦合项 -> 该准则系统性偏斜
  (实测给出 tau=2.47 而真值 3.5)。必须把延迟项放进库里做**联合拟合**再扫 tau。
"""
import os, json
import numpy as np
from scipy.optimize import brentq
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
FIGS = os.path.join(HERE, "figs")
os.makedirs(FIGS, exist_ok=True)

N = 5                                        # 节点数
ID = dict(omega=2.0, c=0.5, kappa=0.8, beta=0.0)   # 场景2 身份 (真值)
TRAIN = dict(lam0=-0.7, tau0=3.5)            # 训练工作点 (振荡区, 非临界点)
GT = dict(lam_star=-0.77912, tau_star=2.19912)     # 用户给定的双Hopf真值


# =============================================================
# 1) DDE 仿真器 (分步法 RK4 + 延迟缓冲, 线性插值)
# =============================================================
def sl_ring_rhs(z, lam, omega, c, kappa, beta, zd):
    """z, zd: (2N,) 实向量 [x0,y0,...,x_{N-1},y_{N-1}]. 节点 j 的左邻居 = (j-1)%N."""
    dz = np.zeros_like(z)
    cb, sb = kappa * np.cos(beta), kappa * np.sin(beta)
    for j in range(N):
        xj, yj = z[2 * j], z[2 * j + 1]
        k = (j - 1) % N
        xd, yd = zd[2 * k], zd[2 * k + 1]
        r2 = xj * xj + yj * yj
        dz[2 * j]     = lam * xj - omega * yj - r2 * xj + c * r2 * yj + cb * xd - sb * yd
        dz[2 * j + 1] = omega * xj + lam * yj + c * r2 * xj - r2 * yj + cb * yd + sb * xd
    return dz


def simulate_sl_ring(lam, tau, t_end, dt=0.005, seed=0, x0=None, hist=None):
    """返回 (t, Z), Z 形状 (T, 2N). 初值取随机小扰动 (同时激发多个行波模 -> 瞬态丰富).
    x0   : 若给定 (2N,) 则用它作初值, 历史缓冲全部填 x0 (常数历史)。
    hist : 若给定, 是 (Mh, 2N) 的历史矩阵, **从最老到最新**排列 (hist[-1] = z(0))。
           这是 DDE 正确的"延续"方式: 把一段已有轨迹的尾部当作 [-tau, 0] 上的历史。

    !! 为什么必须有 hist 参数 (实测踩到): 这个系统有**多稳态** —— 同一个 tau 下,
       z=0 (平衡点) 和行波极限环可以**同时稳定**。用"常数历史"起步会把轨迹踢进
       z=0 的吸引域 (实测 tau=1.3/1.9 的真值振幅只有 0.014/0.002, 即衰减到零),
       而 C-RC 是从训练末的**振荡**状态出发的, 两者根本不在同一个吸引子上,
       逐点对比会给出几千个百分点的假误差。做自由运行的真值对比必须用真实历史延续。"""
    omega, c, kappa, beta = ID["omega"], ID["c"], ID["kappa"], ID["beta"]
    n = int(round(t_end / dt))
    delay_steps = tau / dt
    # +3 而不是 +1: 三次插值需要 i0-1..i0+2 四个节点, 且 idx=M-1-delay_steps+a 落在 [2,4),
    # 保证 i0-1>=1 (不会绕回缓冲取到"未来"的值)。
    M = int(np.ceil(delay_steps)) + 3
    rng = np.random.default_rng(seed)
    if hist is not None:
        H = np.asarray(hist, dtype=float)
        assert H.ndim == 2 and H.shape[1] == 2 * N, "hist 形状应为 (Mh, 2N)"
        if len(H) >= M:
            buf = H[-M:].copy()
        else:
            buf = np.vstack([np.tile(H[0], (M - len(H), 1)), H])
        x0 = buf[-1].copy()
    else:
        if x0 is None:
            x0 = 0.4 + 0.1 * rng.standard_normal(2 * N)
        x0 = np.asarray(x0, dtype=float).reshape(-1)
        buf = np.tile(x0.reshape(1, -1), (M, 1))  # 环形缓冲, 避免每步 vstack
    ptr = 0                                       # buf[ptr] = 最老的一行
    t = np.linspace(0, t_end, n + 1)
    Z = np.zeros((n + 1, 2 * N)); Z[0] = x0

    def row(j):
        return buf[(ptr + j) % M]

    def z_delay(a):
        """RK4 第 a 段 (时刻 t_i + a*dt) 所需的延迟值 z(t_i + a*dt - tau), 在环缓冲中
        **三次(4点 Lagrange)插值**。buf 行 j (相对 ptr) 对应 z(t_i - (M-1-j)*dt);
        故 idx = M-1-delay_steps+a。M 取 +3 保证 idx ∈ [2,4), 使 i0-1 >= 1,
        不会绕回缓冲取到"未来"的值。

        诚实备注(实测): 把这里从线性改成三次 **并没有** 降低辨识残差底
        (numVSan 5.118e-06 -> 5.118e-06, 完全无变化)。即"延迟值插值精度"不是瓶颈。
        真正的残差底来自数值解在 breaking points 处的降阶误差, 见 gen_dataset 文档。
        三次插值仍然保留(它本身更精确), 但不要以为它能解决那个问题。"""
        idx = M - 1 - delay_steps + a
        i0 = int(np.floor(idx)); w = idx - i0
        lm1 = w * (w - 1.0) * (w - 2.0) / (-6.0)
        l0 = (w + 1.0) * (w - 1.0) * (w - 2.0) / 2.0
        l1 = (w + 1.0) * w * (w - 2.0) / (-2.0)
        l2 = (w + 1.0) * w * (w - 1.0) / 6.0
        return lm1 * row(i0 - 1) + l0 * row(i0) + l1 * row(i0 + 1) + l2 * row(i0 + 2)

    for i in range(n):
        k1 = sl_ring_rhs(Z[i], lam, omega, c, kappa, beta, z_delay(0.0))
        k2 = sl_ring_rhs(Z[i] + 0.5 * dt * k1, lam, omega, c, kappa, beta, z_delay(0.5))
        k3 = sl_ring_rhs(Z[i] + 0.5 * dt * k2, lam, omega, c, kappa, beta, z_delay(0.5))
        k4 = sl_ring_rhs(Z[i] + dt * k3, lam, omega, c, kappa, beta, z_delay(1.0))
        Z[i + 1] = Z[i] + (dt / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4)
        buf[ptr] = Z[i + 1]
        ptr = (ptr + 1) % M
    return t, Z


def simulate_sl_ring_het(lam, taus, t_end, dt=0.005, seed=0, x0=None, hist=None):
    """异质时滞版: dz_j/dt = (lam+iom)z_j - (1+ic)|z_j|^2 z_j
                          + kappa e^{i beta} z_{(j-1)%N}(t - taus[j])
    taus: 长度 N 的数组 —— 每条入边 (j-1)%N -> j 有**自己的**时滞。
    其余语义 (多稳态/历史延续/环形缓冲) 与 simulate_sl_ring 完全一致。

    实现要点: 环上每个驱动者 k 只被唯一节点 j=(k+1)%N 使用, 所以可把各节点所需的
    延迟态拼成一个 (2N,) 向量 ZD (ZD[2k:2k+2] = z_k(t - taus[(k+1)%N])),
    然后直接复用 sl_ring_rhs —— 它本来就是按 k=(j-1)%N 读 ZD 的。
    缓冲长度按 max(taus) 取, 每节点在自己的 dsteps[j] 处做三次 (4 点 Lagrange) 插值;
    M = ceil(max_dsteps)+3 保证每个节点的 idx_j = M-1-dsteps[j]+a ∈ [2,4),
    与均匀版的同一论证逐节点成立。"""
    taus = np.asarray(taus, dtype=float).ravel()
    assert taus.size == N, "taus 长度必须 = N"
    omega, c, kappa, beta = ID["omega"], ID["c"], ID["kappa"], ID["beta"]
    n = int(round(t_end / dt))
    dsteps = taus / dt
    M = int(np.ceil(dsteps.max())) + 3
    rng = np.random.default_rng(seed)
    if hist is not None:
        H = np.asarray(hist, dtype=float)
        assert H.ndim == 2 and H.shape[1] == 2 * N, "hist 形状应为 (Mh, 2N)"
        if len(H) >= M:
            buf = H[-M:].copy()
        else:
            buf = np.vstack([np.tile(H[0], (M - len(H), 1)), H])
        x0 = buf[-1].copy()
    else:
        if x0 is None:
            x0 = 0.4 + 0.1 * rng.standard_normal(2 * N)
        x0 = np.asarray(x0, dtype=float).reshape(-1)
        buf = np.tile(x0.reshape(1, -1), (M, 1))
    ptr = 0
    t = np.linspace(0, t_end, n + 1)
    Z = np.zeros((n + 1, 2 * N)); Z[0] = x0

    def row(j):
        return buf[(ptr + j) % M]

    def z_delay_het(a):
        ZD = np.zeros(2 * N)
        for j in range(N):
            idx = M - 1 - dsteps[j] + a
            i0 = int(np.floor(idx)); w = idx - i0
            lm1 = w * (w - 1.0) * (w - 2.0) / (-6.0)
            l0 = (w + 1.0) * (w - 1.0) * (w - 2.0) / 2.0
            l1 = (w + 1.0) * w * (w - 2.0) / (-2.0)
            l2 = (w + 1.0) * w * (w - 1.0) / 6.0
            R = lm1 * row(i0 - 1) + l0 * row(i0) + l1 * row(i0 + 1) + l2 * row(i0 + 2)
            k = (j - 1) % N
            ZD[2 * k:2 * k + 2] = R[2 * k:2 * k + 2]
        return ZD

    for i in range(n):
        k1 = sl_ring_rhs(Z[i], lam, omega, c, kappa, beta, z_delay_het(0.0))
        k2 = sl_ring_rhs(Z[i] + 0.5 * dt * k1, lam, omega, c, kappa, beta, z_delay_het(0.5))
        k3 = sl_ring_rhs(Z[i] + 0.5 * dt * k2, lam, omega, c, kappa, beta, z_delay_het(0.5))
        k4 = sl_ring_rhs(Z[i] + dt * k3, lam, omega, c, kappa, beta, z_delay_het(1.0))
        Z[i + 1] = Z[i] + (dt / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4)
        buf[ptr] = Z[i + 1]
        ptr = (ptr + 1) % M
    return t, Z


# =============================================================
# 2) 数值微分 + 均匀网格延迟采样 (向量化)
# =============================================================
def deriv5(Z, dt):
    """5点中心差分 O(dt^4). 返回 dZ, 形状同 Z (2-D)."""
    dZ = np.zeros_like(Z)
    n = len(Z)
    dZ[2:n - 2] = (-Z[4:n] + 8 * Z[3:n - 1] - 8 * Z[1:n - 3] + Z[0:n - 4]) / (12.0 * dt)
    dZ[0:2] = dZ[2]; dZ[n - 2:n] = dZ[n - 3]
    return dZ


def delayed_uniform(col, dt, tau, cubic=True):
    """1-D 均匀采样序列 col (间隔 dt) 在 (t - tau) 处的插值; t<tau 段用 col[0] 填充.
    cubic=True 用 4 点 Lagrange (节点 -1,0,1,2), 误差 O(dt^4).
    为什么必须用三次: 线性插值的误差随 (tau/dt) 的小数部分周期性起伏, 会在 rel_RSS(tau)
    曲线上叠加一层周期 = dt 的波纹, 把 argmin 从真值拽开 ~1e-2 (实测 0.0055)。"""
    T = len(col)
    idx = np.arange(T, dtype=float) - tau / dt
    i0 = np.floor(np.clip(idx, 0.0, T - 1.0)).astype(int)
    w = np.clip(idx - i0, 0.0, 1.0)
    if not cubic:
        i1 = np.minimum(i0 + 1, T - 1)
        return (1.0 - w) * col[i0] + w * col[i1]
    im1 = np.clip(i0 - 1, 0, T - 1)
    ip1 = np.clip(i0 + 1, 0, T - 1)
    ip2 = np.clip(i0 + 2, 0, T - 1)
    l_m1 = w * (w - 1.0) * (w - 2.0) / (-6.0)
    l_0 = (w + 1.0) * (w - 1.0) * (w - 2.0) / 2.0
    l_1 = (w + 1.0) * w * (w - 2.0) / (-2.0)
    l_2 = (w + 1.0) * w * (w - 1.0) / 6.0
    return l_m1 * col[im1] + l_0 * col[i0] + l_1 * col[ip1] + l_2 * col[ip2]


# =============================================================
# 3) 稀疏回归 (STLSQ)
# =============================================================
def sindy_sparse(target, lib, rel_thresh=1e-2, max_iter=8):
    if np.linalg.norm(target) < 1e-14:
        return np.zeros(lib.shape[1])
    om, *_ = np.linalg.lstsq(lib, target, rcond=None)
    scale = np.max(np.abs(om))
    if scale < 1e-14:
        return np.zeros(lib.shape[1])
    for _ in range(max_iter):
        act = np.abs(om) > rel_thresh * scale
        if act.sum() == 0:
            return np.zeros_like(om)
        if act.sum() == lib.shape[1]:
            break
        om_sub, *_ = np.linalg.lstsq(lib[:, act], target, rcond=None)
        new = np.zeros_like(om); new[act] = om_sub
        if np.allclose(new, om, atol=1e-12):
            om = new; break
        om = new
    return om


def self_terms_j(Z, j):
    """节点 j 的 SL 自项: [x_j, y_j, (x^2+y^2)x_j, (x^2+y^2)y_j], 形状 (T,4)."""
    xj = Z[:, 2 * j]; yj = Z[:, 2 * j + 1]
    r2 = xj * xj + yj * yj
    return np.column_stack([xj, yj, r2 * xj, r2 * yj])


def fit_node(traj, tau, j, k=None, rel_thresh=1e-2):
    """拟合节点 j: 库 = [SL自项] (+ 驱动者 k 的延迟态 [x_k(t-tau), y_k(t-tau)] 当 k 非 None).
    返回 (rel_rss, om_re, om_im)."""
    t, Z, dZ, dt = traj
    lib = self_terms_j(Z, j)
    if k is not None:
        xd = delayed_uniform(Z[:, 2 * k], dt, tau).reshape(-1, 1)
        yd = delayed_uniform(Z[:, 2 * k + 1], dt, tau).reshape(-1, 1)
        lib = np.hstack([lib, xd, yd])
    om_re = sindy_sparse(dZ[:, 2 * j], lib, rel_thresh)
    om_im = sindy_sparse(dZ[:, 2 * j + 1], lib, rel_thresh)
    pr = lib @ om_re; pi = lib @ om_im
    num = np.sum((dZ[:, 2 * j] - pr) ** 2) + np.sum((dZ[:, 2 * j + 1] - pi) ** 2)
    den = np.sum(dZ[:, 2 * j] ** 2) + np.sum(dZ[:, 2 * j + 1] ** 2) + 1e-30
    return float(num / den), om_re, om_im


def recover_params_from_om(om_re, om_im):
    """由 (自项+单驱动延迟项) 的系数恢复 (lam, omega, c, kappa, beta).
    真模型: dx =  lam x -om y - r^2 x + c r^2 y + (k cos b) xd - (k sin b) yd
            dy =  om x +lam y + c r^2 x -   r^2 y + (k sin b) xd + (k cos b) yd"""
    lam   = 0.5 * (om_re[0] + om_im[1])
    omega = 0.5 * (om_im[0] - om_re[1])
    c     = 0.5 * (om_re[3] + om_im[2])
    kcb   = 0.5 * (om_re[4] + om_im[5])   # kappa cos beta
    ksb   = 0.5 * (om_im[4] - om_re[5])   # kappa sin beta
    kap = float(np.sqrt(kcb * kcb + ksb * ksb))
    bet = float(np.arctan2(ksb, kcb))
    return float(lam), float(omega), float(c), kap, bet


# =============================================================
# 4) 从数据辨识 tau
#    准则1: 联合全拟合相对残差 (自项 + 驱动者延迟项一起进库, 扫描 tau)
#    准则2: 留一轨迹交叉验证 (在其余轨迹上拟合系数, 在留出轨迹上算残差)
#    —— 注意: 不能用"先拟合自项、再看残差 r_j / z_k(t-tau) 是否恒定"那条捷径:
#       在行波极限环上耦合项 kappa e^{i beta} z_{j-1}(t-tau) 与 z_j(t) 只差一个复常数
#       因子, 与自项 {x_j, y_j} 共线, 会被自项回归吸收掉, 残差不再等于耦合项,
#       该准则系统性偏斜 (实测给出 tau=2.47, 错 1.03)。必须做"含延迟项"的联合拟合。
# =============================================================
def total_rel_rss(dataset, tau, driver_of=None, rel_thresh=1e-2):
    """假定拓扑 (默认有向环 j<-j-1), 在给定 tau 下对所有轨迹/节点做全拟合, 返回总相对残差."""
    tot = 0.0
    for traj in dataset:
        for j in range(N):
            k = (j - 1) % N if driver_of is None else driver_of[j]
            r, _, _ = fit_node(traj, tau, j, k, rel_thresh)
            tot += r
    return tot


def node_library(traj, tau, j, k=None):
    """构造节点 j 的库: [SL自项] (+ 驱动者 k 的延迟态)."""
    t, Z, dZ, dt = traj
    lib = self_terms_j(Z, j)
    if k is not None:
        xd = delayed_uniform(Z[:, 2 * k], dt, tau).reshape(-1, 1)
        yd = delayed_uniform(Z[:, 2 * k + 1], dt, tau).reshape(-1, 1)
        lib = np.hstack([lib, xd, yd])
    return lib


def fit_node_multi(trajs, tau, j, k=None, rel_thresh=1e-2):
    """把多条轨迹的库/目标纵向拼接后做一次稀疏回归, 返回 (om_re, om_im)."""
    libs, tre, tim = [], [], []
    for traj in trajs:
        t, Z, dZ, dt = traj
        libs.append(node_library(traj, tau, j, k))
        tre.append(dZ[:, 2 * j]); tim.append(dZ[:, 2 * j + 1])
    L = np.vstack(libs)
    tre = np.concatenate(tre); tim = np.concatenate(tim)
    return sindy_sparse(tre, L, rel_thresh), sindy_sparse(tim, L, rel_thresh)


def rel_rss_on(traj, tau, j, k, om_re, om_im):
    """用给定系数在一条轨迹上算相对残差 (不重新拟合)."""
    t, Z, dZ, dt = traj
    lib = node_library(traj, tau, j, k)
    pr = lib @ om_re; pi = lib @ om_im
    num = np.sum((dZ[:, 2 * j] - pr) ** 2) + np.sum((dZ[:, 2 * j + 1] - pi) ** 2)
    den = np.sum(dZ[:, 2 * j] ** 2) + np.sum(dZ[:, 2 * j + 1] ** 2) + 1e-30
    return float(num / den)


def total_rel_rss_holdout(dataset, tau, driver_of=None, rel_thresh=1e-2):
    """准则2 (留一轨迹交叉验证): 轮流留出一条轨迹, 用其余轨迹拟合系数, 在留出轨迹上算残差.
    这是更硬的检验 —— 它排除"靠更多自由参数把任意 tau 都拟合好"的可能."""
    tot = 0.0
    for h in range(len(dataset)):
        train = [dataset[i] for i in range(len(dataset)) if i != h]
        for j in range(N):
            k = (j - 1) % N if driver_of is None else driver_of[j]
            ore, oim = fit_node_multi(train, tau, j, k, rel_thresh)
            tot += rel_rss_on(dataset[h], tau, j, k, ore, oim)
    return tot


def scan_tau(dataset, tau_grid, criterion=total_rel_rss, refine=3, rel_thresh=1e-2):
    """粗扫 + 局部细化, 返回 (tau_hat, curve). curve = [(tau, value), ...]"""
    curve = [(float(tau), float(criterion(dataset, tau, rel_thresh=rel_thresh))) for tau in tau_grid]
    tau_hat = min(curve, key=lambda x: x[1])[0]
    step = float(tau_grid[1] - tau_grid[0]) if len(tau_grid) > 1 else 0.05
    for _ in range(refine):
        step /= 5.0
        lo, hi = tau_hat - 2.5 * step * 5, tau_hat + 2.5 * step * 5
        loc = np.linspace(max(lo, tau_grid[0]), min(hi, tau_grid[-1]), 21)
        curve += [(float(tau), float(criterion(dataset, tau, rel_thresh=rel_thresh))) for tau in loc]
        tau_hat = min(curve, key=lambda x: x[1])[0]
    curve.sort(key=lambda x: x[0])
    return float(tau_hat), curve


# =============================================================
# 5) 结构重构: 每个节点在所有候选驱动者里选 (在已辨识的 tau 上)
# =============================================================
def reconstruct_structure(dataset, tau, rel_thresh=1e-2):
    """对每个节点 j, 在 {无耦合} ∪ {k != j} 里选使全拟合残差最小的驱动者.
    返回 (A_rec (N,N) 0/1, detail).  A_rec[j,k]=1 表示 k 驱动 j."""
    A = np.zeros((N, N))
    detail = []
    for j in range(N):
        cands = [None] + [k for k in range(N) if k != j]
        scores = []
        for k in cands:
            s = 0.0
            for traj in dataset:
                r, _, _ = fit_node(traj, tau, j, k, rel_thresh)
                s += r
            scores.append(s)
        order = np.argsort(scores)
        best_k = cands[int(order[0])]
        runner = cands[int(order[1])]
        if best_k is not None:
            A[j, best_k] = 1.0
        detail.append(dict(node=j, best=best_k, best_rss=scores[int(order[0])],
                           runner=runner, runner_rss=scores[int(order[1])],
                           margin=scores[int(order[1])] / (scores[int(order[0])] + 1e-30)))
    return A, detail


# =============================================================
# 6) 临界参数: 行波模 + 特征方程
# =============================================================
def modes_of_A(A):
    """耦合矩阵 A 的特征值 q (行波模). 对有向环 = 5 次单位根."""
    return np.linalg.eigvals(A)


def critical_tau_for_lambda(omega, kappa, beta, q, lam, tau_max=6.0, mlist=range(-2, 6)):
    """给定 lam, 返回模 q 的所有 Hopf 临界 tau* (list).
    特征方程 (z_j = q^j e^{i nu t}):  i nu - (lam + i om) = (kappa e^{i beta} / q) e^{-i nu tau}
     幅值: lam^2 + (nu-om)^2 = kappa^2
     相位: tau = (beta - arg(q) - atan2(nu-om, -lam) + 2 pi m) / nu"""
    if abs(lam) > kappa + 1e-12:
        return []
    argA = beta - np.angle(q)
    disc = max(kappa * kappa - lam * lam, 0.0)
    out = []
    for br in (+1.0, -1.0):
        nu = omega + br * np.sqrt(disc)
        if nu <= 1e-9:
            continue
        phi = np.arctan2(nu - omega, -lam)
        for m in mlist:
            tau = (argA - phi + 2.0 * np.pi * m) / nu
            if 1e-6 < tau <= tau_max:
                out.append(float(tau))
    out = sorted(out)
    ded = []
    for v in out:
        if not ded or abs(v - ded[-1]) > 1e-9:
            ded.append(v)
    return ded


def critical_lambda_for_tau(omega, kappa, beta, q, tau, klist=range(-2, 6), nth=2001):
    """给定 tau, 返回模 q 的所有临界 lam* (list).
    参数化: lam = -kappa cos(th),  nu = om + kappa sin(th),  th = beta - arg(q) - nu*tau (+2 pi k)
      => 解  th + tau*kappa*sin(th) = beta - arg(q) - om*tau + 2 pi k"""
    phi = -float(np.angle(q))
    base = beta + phi - omega * tau
    ths = np.linspace(-np.pi, np.pi, nth)
    vals = ths + tau * kappa * np.sin(ths)
    out = []
    for k in klist:
        target = base + 2.0 * np.pi * k
        f = vals - target
        sgn = np.sign(f)
        idx = np.where(np.diff(sgn) != 0)[0]
        for i in idx:
            try:
                th = brentq(lambda x, tg=target: x + tau * kappa * np.sin(x) - tg,
                            ths[i], ths[i + 1], xtol=1e-13)
            except Exception:
                continue
            nu = omega + kappa * np.sin(th)
            if nu <= 1e-9:
                continue
            out.append(float(-kappa * np.cos(th)))
    out = sorted(out)
    ded = []
    for v in out:
        if not ded or abs(v - ded[-1]) > 1e-9:
            ded.append(v)
    return ded


def hopf_points_tau_of_lam(omega, kappa, beta, A, lam_grid):
    """输出 (a): 单Hopf曲线 tau*(lam). 返回 array (lam, tau, mode_idx)."""
    qs = modes_of_A(A)
    pts = []
    for mi, q in enumerate(qs):
        for lam in lam_grid:
            for tau in critical_tau_for_lambda(omega, kappa, beta, q, lam):
                pts.append((lam, tau, mi))
    return np.array(pts).reshape(-1, 3) if pts else np.zeros((0, 3))


def hopf_points_lam_of_tau(omega, kappa, beta, A, tau_grid):
    """输出 (b): 单Hopf曲线 lam*(tau). 返回 array (tau, lam, mode_idx)."""
    qs = modes_of_A(A)
    pts = []
    for mi, q in enumerate(qs):
        for tau in tau_grid:
            for lam in critical_lambda_for_tau(omega, kappa, beta, q, tau):
                pts.append((tau, lam, mi))
    return np.array(pts).reshape(-1, 3) if pts else np.zeros((0, 3))


def double_hopf_candidates(omega, kappa, beta, A, klist=range(-2, 5), nth=4001,
                           tau_min=0.05, tau_max=6.0, lam_min=-1.5, lam_max=0.5):
    """输出 (c): 双Hopf点. 两个模 i,j 同时满足 Hopf:
        lam 相同  =>  th_j = -th_i   (cos 相同, sin 反号)
        nu_i = om + kappa sin(th),  nu_j = om - kappa sin(th)
        tau 相同  =>  (beta+phi_i-th+2pi ki)/nu_i = (beta+phi_j+th+2pi kj)/nu_j
    扫描 th 解该方程, 枚举所有 (i<j, ki, kj)."""
    qs = modes_of_A(A)
    phis = [-float(np.angle(q)) for q in qs]
    ths = np.linspace(-np.pi + 1e-9, np.pi - 1e-9, nth)
    s = np.sin(ths)
    nup = omega + kappa * s      # nu_i
    num = omega - kappa * s      # nu_j
    out = []
    M = len(qs)
    for i in range(M):
        for j in range(i + 1, M):
            Li0 = beta + phis[i] - ths
            Rj0 = beta + phis[j] + ths
            for ki in klist:
                for kj in klist:
                    F = (Li0 + 2.0 * np.pi * ki) * num - (Rj0 + 2.0 * np.pi * kj) * nup
                    sgn = np.sign(F)
                    idx = np.where(np.diff(sgn) != 0)[0]
                    if len(idx) == 0:
                        continue
                    for ii in idx:
                        f = (lambda x, i=i, j=j, ki=ki, kj=kj:
                             (beta + phis[i] - x + 2.0 * np.pi * ki) * (omega - kappa * np.sin(x))
                             - (beta + phis[j] + x + 2.0 * np.pi * kj) * (omega + kappa * np.sin(x)))
                        try:
                            th = brentq(f, ths[ii], ths[ii + 1], xtol=1e-13)
                        except Exception:
                            continue
                        nu_i = omega + kappa * np.sin(th)
                        nu_j = omega - kappa * np.sin(th)
                        if nu_i <= 1e-9 or nu_j <= 1e-9:
                            continue
                        tau = (beta + phis[i] - th + 2.0 * np.pi * ki) / nu_i
                        lam = -kappa * np.cos(th)
                        if not (tau_min <= tau <= tau_max and lam_min <= lam <= lam_max):
                            continue
                        out.append(dict(lam=float(lam), tau=float(tau), mi=i, mj=j,
                                        ki=int(ki), kj=int(kj)))
    res = []
    for d in sorted(out, key=lambda d: (d["tau"], d["lam"])):
        if all(abs(d["lam"] - r["lam"]) > 1e-7 or abs(d["tau"] - r["tau"]) > 1e-7 for r in res):
            res.append(d)
    return res


def pick_nearest(cands, lam_ref, tau_ref):
    """在候选双Hopf点里取离参考点最近的那个 (用于和用户给定真值对照)."""
    if not cands:
        return None
    return min(cands, key=lambda d: (d["lam"] - lam_ref) ** 2 + (d["tau"] - tau_ref) ** 2)


# =============================================================
# 7) 数据集生成 (保留瞬态, 多条不同初值的轨迹)
# =============================================================
def gen_dataset(seeds=(0, 1, 2), t_end=60.0, dt=0.00125, Msub=16, lam=None, tau=None):
    """返回 list of (t, Z, dZ, dt_sub). 保留完整瞬态 -> 多模混合 -> tau/拓扑可辨识.

    残差底(以及由此产生的 tau 偏差)的来源 —— 已用双变量扫描定案, 结论如下:
      * 残差底完全由**仿真步长 h** 决定, 按 **O(h^2)** 严格收敛:
          h=0.005 -> 8.09e-05 | 0.0025 -> 2.04e-05 | 0.00125 -> 5.12e-06 | 0.000625 -> 1.28e-06
          (每减半降 3.97~3.99 倍, 干净二阶)
      * 与**辨识端**完全无关: 固定 h, 把辨识端采样间隔 dt_sub 从 0.02 降到 0.00125
        (采样点 3000 -> 48000), 残差恒为 5.12e-06, 纹丝不动。
        => 差分格式/延迟插值/采样密度都不是瓶颈。
      * 与**拟合**无关: 真系数模型 vs 解析导数 = 1.5e-32 (机器零), 说明库构造、模型
        形式、延迟插值全部正确; 而 真系数 vs 数值导数 = 5.15e-06 ≈ 数值导数 vs
        解析导数 = 5.14e-06 -> 残差 100% 是"数值导数与解析导数不一致"。
      * 不是 breaking point 局部问题: 剔除 t=k*tau 附近 ±0.05/±0.15/±0.40 的点
        (最多剔除 23% 的样本) 残差仅从 1.4795e-06 降到 1.4674e-06。
      * **根因**: DDE 解在 breaking points t = k*tau 处导数不连续, RK4 跨越这些点时
        从 4 阶降到 2 阶; 该误差经延迟耦合沿轨迹传播(所以不是局部的, 剔点无效),
        最终表现为整条轨迹对连续 DDE 的 O(h^2) 偏差 -> 把 tau 极小值拽偏。
          h=0.005 -> tau 偏差 -0.005;  h=0.00125 -> -0.0015  (同比缩小)
    即: 这 ~0.0015 的 tau 偏差是"造数据的误差", 不是"辨识方法的误差"。
    彻底解决需换能追踪 breaking point 的 DDE 求解器, 或改用弱形式(积分形式)SINDy
    避开逐点数值微分; 廉价做法就是继续缩小 h (h=0.000625 时残差底降到 3.5e-07)。
    Msub 随 dt 同比放大以保持辨识端 dt_sub=0.02 不变。"""
    lam = TRAIN["lam0"] if lam is None else lam
    tau = TRAIN["tau0"] if tau is None else tau
    out = []
    for sd in seeds:
        t, Z = simulate_sl_ring(lam, tau, t_end=t_end, dt=dt, seed=sd)
        dZ = deriv5(Z, dt)
        sl = slice(3, -3)                      # 去掉差分端点
        t2, Z2, dZ2 = t[sl][::Msub], Z[sl][::Msub], dZ[sl][::Msub]
        out.append((t2, Z2, dZ2, dt * Msub))
    return out


# =============================================================
# 8) 主流程
# =============================================================
def main():
    print("=" * 74)
    print("SL 时滞环: 纯时间序列 -> (结构, tau, 临界分岔参数)  [SINDy-DDE]")
    print("=" * 74)

    # ---------- [1] 数据 ----------
    lam0, tau0 = TRAIN["lam0"], TRAIN["tau0"]
    print(f"\n[1] 生成轨迹 (保留瞬态): 工作点 lam0={lam0}, tau0={tau0}, "
          f"身份 om={ID['omega']}, c={ID['c']}, kappa={ID['kappa']}, beta={ID['beta']}")
    # dt 取 0.00125 (收敛值, 见 gen_dataset 文档与 sl_ring_dt_probe.py), Msub=16 保持 dt_sub=0.02
    dataset = gen_dataset(seeds=(0, 1, 2), t_end=60.0, dt=0.00125, Msub=16)
    npts = sum(len(tr[0]) for tr in dataset)
    amp_tr = [float(np.mean(np.sqrt((tr[1][:, ::2] ** 2 + tr[1][:, 1::2] ** 2).mean(axis=1)))) for tr in dataset]
    print(f"    轨迹数 {len(dataset)}, 总采样点 {npts}, 各轨迹平均振幅 |z| = "
          + ", ".join(f"{a:.4f}" for a in amp_tr))

    # ---------- [2] 辨识 tau ----------
    print("\n[2] 辨识时滞 tau (两种准则: 联合全拟合残差 / 留一轨迹交叉验证)...")
    tau_grid = np.arange(0.20, 5.01, 0.05)
    tau_rss, curve_rss = scan_tau(dataset, tau_grid, criterion=total_rel_rss, refine=3)
    tau_ho, curve_ho = scan_tau(dataset, tau_grid, criterion=total_rel_rss_holdout, refine=3)
    print(f"    准则1 联合全拟合残差 argmin : tau_hat = {tau_rss:.4f}  (真值 {tau0})  误差 {abs(tau_rss-tau0):.4f}")
    print(f"    准则2 留一轨迹交叉验证     : tau_hat = {tau_ho:.4f}  (真值 {tau0})  误差 {abs(tau_ho-tau0):.4f}")
    tau_hat = tau_rss

    # ---------- [3] 结构重构 ----------
    print("\n[3] 结构重构: 每个节点在所有候选驱动者 {无耦合, k!=j} 里选残差最小者...")
    A_rec, detail = reconstruct_structure(dataset, tau_hat)
    A_true = np.zeros((N, N))
    for j in range(N):
        A_true[j, (j - 1) % N] = 1.0
    struct_ok = bool(np.allclose(A_rec, A_true))
    print(f"    重构 A (行=受驱节点 j, 列=驱动者 k):\n{A_rec.astype(int)}")
    print(f"    真值 A:\n{A_true.astype(int)}")
    print(f"    结构完全命中: {struct_ok}")
    for d in detail:
        print(f"      node {d['node']}: best driver = {d['best']}, 次优 {d['runner']}, "
              f"残差比(次优/最优) = {d['margin']:.1f}x")

    # ---------- [4] 恢复身份参数 ----------
    print("\n[4] 在 (重构结构, tau_hat) 上恢复身份参数 (lam, om, c, kappa, beta)...")
    acc = {k: [] for k in ("lam", "omega", "c", "kappa", "beta")}
    drivers = [int(np.argmax(A_rec[j])) if A_rec[j].sum() > 0 else None for j in range(N)]
    for traj in dataset:
        for j in range(N):
            r, ore, oim = fit_node(traj, tau_hat, j, drivers[j])
            if ore is None or len(ore) < 6:
                continue
            lam, om, c, kap, bet = recover_params_from_om(ore, oim)
            acc["lam"].append(lam); acc["omega"].append(om); acc["c"].append(c)
            acc["kappa"].append(kap); acc["beta"].append(bet)
    rec = {k: float(np.mean(v)) for k, v in acc.items()}
    rec["tau"] = float(tau_hat)
    for key, tv in (("omega", ID["omega"]), ("c", ID["c"]), ("kappa", ID["kappa"]),
                    ("beta", ID["beta"]), ("lam", lam0), ("tau", tau0)):
        print(f"    {key:6s} 恢复 = {rec[key]:+.5f}   真值 = {tv:+.5f}   误差 = {abs(rec[key]-tv):.5f}")

    # ---------- [5] 临界参数预测 (a)(b)(c) ----------
    print("\n[5] 用恢复的身份预测分支临界参数 (与训练工作点无关)...")
    lam_grid = np.linspace(-1.20, -0.20, 201)
    tau_g2 = np.linspace(0.10, 5.00, 201)

    # 基准: 用真值身份
    dh_true_all = double_hopf_candidates(ID["omega"], ID["kappa"], ID["beta"], A_true)
    dh_true = pick_nearest(dh_true_all, GT["lam_star"], GT["tau_star"])
    print(f"    基准[真值身份] 双Hopf 候选 {len(dh_true_all)} 个; 最接近用户真值的一个: "
          f"lam*={dh_true['lam']:.5f}, tau*={dh_true['tau']:.5f} (模 {dh_true['mi']},{dh_true['mj']})")
    print(f"    用户给定真值:                  lam*={GT['lam_star']}, tau*={GT['tau_star']}"
          f"   -> 基准误差 dlam={abs(dh_true['lam']-GT['lam_star']):.5f}, dtau={abs(dh_true['tau']-GT['tau_star']):.5f}")

    # 预测: 用恢复身份 + 重构结构
    dh_pred_all = double_hopf_candidates(rec["omega"], rec["kappa"], rec["beta"], A_rec)
    dh_pred = pick_nearest(dh_pred_all, dh_true["lam"], dh_true["tau"])
    print(f"    预测[恢复身份] 双Hopf 候选 {len(dh_pred_all)} 个; 匹配基准的一个: "
          f"lam*={dh_pred['lam']:.5f}, tau*={dh_pred['tau']:.5f} (模 {dh_pred['mi']},{dh_pred['mj']})")
    print(f"    预测 vs 用户真值: dlam={abs(dh_pred['lam']-GT['lam_star']):.5f}, "
          f"dtau={abs(dh_pred['tau']-GT['tau_star']):.5f}")

    pts_a_true = hopf_points_tau_of_lam(ID["omega"], ID["kappa"], ID["beta"], A_true, lam_grid)
    pts_b_true = hopf_points_lam_of_tau(ID["omega"], ID["kappa"], ID["beta"], A_true, tau_g2)
    pts_a_pred = hopf_points_tau_of_lam(rec["omega"], rec["kappa"], rec["beta"], A_rec, lam_grid)
    pts_b_pred = hopf_points_lam_of_tau(rec["omega"], rec["kappa"], rec["beta"], A_rec, tau_g2)
    print(f"    (a) tau*(lam) 曲线点: 真值 {len(pts_a_true)}, 预测 {len(pts_a_pred)}")
    print(f"    (b) lam*(tau) 曲线点: 真值 {len(pts_b_true)}, 预测 {len(pts_b_pred)}")

    # ---------- [6] 保存 ----------
    res = dict(
        train=dict(lam0=lam0, tau0=tau0),
        tau_hat=float(tau_hat), tau_rss=float(tau_rss), tau_ho=float(tau_ho),
        tau_err=dict(rss=float(abs(tau_rss - tau0)), holdout=float(abs(tau_ho - tau0))),
        A_rec=A_rec.astype(int).tolist(), A_true=A_true.astype(int).tolist(),
        struct_ok=struct_ok, struct_detail=detail,
        recovered={k: float(v) for k, v in rec.items()},
        true_identity=dict(ID, lam=lam0, tau=tau0),
        rec_err={k: float(abs(rec[k] - v)) for k, v in
                 (("omega", ID["omega"]), ("c", ID["c"]), ("kappa", ID["kappa"]),
                  ("beta", ID["beta"]), ("lam", lam0), ("tau", tau0))},
        double_hopf=dict(
            user_gt=GT,
            baseline_true_identity=dict(lam=dh_true["lam"], tau=dh_true["tau"],
                                        modes=[dh_true["mi"], dh_true["mj"]]),
            predicted=dict(lam=dh_pred["lam"], tau=dh_pred["tau"],
                           modes=[dh_pred["mi"], dh_pred["mj"]]),
            err_vs_user=dict(dlam=float(abs(dh_pred["lam"] - GT["lam_star"])),
                             dtau=float(abs(dh_pred["tau"] - GT["tau_star"]))),
            n_candidates_true=len(dh_true_all), n_candidates_pred=len(dh_pred_all),
            candidates_true=dh_true_all[:20], candidates_pred=dh_pred_all[:20],
        ),
    )
    with open(os.path.join(HERE, "results_sl_ring_reconstruct.json"), "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=2)

    # ---------- [7] 图 ----------
    out = make_figures(dataset, A_rec, A_true, rec, curve_rss, curve_ho,
                       pts_a_true, pts_a_pred, pts_b_true, pts_b_pred,
                       dh_true, dh_pred, tau_rss, tau_ho)
    print(f"\n完成 -> {out}")
    print(f"      -> {os.path.join(HERE, 'results_sl_ring_reconstruct.json')}")
    return res


# =============================================================
# 9) 绘图
# =============================================================
def make_figures(dataset, A_rec, A_true, rec, curve_rss, curve_ho,
                 pts_a_true, pts_a_pred, pts_b_true, pts_b_pred,
                 dh_true, dh_pred, tau_rss, tau_ho, fname="fig7_sl_reconstruct.png"):
    plt.rcParams.update({"font.size": 10})
    fig, axes = plt.subplots(2, 3, figsize=(18, 10.5))

    # (a) 数据: 含瞬态的轨迹
    ax = axes[0, 0]
    t, Z, _, _ = dataset[0]
    ax.plot(t, Z[:, 0], lw=1.0, color="tab:blue", label="node0 Re")
    ax.plot(t, Z[:, 1], lw=0.8, ls="--", color="tab:blue", alpha=0.6, label="node0 Im")
    ax.plot(t, Z[:, 2], lw=1.0, color="tab:orange", label="node1 Re")
    ax.set_xlabel("t"); ax.set_ylabel("state")
    ax.set_title("(a) Data: trajectories WITH transient\n(limit cycle alone is degenerate for tau/structure)")
    ax.legend(fontsize=8); ax.grid(alpha=0.3)

    # (b) 重构拓扑
    ax = axes[0, 1]
    pos = {j: (np.cos(2 * np.pi * j / N), np.sin(2 * np.pi * j / N)) for j in range(N)}
    for j in range(N):
        for k in range(N):
            if A_rec[j, k] > 0.5:
                x1, y1 = pos[k]; x2, y2 = pos[j]
                ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                            arrowprops=dict(arrowstyle="-|>", color="tab:blue", lw=2.2,
                                            mutation_scale=16, shrinkA=18, shrinkB=22))
    for j in range(N):
        x, y = pos[j]
        ax.plot(x, y, "o", ms=26, color="tab:orange", zorder=3)
        ax.text(x, y, str(j), ha="center", va="center", fontsize=13)
    ax.set_xlim(-1.45, 1.45); ax.set_ylim(-1.45, 1.45); ax.set_aspect("equal"); ax.axis("off")
    ok = np.allclose(A_rec, A_true)
    ax.set_title(f"(b) Reconstructed topology (ring j<-j-1)\nstructure match = {ok}, tau_hat = {rec['tau']:.3f}")

    # (c) tau 辨识曲线
    ax = axes[0, 2]
    tr = [c[0] for c in curve_rss]; vr = [c[1] for c in curve_rss]
    tc = [c[0] for c in curve_ho]; vc = [c[1] for c in curve_ho]
    ax.semilogy(tr, np.maximum(vr, 1e-14), lw=1.8, color="tab:purple", label="crit.1: joint full-fit rel. RSS")
    ax.axvline(tau_rss, color="tab:purple", ls="--", lw=1.4)
    ax.set_xlabel("candidate delay tau"); ax.set_ylabel("rel. RSS (log)", color="tab:purple")
    ax2 = ax.twinx()
    ax2.semilogy(tc, np.maximum(vc, 1e-14), lw=1.2, color="tab:green", alpha=0.85,
                 label="crit.2: leave-one-trajectory-out RSS")
    ax2.set_ylabel("hold-out RSS (log)", color="tab:green")
    ax.axvline(TRAIN["tau0"], color="k", ls=":", lw=1.6, label=f"tau_true={TRAIN['tau0']}")
    ax.set_title(f"(c) Delay identification\npurple={tau_rss:.4f} | green(hold-out)={tau_ho:.4f} | true={TRAIN['tau0']}")
    ax.grid(alpha=0.3)
    h1, l1 = ax.get_legend_handles_labels(); h2, l2 = ax2.get_legend_handles_labels()
    ax.legend(h1 + h2, l1 + l2, fontsize=8, loc="upper right")

    # (d) 输出(a): tau*(lam)
    ax = axes[1, 0]
    for arr, sty, lab in ((pts_a_true, dict(ms=4, alpha=0.55), "true identity"),
                          (pts_a_pred, dict(ms=4, alpha=0.9, marker="x"), "recovered")):
        if len(arr):
            for mi in range(N):
                m = arr[:, 2] == mi
                if m.sum():
                    ax.scatter(arr[m, 0], arr[m, 1], s=8 if "true" in lab else 14,
                               alpha=0.5 if "true" in lab else 0.9,
                               marker="o" if "true" in lab else "x",
                               color=plt.cm.tab10(mi % 10),
                               label=f"mode {mi}" if "true" in lab else None)
    ax.plot([dh_true["lam"]], [dh_true["tau"]], "s", ms=15, mfc="none", mec="green", mew=2.5,
            label=f"double-Hopf baseline ({dh_true['lam']:.4f}, {dh_true['tau']:.4f})")
    ax.plot([dh_pred["lam"]], [dh_pred["tau"]], "*", ms=18, color="red",
            label=f"double-Hopf predicted ({dh_pred['lam']:.4f}, {dh_pred['tau']:.4f})")
    ax.plot([GT["lam_star"]], [GT["tau_star"]], "D", ms=9, mfc="none", mec="k", mew=1.6,
            label=f"user GT ({GT['lam_star']}, {GT['tau_star']})")
    ax.set_xlabel("lambda (growth rate)"); ax.set_ylabel("critical delay tau*")
    ax.set_ylim(0, 5.5)
    ax.set_title("(d) Output (a): single-Hopf curves tau*(lambda) per mode")
    ax.legend(fontsize=7); ax.grid(alpha=0.3)

    # (e) 输出(b): lam*(tau)
    ax = axes[1, 1]
    for arr, lab in ((pts_b_true, "true"), (pts_b_pred, "rec")):
        if len(arr):
            for mi in range(N):
                m = arr[:, 2] == mi
                if m.sum():
                    ax.scatter(arr[m, 0], arr[m, 1], s=8 if lab == "true" else 16,
                               alpha=0.5 if lab == "true" else 0.9,
                               marker="o" if lab == "true" else "x",
                               color=plt.cm.tab10(mi % 10))
    ax.plot([dh_true["tau"]], [dh_true["lam"]], "s", ms=15, mfc="none", mec="green", mew=2.5,
            label=f"baseline ({dh_true['lam']:.4f}, {dh_true['tau']:.4f})")
    ax.plot([dh_pred["tau"]], [dh_pred["lam"]], "*", ms=18, color="red",
            label=f"predicted ({dh_pred['lam']:.4f}, {dh_pred['tau']:.4f})")
    ax.plot([GT["tau_star"]], [GT["lam_star"]], "D", ms=9, mfc="none", mec="k", mew=1.6,
            label=f"user GT ({GT['lam_star']}, {GT['tau_star']})")
    ax.set_xlabel("delay tau"); ax.set_ylabel("critical lambda*")
    ax.set_ylim(-1.25, -0.15)
    ax.set_title("(e) Output (b): single-Hopf curves lambda*(tau) per mode")
    ax.legend(fontsize=8); ax.grid(alpha=0.3)

    # (f) 参数对照表
    ax = axes[1, 2]; ax.axis("off")
    rows = [("tau (delay)", rec["tau"], TRAIN["tau0"]),
            ("omega", rec["omega"], ID["omega"]),
            ("c", rec["c"], ID["c"]),
            ("lambda (work pt)", rec["lam"], TRAIN["lam0"]),
            ("kappa", rec["kappa"], ID["kappa"]),
            ("beta", rec["beta"], ID["beta"])]
    cell = [["param", "recovered", "true", "abs err"]]
    for nm, rv, tv in rows:
        cell.append([nm, f"{rv:+.5f}", f"{tv:+.5f}", f"{abs(rv-tv):.5f}"])
    cell.append(["", "", "", ""])
    cell.append(["double-Hopf lam*", f"{dh_pred['lam']:+.5f}", f"{GT['lam_star']:+.5f}",
                 f"{abs(dh_pred['lam']-GT['lam_star']):.5f}"])
    cell.append(["double-Hopf tau*", f"{dh_pred['tau']:+.5f}", f"{GT['tau_star']:+.5f}",
                 f"{abs(dh_pred['tau']-GT['tau_star']):.5f}"])
    tbl = ax.table(cellText=cell, cellLoc="center", loc="center", colWidths=[0.34, 0.24, 0.22, 0.2])
    tbl.auto_set_font_size(False); tbl.set_fontsize(9); tbl.scale(1, 1.5)
    for (r, c_), cellobj in tbl.get_celld().items():
        if r == 0:
            cellobj.set_facecolor("#dcdcdc"); cellobj.set_text_props(weight="bold")
        if r == len(cell) - 1 or r == len(cell) - 2:
            cellobj.set_facecolor("#fff2cc")
    ax.set_title("(f) Recovered vs true (structure match = %s)" % np.allclose(A_rec, A_true))

    fig.suptitle("N=5 SL delayed ring: time series -> (structure, tau, critical parameters) via SINDy-DDE",
                 fontsize=14, y=1.00)
    fig.tight_layout()
    out = os.path.join(FIGS, fname)
    fig.savefig(out, dpi=120, bbox_inches="tight")
    plt.close(fig)
    return out


if __name__ == "__main__":
    main()
