# -*- coding: utf-8 -*-
"""
review_e1_holdout.py — E1: 样本内 vs 样本外(out-of-sample)增益对照
====================================================================
审稿风险: 论文的结构/时延推断增益 ΔE_ij(k) 在全部 T 个样本上计算(样本内),
只有预测实验(k_eff)有 train/test 划分。特征维 p=Ns+Nc=330, 加一个候选特征
必然降低训练误差 → 增益可能被系统性抬高, 而 AUC=1.000 正是审稿人最警惕
"泄漏"的信号。

本实验: 把 err_terms 的时间轴按列切成 train(前 60%) / test(后 40%),
  - 岭回归只在 train 上拟合;
  - 误差(以及增益)只在 held-out test 上评估。
储备池状态 r_i(t) 只依赖 x_i(s), s<=t, 故按时间切分不引入未来泄漏。

对每个拓扑×种子同时产出:
  AUC_in / AUC_out, gap 判据 F1_in / F1_out, argmax k* 一致率, 时延命中(±1/±2步)。
若 AUC_out ≈ AUC_in 且 k* 一致率高 → 样本内评估无泄漏, 结论稳健。
"""
import os
import pickle
import time

import numpy as np

from pre2025_crc import W7, Reservoir
from granger_structure import fit_out
from lorenz_tune import simulate


# ---------------- 样本内 / 样本外误差 ----------------
def err_terms_split(X, i, terms, reservoirs, Nc, lam, n_train):
    """与 sindy_delay.err_terms 同构, 但拟合用前 n_train 列, 评估用其余列。

    返回 (e_in, e_out): e_in 在 train 列上评估(与论文原式一致),
    e_out 在 held-out 列上评估。
    """
    T = X.shape[0]
    K_max = max([k for (_, k) in terms] + [0])
    Ts = T - K_max - 1
    parts = [reservoirs[i][K_max + 1:T - 1, :]]
    for (j, k) in terms:
        parts.append(reservoirs[j][K_max + 1 - k:T - 1 - k, :Nc])
    R = np.hstack(parts).T                       # (p, Ts)
    U = X[K_max + 2:K_max + 2 + Ts, i, :].T      # (3, Ts)
    Rtr, Utr = R[:, :n_train], U[:, :n_train]
    Rte, Ute = R[:, n_train:], U[:, n_train:]
    w = fit_out(Utr, Rtr, lam)
    pred_tr = w @ Rtr
    pred_te = w @ Rte
    e_in = float(np.mean((Utr - pred_tr) ** 2))
    e_out = float(np.mean((Ute - pred_te) ** 2))
    return e_in, e_out


def gains_split(X, i, reservoirs, Nc, K_max, lam, n_train):
    """逐邻居 argmax, 同时返回样本内/样本外增益与各自 k*。"""
    N = X.shape[1]
    b_in, b_out = err_terms_split(X, i, [], reservoirs, Nc, lam, n_train)
    gin, gout = {}, {}
    kin, kout = {}, {}
    for j in range(N):
        if j == i:
            continue
        bi, bo = -np.inf, 0
        ci, co = -np.inf, 0
        for k in range(0, K_max + 1):
            e_in, e_out = err_terms_split(X, i, [(j, k)], reservoirs, Nc,
                                          lam, n_train)
            gi, go = b_in - e_in, b_out - e_out
            if gi > bi:
                bi, ci = gi, k
            if go > bo:
                bo, co = go, k
        gin[j], gout[j] = bi, bo
        kin[j], kout[j] = ci, co
    return gin, gout, kin, kout


# ---------------- 判据与指标 ----------------
def gap_rule(gains, N):
    hat = set()
    for i in range(N):
        items = sorted(gains[i].items(), key=lambda x: -x[1])
        g = np.array([v for _, v in items])
        if len(g) < 2:
            hat.add((i, items[0][0]))
            continue
        ratio = g[:-1] / (g[1:] + 1e-30)
        m = int(np.argmax(ratio))
        for j, _ in items[:m + 1]:
            hat.add((i, j))
    return hat


def eval_hat(hat, true):
    TP = len(hat & true); FP = len(hat - true); FN = len(true - hat)
    P = TP / (TP + FP) if TP + FP else 0.0
    R = TP / (TP + FN) if TP + FN else 0.0
    F1 = 2 * P * R / (P + R) if P + R else 0.0
    return P, R, F1, FP


def auc_of(gains, true, N):
    pos = np.array([gains[i][j] for (i, j) in true])
    neg = np.array([gains[i][j] for i in range(N) for j in range(N)
                    if j != i and (i, j) not in true])
    if len(neg) == 0:
        return float("nan")
    return float(np.mean(pos[:, None] > neg[None, :]))


# ---------------- 拓扑 ----------------
def er(N, m=3, seed=0):
    rng = np.random.default_rng(seed)
    W = (rng.random((N, N)) < m / (N - 1)).astype(int)
    np.fill_diagonal(W, 0)
    return W


def one(W, eps, tau_range, seed, T_use, Ns=300, Nc=30, lam=1e-6,
        sample=10, dt_int=0.005, train_frac=0.6):
    N = W.shape[0]
    dt_s = sample * dt_int
    rng = np.random.default_rng(seed + 1000)
    tau = rng.uniform(*tau_range, (N, N)); np.fill_diagonal(tau, 0.0)
    tau = tau * W
    t_end = T_use * dt_s + 20.0
    X = simulate(W, tau, t_end, dt=dt_int, eps=eps, seed=seed,
                 sample=sample)[:T_use]
    T = X.shape[0]
    K_max = int(np.ceil(tau[W == 1].max() / dt_s)) + 2
    n_train = int((T - K_max - 1) * train_frac)
    reservoirs = [Reservoir(Ns, 3, 0.1, 0.3, 0.9, seed=i).run(X[:, i, :])
                  for i in range(N)]
    true = set((p, q) for p in range(N) for q in range(N) if W[p, q] == 1)

    gin, gout = {}, {}
    kin, kout = {}, {}
    for i in range(N):
        a, b, c, d = gains_split(X, i, reservoirs, Nc, K_max, lam, n_train)
        gin[i], gout[i], kin[i], kout[i] = a, b, c, d

    out = dict(N=N, T=T, K_max=K_max, dt_s=dt_s, n_train=n_train,
               n_test=T - K_max - 1 - n_train,
               auc_in=auc_of(gin, true, N), auc_out=auc_of(gout, true, N))
    for tag, G in (("in", gin), ("out", gout)):
        P, R, F1, FP = eval_hat(gap_rule(G, N), true)
        out[f"P_{tag}"], out[f"R_{tag}"], out[f"F1_{tag}"], out[f"FP_{tag}"] = \
            P, R, F1, FP
    # argmax k* 一致率(真边 + 全部候选)
    same_t = tot_t = same_a = tot_a = 0
    for (i, j) in true:
        tot_t += 1
        same_t += int(kin[i][j] == kout[i][j])
    for i in range(N):
        for j in range(N):
            if j != i:
                tot_a += 1
                same_a += int(kin[i][j] == kout[i][j])
    out["kagree_true"] = same_t / tot_t
    out["kagree_all"] = same_a / tot_a
    # 时延命中: ±1 / ±2 步
    for tol, lab in ((1, "1"), (2, "2")):
        h_in = sum(int(abs(kin[i][j] * dt_s - tau[i, j]) <= tol * dt_s)
                   for (i, j) in true)
        h_out = sum(int(abs(kout[i][j] * dt_s - tau[i, j]) <= tol * dt_s)
                    for (i, j) in true)
        out[f"hit{lab}_in"], out[f"hit{lab}_out"] = h_in, len(true)
        out[f"hit{lab}_outonly"] = h_out
    # 真/假边增益中位数比(样本内外)
    for tag, G in (("in", gin), ("out", gout)):
        pos = np.array([G[i][j] for (i, j) in true])
        neg = np.array([G[i][j] for i in range(N) for j in range(N)
                        if j != i and (i, j) not in true])
        out[f"sep_{tag}"] = float(np.median(pos) / (np.median(neg) + 1e-30))
    return out


def show(tag, r):
    print(f"{tag:<30} T={r['T']:>6} ntr={r['n_train']:>6} nte={r['n_test']:>6} | "
          f"AUC in={r['auc_in']:.3f} out={r['auc_out']:.3f} | "
          f"gapF1 in={r['F1_in']:.3f} out={r['F1_out']:.3f} "
          f"(FP {r['FP_in']}/{r['FP_out']}) | "
          f"k*agree true={r['kagree_true']:.0%} all={r['kagree_all']:.0%} | "
          f"±1 hit in={r['hit1_in']}/{r['hit1_out']} out={r['hit1_outonly']}/{r['hit1_out']} | "
          f"sep in={r['sep_in']:.1f} out={r['sep_out']:.1f}", flush=True)


def main():
    t0 = time.time()
    cache = "e1_holdout_results.json"
    res = {}
    if os.path.exists(cache):
        import json
        res = json.load(open(cache, encoding="utf-8"))

    print("=" * 118, flush=True)
    print("E1: 样本内 vs 样本外(out-of-sample)增益 — 岭回归只在前 60% 拟合, 增益在后 40% 评估", flush=True)
    print("=" * 118, flush=True)

    jobs = []
    for s in range(4):
        jobs.append((f"W7 eps1.5 s{s}", W7, 1.5, (0.3, 1.2), s, 20000))
    W20 = er(20, 3, seed=0)
    jobs.append(("ER20 d3 s0", W20, 1.5, (0.3, 1.2), 0, 12000))
    jobs.append(("ER20 d3 s1", W20, 1.5, (0.3, 1.2), 1, 12000))
    Wr = np.zeros((7, 7), int)
    for j in range(7):
        Wr[j, (j - 1) % 7] = 1
        Wr[j, (j + 1) % 7] = 1
    jobs.append(("ring7 s0", Wr, 1.5, (0.3, 1.2), 0, 20000))

    for tag, W, eps, trng, seed, T_use in jobs:
        if tag in res:
            show(tag, res[tag])
            continue
        r = one(W, eps, trng, seed, T_use)
        res[tag] = r
        show(tag, r)
        import json
        json.dump(res, open(cache, "w", encoding="utf-8"), indent=1)
    print(f"\ntotal {time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
