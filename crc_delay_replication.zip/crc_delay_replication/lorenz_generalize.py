"""
lorenz_generalize.py — 两个问题一锅端
=================================================================
(1) 同步疑点: ε=1.5 这么大到底同步没有? 同步了还能辨识结构吗?
    → 扫 ε∈{0.3,0.6,1.0,1.5,2.0,3.0}, 同时输出:
       s_sync = mean_{i<j} RMS(x_i-x_j) / spread
         s→0 完全同步(不可辨识) | s≈√2≈1.41 统计独立(完全不同步)
       ρ = 平均成对相关系数
       结构 P/R + 时延命中 → 直接回答"同步是否破坏结构辨识"
(2) 泛化: 换稀疏拓扑(环/随机ER/无标度BA) + 更多振子(N=10,15,20,30)
最优配置沿用: ε=1.5, Δt=0.05, τ∈[0.3,1.2]s, Ns=300, Nc=30, λ=1e-6
"""
import time
import numpy as np
from pre2025_crc import W7, Reservoir
from lorenz_tune import simulate
from sindy_argmax import sindy_argmax


# ---------------- 拓扑生成 ----------------
def ring(N):
    W = np.zeros((N, N), int)
    for i in range(N):
        W[i, (i + 1) % N] = 1
        W[i, (i - 1) % N] = 1
    return W


def er(N, m=3, seed=0):
    """有向随机ER, 平均出度≈m."""
    rng = np.random.default_rng(seed)
    W = (rng.random((N, N)) < m / (N - 1)).astype(int)
    np.fill_diagonal(W, 0)
    return W


def ba(N, m=2, seed=0):
    """有向无标度(偏好连接): 新节点按度数概率连向m个已有节点."""
    rng = np.random.default_rng(seed)
    W = np.zeros((N, N), int)
    for i in range(1, min(m + 1, N)):
        W[i, :i] = 1          # 初始小核(前m+1个节点连向更早节点)
    for i in range(m + 1, N):
        deg = W.sum(axis=1) + W.sum(axis=0)
        p = deg[:i] / deg[:i].sum()
        for j in rng.choice(i, size=min(m, i), replace=False, p=p):
            W[i, j] = 1
    return W


# ---------------- 评估 ----------------
def run(W, sample=10, eps=1.5, tau_range=(0.3, 1.2), Ns=300, Nc=30, lam=1e-6,
        seed=0, T_use=20000, dt_int=0.005):
    """完整评估: 同步指标 + 结构P/R + 时延命中."""
    N = W.shape[0]
    dt_s = sample * dt_int
    rng = np.random.default_rng(seed + 1000)
    tau = rng.uniform(*tau_range, (N, N)); np.fill_diagonal(tau, 0.0)
    tau = tau * W
    t_end = T_use * dt_s + 20.0
    X = simulate(W, tau, t_end, dt=dt_int, eps=eps, seed=seed, sample=sample)[:T_use]
    # --- 同步指标 (x分量) ---
    xs = X[:, :, 0]
    d = np.array([np.sqrt(np.mean((xs[:, i] - xs[:, j]) ** 2))
                  for i in range(N) for j in range(i + 1, N)])
    spread = np.sqrt(np.mean((xs - xs.mean(axis=1, keepdims=True)) ** 2))
    s_sync = float(np.mean(d) / (spread + 1e-12))          # →0同步, ≈1.41独立
    C = np.corrcoef(xs.T)
    rho = float((C.sum() - N) / (N * (N - 1)))
    # --- CRC argmax ---
    reservoirs = [Reservoir(Ns, 3, 0.1, 0.3, 0.9, seed=i).run(X[:, i, :]) for i in range(N)]
    K_max = int(np.ceil(tau[W == 1].max() / dt_s)) + 2
    true = set((p, q) for p in range(N) for q in range(N) if W[p, q] == 1)
    hat = set(); hit = 0; n_true = 0; errs = []
    for i in range(N):
        gain_max, k_best = sindy_argmax(X, i, reservoirs, Nc, K_max, lam)
        thr = np.mean(list(gain_max.values()))
        for j, v in gain_max.items():
            if v > thr:
                hat.add((i, j))
        for j in range(N):
            if W[i, j] == 1:
                n_true += 1
                k = k_best.get(j, -1)
                err = abs(k * dt_s - tau[i, j])
                errs.append(err)
                hit += int(err <= 0.1)
    TP = len(hat & true); FP = len(hat - true); FN = len(true - hat)
    P = TP / (TP + FP) if TP + FP else 0; R = TP / (TP + FN) if TP + FN else 0
    return dict(P=P, R=R, TP=TP, FP=FP, FN=FN, hit=hit, n_true=n_true,
                merr=float(np.mean(errs)), s_sync=s_sync, rho=rho,
                edges=int(W.sum()), N=N, deg=float(W.sum() / N))


def show(tag, rows):
    P = np.mean([r["P"] for r in rows]); R = np.mean([r["R"] for r in rows])
    hit = np.mean([r["hit"] for r in rows]); nt = rows[0]["n_true"]
    FP = np.mean([r["FP"] for r in rows]); me = np.mean([r["merr"] for r in rows])
    ss = np.mean([r["s_sync"] for r in rows]); rh = np.mean([r["rho"] for r in rows])
    print(f"{tag:<26} P={P:>5.0%} R={R:>5.0%} FP={FP:>5.1f} 时延={hit:>5.1f}/{nt:<3}"
          f" mean|Δτ|={me:5.3f}s  s_sync={ss:5.2f} ρ={rh:+.2f}", flush=True)
    return P, R, hit / nt


def main():
    t0 = time.time()
    print("=" * 100, flush=True)
    print("[1] 同步诊断: ε扫描 (N=7 W7, Δt=0.05, τ∈[0.3,1.2], 2种子)  ", flush=True)
    print("    s_sync→0 完全同步(结构不可辨识) | s_sync≈1.41 统计独立(完全不同步)", flush=True)
    print("=" * 100, flush=True)
    print(f"{'ε':<26} {'P':>5} {'R':>5} {'FP':>5} {'时延':>9} {'mean|Δτ|':>9} {'s_sync':>7} {'ρ':>6}", flush=True)
    for eps in [0.3, 0.6, 1.0, 1.5, 2.0, 3.0]:
        rows = [run(W7, eps=eps, seed=s) for s in range(2)]
        show(f"  ε={eps:.1f}", rows)

    print("\n" + "=" * 100, flush=True)
    print("[2] 稀疏拓扑 + 更大N 泛化 (ε=1.5, Δt=0.05, τ∈[0.3,1.2])", flush=True)
    print("    N≤10: 2种子 T=20000 | N≥15: 1种子 T=12000(控算力)", flush=True)
    print("=" * 100, flush=True)
    cases = [
        ("W7 基准", W7, 2, 20000),
        ("环 N=7", ring(7), 2, 20000),
        ("随机ER N=7", er(7, 3, 1), 2, 20000),
        ("无标度BA N=7", ba(7, 2, 1), 2, 20000),
        ("环 N=10", ring(10), 2, 20000),
        ("随机ER N=10", er(10, 3, 2), 2, 20000),
        ("随机ER N=15", er(15, 3, 3), 1, 12000),
        ("环 N=20", ring(20), 1, 12000),
        ("随机ER N=20", er(20, 3, 4), 1, 12000),
        ("随机ER N=30", er(30, 3, 5), 1, 12000),
    ]
    for name, W, nseed, T in cases:
        rows = [run(W, seed=s, T_use=T) for s in range(nseed)]
        show(f"  {name} ({int(W.sum())}边,d̄={W.sum()/W.shape[0]:.1f})", rows)

    print("\n" + "=" * 100, flush=True)
    print("解读要点:", flush=True)
    print("  · s_sync 若在各 ε 下均≈1.3–1.4、ρ≈0 → 振子统计独立, 完全没有同步, 结构可辨识(P=R=100%)", flush=True)
    print("  · 若某 ε 处 s_sync 骤降(→0)且 P 崩 → 该 ε 即同步边界, 结构随之不可辨识", flush=True)
    print(f"总耗时: {time.time() - t0:.1f}s", flush=True)


if __name__ == "__main__":
    main()
