"""SL N=50 参数筛查：以基线 MSE（仅自身历史的储备池预测残差）为可辨识性代理指标。

原理（见 §4.4 机制陈述）：时延可辨识的前提是"自身历史无法完美预测下一步"，
即 baseMSE 必须显著高于数值噪声。若 baseMSE ~1e-10（极限环过度可预测），
邻居时延项无边际贡献，无需跑昂贵的全量 argmax。

筛查维度：时延/周期比、ω 异质性、κ、c、λ。
"""
import numpy as np
import time
import itertools

import sl_l50 as S
from pre2025_crc import Reservoir

LAM_R = 1e-6


def base_mse(Z, N, Ns=300, dt_int=0.005, sample=10, K_MAX=2):
    """每个振子：储备池状态 -> 下一步 z_i 的岭回归 MSE（不含任何邻居项）。"""
    dt_s = sample * dt_int
    reservoirs = [Reservoir(Ns, 2, 0.1, 0.3, 0.9, seed=i).run(Z[:, i, :])
                  for i in range(N)]
    pad = K_MAX + 1
    T = Z.shape[0]
    Ts = T - pad - 2
    out = []
    for i in range(N):
        Ri = reservoirs[i][pad:pad + Ts, :]
        U = Z[pad + 1:pad + 1 + Ts, i, :]
        G = Ri.T @ Ri
        b = Ri.T @ U
        u2 = float(np.sum(U * U))
        A = G + LAM_R * np.eye(Ri.shape[1])
        w = np.linalg.solve(A, b)
        sse = u2 - 2 * float(np.sum(b * w)) + float(np.sum(w * (A @ w))) \
            - LAM_R * float(np.sum(w * w))
        out.append(sse / (2 * Ts))
    return float(np.mean(out)), float(np.var(Z[:, :, 0]) + np.var(Z[:, :, 1]))


def screen(tag, N, lam, kappa, beta, c, wspec, tau_range, seed=0,
           dt_int=0.005, T_use=12000, W=None, verbose=True):
    omega = np.full(N, wspec[0]) if len(set(wspec)) == 1 else \
        np.random.default_rng(7).uniform(*wspec, N)
    if W is None:
        W = S.er_directed(N, 3, seed=11)
    rng = np.random.default_rng(seed + 1000)
    tau = rng.uniform(*tau_range, (N, N))
    np.fill_diagonal(tau, 0.0)
    tau = tau * W
    sample = 10
    dt_s = dt_int * sample
    t_end = T_use * dt_s + 20.0
    Z = S.simulate(W, tau, t_end, dt_int, kappa, beta, lam, c, omega, seed)[:T_use]
    if not np.all(np.isfinite(Z[-1])) or np.abs(Z).max() > 1e4:
        print(f"{tag:<46} DIVERGED", flush=True)
        return None
    s, r, a = S.sync_diag(Z, N)
    amp_t = np.sqrt(Z[:, :, 0] ** 2 + Z[:, :, 1] ** 2)
    ampCV = float(np.mean(amp_t.std(axis=0) / (amp_t.mean(axis=0) + 1e-12)))
    bm, varz = base_mse(Z, N, dt_int=dt_int)
    # 相对残差：对常数预测的归一化
    rel = bm / (varz + 1e-18)
    if verbose:
        print(f"{tag:<46} s={s:5.2f} ρ={r:+.2f} |z|={a:6.3f} ampCV={ampCV:.3f} "
              f"baseMSE={bm:.2e} rel={rel:.2e}", flush=True)
    return dict(tag=tag, s=s, rho=r, amp=a, ampCV=ampCV, base=bm, rel=rel)


if __name__ == "__main__":
    t0 = time.time()
    N = 50
    W = S.er_directed(N, 3, seed=11)
    period = 2 * np.pi / 2.0          # ω=2.0 的固有周期 ≈ 3.14 s
    print(f"N=50 ER d≈3 ({int(W.sum())} edges); ω=2.0 周期={period:.2f}s；"
          f"τ∈[0.3,1.2]≈0.1-0.4周期 vs τ∈[2.5,4.0]≈0.8-1.3周期", flush=True)

    configs = [
        #(tag, lam, kappa, beta, c, wspec, tau_range)
        ("ref τ短 λ-0.7 κ0.8 ω同2.0",  -0.7, 0.8, 0.0, 0.5, (2.0, 2.0), (0.3, 1.2)),
        ("A τ长 λ-0.7 κ0.8 ω同2.0",    -0.7, 0.8, 0.0, 0.5, (2.0, 2.0), (2.5, 4.0)),
        ("B τ长 λ-0.7 κ0.8 ω异U1.5-2.5", -0.7, 0.8, 0.0, 0.5, (1.5, 2.5), (2.5, 4.0)),
        ("C τ中 λ-0.7 κ0.8 ω同2.0",    -0.7, 0.8, 0.0, 0.5, (2.0, 2.0), (1.5, 3.0)),
        ("D τ长 λ-0.7 κ0.4 ω同2.0",    -0.7, 0.4, 0.0, 0.5, (2.0, 2.0), (2.5, 4.0)),
        ("E τ长 λ-0.7 κ1.5 ω同2.0",    -0.7, 1.5, 0.0, 0.5, (2.0, 2.0), (2.5, 4.0)),
        ("F τ长 λ-0.7 κ0.8 c=2 ω同2.0", -0.7, 0.8, 0.0, 2.0, (2.0, 2.0), (2.5, 4.0)),
        ("G τ长 λ-0.7 κ0.8 c=5 ω同2.0", -0.7, 0.8, 0.0, 5.0, (2.0, 2.0), (2.5, 4.0)),
        ("H τ长 λ-0.7 κ0.8 β=π/4 ω同", -0.7, 0.8, np.pi / 4, 0.5, (2.0, 2.0), (2.5, 4.0)),
        ("I τ长 λ-0.7 κ0.8 β=π/2 ω同", -0.7, 0.8, np.pi / 2, 0.5, (2.0, 2.0), (2.5, 4.0)),
        ("J τ长 λ+0.3 κ0.8 ω同2.0",    +0.3, 0.8, 0.0, 0.5, (2.0, 2.0), (2.5, 4.0)),
        ("K τ长 λ+1.0 κ0.8 ω同2.0",    +1.0, 0.8, 0.0, 0.5, (2.0, 2.0), (2.5, 4.0)),
    ]
    rows = []
    for tag, lam, kappa, beta, c, wsp, tr in configs:
        r = screen(tag, N, lam, kappa, beta, c, wsp, tr, W=W)
        if r:
            rows.append(r)
    print(f"\n耗时 {time.time()-t0:.1f}s")
    print("\n=== 按相对残差降序（越高越可辨识）===")
    for r in sorted(rows, key=lambda x: -x["rel"]):
        print(f"{r['tag']:<46} rel={r['rel']:.2e} base={r['base']:.2e} "
              f"s={r['s']:.2f} ρ={r['rho']:+.2f} ampCV={r['ampCV']:.3f}")
