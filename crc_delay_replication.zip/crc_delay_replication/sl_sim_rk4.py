"""
sl_sim_rk4.py — 通用拓扑 Stuart-Landau 时延耦合网络的 RK4 + 四点拉格朗日插值积分器
=====================================================================================
模型（逐辺异构时延，任意有向拓扑）:
    dz_p/dt = (λ+iω_p) z_p − (1+ic)|z_p|² z_p
              + Σ_q w_pq κ e^{iβ} z_q(t − τ_pq)

为什么必须 RK4 + 插值：
  sl_l50.simulate 用前向欧拉 + 时延按 dt 取整（round），在 N=5 环上使 C-RC 判据
  完全失效（AUC 0.43–0.63、结构 F1 0.24–0.40）；改用本积分器后，同一套判据在
  同一系统上给出 P=R=100%、时延 5/5、误差 0.0065s。故 SL 的数据生成必须使用
  高精度 DDE 积分（RK4 + 延迟态插值），而非欧拉+舍入。

实现要点（沿用 sl_ring_reconstruct.simulate_sl_ring_het 的环形缓冲方案，推广到任意拓扑）:
  - 环形缓冲 buf (M, N, 2)，M = ceil(max steps delay)+3
  - 每条有向边 e=(p←q) 的延迟步数 dsteps_e = τ_pq/dt（可为分数）
  - 延迟态 idx_e = M−1−dsteps_e+a（a 为 RK4 阶段的分数偏移），四点 Lagrange 插值
  - 各边按接收端 p 用 bincount 累加；复耦合 κe^{iβ} 手工展开为实部/虚部
"""
import time

import numpy as np


def simulate_rk4(W, tau, t_end, dt, kappa, beta, lam, c, omega, seed,
                 x0=None, hist=None):
    """RK4 + 四点 Lagrange 插值。返回 Z (T, N, 2)，T = round(t_end/dt)+1。"""
    N = W.shape[0]
    p_idx, q_idx = np.nonzero(W)                    # 边: p 由 q 驱动
    d_e = np.asarray(tau, float)[p_idx, q_idx] / dt  # 延迟步数（分数）
    d_e = np.maximum(d_e, 1e-9)
    M = int(np.ceil(d_e.max())) + 3
    cb, sb = np.cos(beta), np.sin(beta)

    n = int(round(t_end / dt))
    rng = np.random.default_rng(seed)
    if hist is not None:
        H = np.asarray(hist, float)
        buf = H[-M:].copy() if len(H) >= M else \
            np.vstack([np.tile(H[0], (M - len(H), 1, 1)), H])
        x0 = buf[-1].copy()
    else:
        if x0 is None:
            x0 = 0.4 + 0.1 * rng.standard_normal((N, 2))
        buf = np.tile(np.asarray(x0, float), (M, 1, 1))

    def delayed(a):
        """各接收端收到的 Σ_q κ e^{iβ} z_q(t+a·dt−τ_pq)，形状 (N,2)。"""
        idx = M - 1 - d_e + a
        i0 = np.floor(idx).astype(np.int64)
        w = idx - i0
        lm1 = w * (w - 1.0) * (w - 2.0) / (-6.0)
        l0 = (w + 1.0) * (w - 1.0) * (w - 2.0) / 2.0
        l1 = (w + 1.0) * w * (w - 2.0) / (-2.0)
        l2 = (w + 1.0) * w * (w - 1.0) / 6.0
        rows = (ptr + i0[None, :] + np.array([-1, 0, 1, 2])[:, None]) % M
        vals = buf[rows, q_idx[None, :], :]                     # (4, E, 2)
        lw = np.stack([lm1, l0, l1, l2])                        # (4, E)
        V = np.einsum("ae,aec->ec", lw, vals)                   # (E, 2)
        re = kappa * (cb * V[:, 0] - sb * V[:, 1])
        im = kappa * (sb * V[:, 0] + cb * V[:, 1])
        out = np.empty((N, 2))
        out[:, 0] = np.bincount(p_idx, weights=re, minlength=N)
        out[:, 1] = np.bincount(p_idx, weights=im, minlength=N)
        return out

    def rhs(z, ZD):
        a, b = z[:, 0], z[:, 1]
        m2 = a * a + b * b
        out = np.empty_like(z)
        out[:, 0] = lam * a - omega * b - (m2 * a - c * m2 * b) + ZD[:, 0]
        out[:, 1] = omega * a + lam * b - (m2 * b + c * m2 * a) + ZD[:, 1]
        return out

    Z = np.empty((n + 1, N, 2))
    Z[0] = x0
    ptr = 0
    for i in range(n):
        z = Z[i]
        k1 = rhs(z, delayed(0.0))
        k2 = rhs(z + 0.5 * dt * k1, delayed(0.5))
        k3 = rhs(z + 0.5 * dt * k2, delayed(0.5))
        k4 = rhs(z + dt * k3, delayed(1.0))
        Z[i + 1] = z + (dt / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4)
        buf[ptr] = Z[i + 1]
        ptr = (ptr + 1) % M
    return Z


def sync_diag(Z, N):
    """与 sl_l50 同口径: s_sync(成对复距离/spread), ρ(Re分量平均成对相关), 平均振幅。"""
    d = 0.0
    cnt = 0
    for i in range(N):
        for j in range(i + 1, N):
            d += np.mean(np.sum((Z[:, i, :] - Z[:, j, :]) ** 2, axis=1))
            cnt += 1
    m = np.mean(np.sum((Z - Z.mean(axis=1, keepdims=True)) ** 2, axis=2))
    s = float(np.sqrt(d / cnt / (2 * m)))
    corr = np.corrcoef(Z[:, :, 0].T)
    rho = float((corr.sum() - N) / (N * (N - 1)))
    amp = float(np.mean(np.sqrt(Z[:, :, 0] ** 2 + Z[:, :, 1] ** 2)))
    return s, rho, amp


def subsample(Z, dt, sample):
    return Z[::sample].copy(), dt * sample
